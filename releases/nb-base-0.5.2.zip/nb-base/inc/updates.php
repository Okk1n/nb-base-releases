<?php
/**
 * Mises à jour du thème depuis le dépôt public des versions (GitHub).
 *
 * Méthode approuvée par WordPress : en-tête `Update URI` de style.css et
 * filtre `update_themes_{$hostname}` (WordPress 6.1+). Deux fois par jour,
 * WordPress demande s'il existe une version plus récente ; le thème lit alors
 * le fichier de version `info.json` du dépôt public :
 *
 *   {
 *     "version": "0.5.0",
 *     "package": "https://raw.githubusercontent.com/<compte>/nb-base-releases/main/releases/nb-base-0.5.0.zip",
 *     "requires": "6.6",
 *     "requires_php": "8.3",
 *     "tested": "7.1",
 *     "signature": "<signature Ed25519, base64>"
 *   }
 *
 * Chaque zip est signé (`npm run release`, clé secrète hors du projet) ; avant
 * d'installer, le site vérifie la signature avec la clé publique du thème et
 * refuse tout zip non signé ou modifié, même publié depuis le compte GitHub.
 * Message signé : « nb-base:<version>:<sha256 du zip> » (un ancien zip ne peut
 * pas être présenté comme une nouvelle version).
 *
 * La mise à jour apparaît dans le tableau de bord comme pour tout thème et
 * n'est installée que par un designer (capacité `update_themes` réservée).
 * Fichiers produits par `npm run release` (voir README.md, « Publier une version »).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/** Adresse du dépôt public des versions (fichier info.json et zips). */
const NB_BASE_UPDATE_SOURCE = 'https://raw.githubusercontent.com/Okk1n/nb-base-releases/main/';

/**
 * Clés publiques acceptées pour la signature des versions (Ed25519, base64).
 * Ajoutées par `npm run release:keygen` ; en garder plusieurs pendant un
 * changement de clé.
 */
const NB_BASE_UPDATE_PUBLIC_KEYS = array(
	'l/pUWagtbCdZP+vHhWaOaVhIyni3y8B+KhX6gi7qIBQ=',
);

/** Cache du fichier de version (une lecture par heure au plus). */
const NB_BASE_UPDATE_CACHE = 'nb_base_update_manifest';

/**
 * Adresse du dossier des versions, terminée par « / ».
 * Le filtre sert aux tests (dépôt local) ; le zip doit toujours venir de cette adresse.
 */
function nb_base_update_source(): string {
	return trailingslashit( (string) apply_filters( 'nb_base_update_source', NB_BASE_UPDATE_SOURCE ) );
}

/**
 * Fichier de version validé, ou null (indisponible ou invalide).
 *
 * @return array{version: string, package: string, signature: string, requires: string, requires_php: string, tested: string}|null
 */
function nb_base_update_manifest(): ?array {
	$cached = get_site_transient( NB_BASE_UPDATE_CACHE );
	if ( is_array( $cached ) ) {
		return $cached ? $cached : null;
	}

	$source   = nb_base_update_source();
	$manifest = null;
	$response = wp_safe_remote_get(
		$source . 'info.json',
		array(
			'timeout' => 10,
			'headers' => array( 'Accept' => 'application/json' ),
		)
	);
	if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
		$manifest = nb_base_update_validate( json_decode( wp_remote_retrieve_body( $response ), true ), $source );
	}

	// Échec : mémorisé une heure aussi, pour ne pas ralentir l'administration.
	set_site_transient( NB_BASE_UPDATE_CACHE, $manifest ?? array(), HOUR_IN_SECONDS );
	return $manifest;
}

/**
 * Valide le contenu du fichier de version : numéros au format x.y.z,
 * zip obligatoirement situé dans le dépôt des versions.
 *
 * @param mixed  $data   Contenu décodé.
 * @param string $source Adresse du dépôt des versions.
 */
function nb_base_update_validate( $data, string $source ): ?array {
	if ( ! is_array( $data ) ) {
		return null;
	}
	$version_pattern = '/^\d+\.\d+(\.\d+)?$/';
	$version         = (string) ( $data['version'] ?? '' );
	$package         = (string) ( $data['package'] ?? '' );
	if ( ! preg_match( $version_pattern, $version )
		|| ! str_starts_with( $package, $source )
		|| ! preg_match( '/^[a-z0-9\/._-]+\.zip$/i', substr( $package, strlen( $source ) ) )
		|| str_contains( $package, '..' ) ) {
		return null;
	}
	$signature = base64_decode( (string) ( $data['signature'] ?? '' ), true );
	if ( false === $signature || 64 !== strlen( $signature ) ) {
		return null;
	}
	$manifest = array(
		'version'   => $version,
		'package'   => $package,
		'signature' => $signature,
	);
	foreach ( array( 'requires', 'requires_php', 'tested' ) as $key ) {
		$value            = (string) ( $data[ $key ] ?? '' );
		$manifest[ $key ] = preg_match( $version_pattern, $value ) ? $value : '';
	}
	return $manifest;
}

/**
 * Réponse à WordPress : version disponible pour nb-base.
 * Hôte de l'en-tête `Update URI` : github.com.
 */
add_filter(
	'update_themes_github.com',
	static function ( $update, $theme_data, $theme_stylesheet ) {
		// Environnement de développement : nb-base/ y est le dossier source.
		if ( 'nb-base' !== $theme_stylesheet || ( defined( 'NB_BASE_DISABLE_UPDATES' ) && NB_BASE_DISABLE_UPDATES ) ) {
			return $update;
		}
		$manifest = nb_base_update_manifest();
		if ( ! $manifest ) {
			return $update;
		}
		return array(
			'theme'        => 'nb-base',
			'version'      => $manifest['version'],
			'url'          => (string) $theme_data['UpdateURI'],
			'package'      => $manifest['package'],
			'requires'     => $manifest['requires'],
			'requires_php' => $manifest['requires_php'],
			'tested'       => $manifest['tested'],
		);
	},
	10,
	3
);

/**
 * Le thème n'est jamais envoyé à WordPress.org pour la recherche de mises à
 * jour : un thème homonyme publié là-bas ne pourrait pas remplacer nb-base.
 */
add_filter(
	'http_request_args',
	static function ( $args, $url ) {
		if ( ! str_contains( (string) $url, '://api.wordpress.org/themes/update-check/' )
			|| empty( $args['body']['themes'] ) ) {
			return $args;
		}
		$themes = json_decode( (string) $args['body']['themes'], true );
		if ( is_array( $themes ) ) {
			unset( $themes['themes']['nb-base'] );
			$args['body']['themes'] = wp_json_encode( $themes );
		}
		return $args;
	},
	10,
	2
);

/**
 * La signature du zip est-elle valable pour cette version ?
 *
 * @param string $file      Zip téléchargé.
 * @param string $version   Version annoncée par le fichier de version.
 * @param string $signature Signature brute (64 octets).
 */
function nb_base_update_signature_valid( string $file, string $version, string $signature ): bool {
	if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}
	$hash = hash_file( 'sha256', $file );
	if ( ! $hash ) {
		return false;
	}
	$message = 'nb-base:' . $version . ':' . $hash;
	foreach ( NB_BASE_UPDATE_PUBLIC_KEYS as $key ) {
		$key = base64_decode( (string) $key, true );
		if ( false !== $key && SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES === strlen( $key )
			&& sodium_crypto_sign_verify_detached( $signature, $message, $key ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Téléchargement d'une mise à jour de nb-base : le zip n'est remis à
 * WordPress que si sa signature est valable (filtre `upgrader_pre_download`).
 */
add_filter(
	'upgrader_pre_download',
	static function ( $reply, $package, $upgrader, $hook_extra ) {
		$package = (string) $package;
		if ( false !== $reply
			|| ( 'nb-base' !== ( $hook_extra['theme'] ?? '' ) && ! str_starts_with( $package, nb_base_update_source() ) ) ) {
			return $reply;
		}
		$manifest = nb_base_update_manifest();
		if ( ! $manifest || $manifest['package'] !== $package ) {
			delete_site_transient( NB_BASE_UPDATE_CACHE );
			$manifest = nb_base_update_manifest();
		}
		if ( ! $manifest || $manifest['package'] !== $package ) {
			return new WP_Error( 'nb_base_update_unknown', __( 'This theme update is not listed in the NB Base releases: installation cancelled.', 'nb-base' ) );
		}
		$file = download_url( $package, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		if ( ! nb_base_update_signature_valid( $file, $manifest['version'], $manifest['signature'] ) ) {
			wp_delete_file( $file );
			return new WP_Error( 'nb_base_update_signature', __( 'The signature of this theme update is invalid: installation cancelled. Contact the site designer.', 'nb-base' ) );
		}
		return $file;
	},
	10,
	4
);

/** « Vérifier à nouveau » (Tableau de bord → Mises à jour) relit le fichier de version. */
add_action(
	'load-update-core.php',
	static function () {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- simple lecture, aucune action.
		if ( isset( $_GET['force-check'] ) && current_user_can( 'update_themes' ) ) {
			delete_site_transient( NB_BASE_UPDATE_CACHE );
		}
	},
	9
);

/**
 * Mise à jour des thèmes réservée au designer : il teste chaque version
 * avant de l'installer. Les administrateurs (client) ne la voient pas.
 */
add_filter(
	'map_meta_cap',
	static function ( $caps, $cap, $user_id ) {
		if ( 'update_themes' === $cap && ! nb_base_is_designer( (int) $user_id ) ) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	10,
	3
);
