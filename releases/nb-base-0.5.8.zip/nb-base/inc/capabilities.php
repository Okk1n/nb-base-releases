<?php
/**
 * Capacité « designer » : réservée au compte du concepteur du thème.
 *
 * Seuls les comptes possédant cette capacité peuvent modifier les styles
 * globaux, les templates, les template parts, activer des fonctionnalités et
 * importer/exporter les styles. Les administrateurs (client, partenaire)
 * ne l'ont pas par défaut.
 *
 * Attribution manuelle via WP-CLI :
 *   wp user add-cap <login> nb_base_design
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_DESIGN_CAP = 'nb_base_design';

/**
 * Capacité « agence » : compte administrateur de l'agence qui vend et suit
 * le site (chef de projet, pas designer). Donnée par le designer seul (fiche
 * du compte, ou `wp user add-cap <login> nb_base_agency`). Ouvre toujours les
 * accès de nb_base_agency_accesses(), quels que soient les accès du client.
 * Le designer a implicitement tous les droits de l'agence.
 */
const NB_BASE_AGENCY_CAP = 'nb_base_agency';

/**
 * L'utilisateur (courant par défaut) est-il designer ?
 */
function nb_base_is_designer( ?int $user_id = null ): bool {
	$user_id = $user_id ?? get_current_user_id();
	return $user_id > 0 && user_can( $user_id, NB_BASE_DESIGN_CAP );
}

/**
 * Existe-t-il au moins un compte designer sur le site ?
 */
function nb_base_has_designer(): bool {
	foreach ( get_users( array( 'fields' => 'ID' ) ) as $user_id ) {
		if ( nb_base_is_designer( (int) $user_id ) ) {
			return true;
		}
	}
	return false;
}

/**
 * À la première activation du thème, le compte qui l'active devient designer
 * (uniquement si aucun designer n'existe encore).
 */
add_action(
	'after_switch_theme',
	static function () {
		$user = wp_get_current_user();
		if ( $user->exists() && ! nb_base_has_designer() ) {
			$user->add_cap( NB_BASE_DESIGN_CAP );
		}
	}
);

/**
 * Le compte est-il designer ? Lecture directe des droits du compte, sans
 * passer par `map_meta_cap` (utilisable dans ce filtre sans boucle).
 */
function nb_base_user_is_designer( int $user_id ): bool {
	$user = $user_id > 0 ? get_userdata( $user_id ) : false;
	return $user && ! empty( $user->allcaps[ NB_BASE_DESIGN_CAP ] );
}

/**
 * Le compte a-t-il le droit agence (donné directement, designer non compris) ?
 * Lecture directe, sans passer par `map_meta_cap`.
 */
function nb_base_user_is_agency( int $user_id ): bool {
	$user = $user_id > 0 ? get_userdata( $user_id ) : false;
	return $user && ! empty( $user->allcaps[ NB_BASE_AGENCY_CAP ] );
}

/**
 * Accès toujours ouverts au compte agence (fermés au client par défaut,
 * ouvrables site par site : NB Base → Fonctionnalités → Accès du client).
 * Apparence → Thèmes et Polices restent au designer (structure, charte).
 *
 * @return string[]
 */
function nb_base_agency_accesses(): array {
	return array( 'client_settings', 'client_tools', 'client_users', 'client_forms' );
}

/**
 * Le compte a-t-il cet accès réservé (designer, agence ou accès client ouvert) ?
 *
 * @param int    $user_id Compte.
 * @param string $access  Accès (client_settings, client_tools…).
 */
function nb_base_user_access( int $user_id, string $access ): bool {
	return nb_base_user_is_designer( $user_id )
		|| ( nb_base_user_is_agency( $user_id ) && in_array( $access, nb_base_agency_accesses(), true ) )
		|| nb_base_feature_enabled( $access );
}

// Le designer a tous les droits de l'agence (ex. formulaires, voir forms-cf7.php).
add_filter(
	'user_has_cap',
	static function ( array $allcaps ): array {
		if ( ! empty( $allcaps[ NB_BASE_DESIGN_CAP ] ) ) {
			$allcaps[ NB_BASE_AGENCY_CAP ] = true;
		}
		return $allcaps;
	}
);

/**
 * Droits retirés aux comptes non designers (client, partenaire), même
 * administrateurs : code et fichiers du site (éditeurs de fichiers, thèmes,
 * HTML libre). Ils gardent l'installation et la gestion des extensions.
 *
 * @return string[]
 */
function nb_base_designer_only_caps(): array {
	return array(
		'edit_files',
		'edit_themes',
		'edit_plugins',
		'install_themes',
		'upload_themes',
		'switch_themes',
		'delete_themes',
		'unfiltered_html',
		'unfiltered_upload',
	);
}

/**
 * Comptes protégés :
 * - compte designer : seul un designer peut le modifier (mot de passe, e-mail,
 *   mots de passe d'application, sessions), le supprimer ou changer son rôle ;
 * - compte agence : seuls un designer et les comptes agence (lui-même
 *   compris) le peuvent ; le client non.
 *
 * @return string[]
 */
function nb_base_protected_user_caps(): array {
	return array( 'edit_user', 'delete_user', 'remove_user', 'promote_user' );
}

add_filter(
	'map_meta_cap',
	static function ( $caps, $cap, $user_id, $args ) {
		$designer_only = in_array( $cap, nb_base_designer_only_caps(), true );
		$user_cap      = in_array( $cap, nb_base_protected_user_caps(), true );
		$create_user   = in_array( $cap, array( 'create_users', 'add_users' ), true );
		if ( ! $designer_only && ! $user_cap && ! $create_user ) {
			return $caps;
		}
		if ( nb_base_user_is_designer( (int) $user_id ) ) {
			return $caps;
		}
		if ( $create_user ) {
			// Création de comptes : agence, ou accès client « client_users » (fermé par défaut).
			if ( ! nb_base_user_access( (int) $user_id, 'client_users' ) ) {
				$caps[] = 'do_not_allow';
			}
		} elseif ( $designer_only ) {
			$caps[] = 'do_not_allow';
		} elseif ( ! empty( $args[0] ) && (int) $args[0] !== (int) $user_id ) {
			$target = (int) $args[0];
			if ( nb_base_user_is_designer( $target )
				|| ( nb_base_user_is_agency( $target ) && ! nb_base_user_is_agency( (int) $user_id ) ) ) {
				$caps[] = 'do_not_allow';
			}
		}
		return $caps;
	},
	10,
	4
);

/**
 * Création de comptes par un non-designer : seulement si l'accès client
 * « Création de comptes » (client_users) est ouvert (NB Base → Fonctionnalités).
 * Création et modification des comptes par un non-designer : tous les rôles
 * sauf administrateur (un collaborateur oui, un nouvel administrateur non).
 * S'applique aux écrans Comptes et à l'API REST (`get_editable_roles()`).
 */
add_filter(
	'editable_roles',
	static function ( $roles ) {
		if ( ! nb_base_user_is_designer( get_current_user_id() ) ) {
			unset( $roles['administrator'] );
		}
		return $roles;
	}
);

/*
 * Fiche d'un compte administrateur (designer seulement) : case « Compte
 * agence ». Enregistrée seulement par un designer (vérifié côté serveur).
 */
$nb_base_agency_field = static function ( WP_User $user ): void {
	if ( ! nb_base_is_designer() || nb_base_user_is_designer( $user->ID ) || ! in_array( 'administrator', (array) $user->roles, true ) ) {
		return;
	}
	?>
	<h2><?php esc_html_e( 'NB Base', 'nb-base' ); ?></h2>
	<table class="form-table" role="presentation"><tbody>
		<tr>
			<th scope="row"><?php esc_html_e( 'Agency account', 'nb-base' ); ?></th>
			<td>
				<label for="nb-base-agency">
					<input type="checkbox" id="nb-base-agency" name="nb_base_agency" value="1" <?php checked( nb_base_user_is_agency( $user->ID ) ); ?>>
					<?php esc_html_e( 'Account of the agency that sells and follows the site', 'nb-base' ); ?>
				</label>
				<p class="description"><?php esc_html_e( 'Always has the Settings and Tools menus, account creation (any role except administrator) and form editing, whatever the client accesses. Never the styles, templates, features, NB Base page, themes or fonts.', 'nb-base' ); ?></p>
			</td>
		</tr>
	</tbody></table>
	<?php
};
add_action( 'show_user_profile', $nb_base_agency_field );
add_action( 'edit_user_profile', $nb_base_agency_field );

$nb_base_agency_save = static function ( int $user_id ): void {
	// Nonce vérifié par WordPress (update-user_<id>) avant ces actions.
	if ( ! nb_base_is_designer() || nb_base_user_is_designer( $user_id ) ) {
		return;
	}
	$user = get_userdata( $user_id );
	if ( ! $user ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( ! empty( $_POST['nb_base_agency'] ) && in_array( 'administrator', (array) $user->roles, true ) ) {
		$user->add_cap( NB_BASE_AGENCY_CAP );
	} else {
		$user->remove_cap( NB_BASE_AGENCY_CAP );
	}
};
add_action( 'personal_options_update', $nb_base_agency_save );
add_action( 'edit_user_profile_update', $nb_base_agency_save );
unset( $nb_base_agency_field, $nb_base_agency_save );

/*
 * Comptes designer masqués aux autres comptes : liste Comptes (et ses
 * compteurs) et liste des comptes de l'API REST. Ils restent protégés
 * (voir plus haut) et visibles du designer.
 */

/**
 * Identifiants des comptes designer.
 *
 * @return int[]
 */
function nb_base_designer_ids(): array {
	static $ids = null;
	if ( null === $ids ) {
		$ids = array_values(
			array_filter(
				array_map( 'intval', get_users( array( 'fields' => 'ID', 'role' => 'administrator' ) ) ),
				'nb_base_user_is_designer'
			)
		);
	}
	return $ids;
}

add_filter(
	'users_list_table_query_args',
	static function ( array $args ): array {
		if ( ! nb_base_user_is_designer( get_current_user_id() ) ) {
			$args['exclude'] = array_merge( (array) ( $args['exclude'] ?? array() ), nb_base_designer_ids() );
		}
		return $args;
	}
);

add_filter(
	'rest_user_query',
	static function ( array $args ): array {
		if ( ! nb_base_user_is_designer( get_current_user_id() ) ) {
			$args['exclude'] = array_merge( (array) ( $args['exclude'] ?? array() ), nb_base_designer_ids() );
		}
		return $args;
	}
);

// Compteurs « Tous (n) | Administrateur (n) » de la liste Comptes, sans les designers.
add_filter(
	'pre_count_users',
	static function ( $result, $strategy, $site_id ) {
		static $running = false;
		if ( null !== $result || $running || ! is_admin() || nb_base_user_is_designer( get_current_user_id() ) ) {
			return $result;
		}
		$running = true;
		$counts  = count_users( $strategy, $site_id );
		$running = false;
		foreach ( nb_base_designer_ids() as $id ) {
			$user = get_userdata( $id );
			--$counts['total_users'];
			foreach ( (array) ( $user ? $user->roles : array() ) as $role ) {
				if ( isset( $counts['avail_roles'][ $role ] ) ) {
					--$counts['avail_roles'][ $role ];
				}
			}
		}
		return $counts;
	},
	10,
	3
);
