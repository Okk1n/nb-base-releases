<?php
/**
 * Licence du site : une clé par nom de domaine, signée par le designer.
 *
 * Clé produite hors du site par `npm run license -- <domaine>` (clé secrète
 * des versions, ~/.nb-base/release-signing-key.pem) et collée dans
 * NB Base → Licence. Format : « <domaine>:<signature Ed25519, base64url> »,
 * message signé « nb-base-license:<domaine> » (distinct des versions).
 * Vérifiée sur le site, sans appel réseau, avec les clés publiques du thème
 * (NB_BASE_UPDATE_PUBLIC_KEYS, inc/updates.php).
 *
 * Une clé vaut pour son domaine et ses sous-domaines (www, préprod…). Sites
 * locaux (localhost, *.local, *.test…) : toujours acceptés.
 *
 * Sans licence valable pour le domaine du site : le site s'affiche et
 * fonctionne comme avant (aucun rendu cassé, fonctionnalités inchangées),
 * mais aucune mise à jour du thème n'est proposée ni installée, et les
 * réglages de la page NB Base ne peuvent plus être enregistrés (sauf la
 * licence). Avertissement affiché au designer.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_LICENSE_OPTION = 'nb_base_license';

/**
 * Nom de domaine normalisé : minuscules, sans protocole, chemin, port ni
 * « www. » de tête, en ASCII (punycode). '' si invalide.
 *
 * @param string $domain Domaine ou adresse.
 */
function nb_base_license_normalize_domain( string $domain ): string {
	$domain = strtolower( trim( $domain ) );
	if ( str_contains( $domain, '://' ) ) {
		$domain = (string) wp_parse_url( $domain, PHP_URL_HOST );
	}
	$domain = preg_replace( '/[\/:].*$/', '', $domain );
	$domain = rtrim( (string) $domain, '.' );
	if ( '' !== $domain && preg_match( '/[^\x20-\x7e]/', $domain ) && function_exists( 'idn_to_ascii' ) ) {
		$ascii  = idn_to_ascii( $domain, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46 );
		$domain = false === $ascii ? '' : $ascii;
	}
	$domain = (string) preg_replace( '/^www\./', '', $domain );
	return preg_match( '/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/', $domain ) ? $domain : '';
}

/**
 * Domaine du site (adresse du site, réglages WordPress).
 */
function nb_base_license_site_host(): string {
	return strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
}

/**
 * Le site est-il local (développement, préprod sur l'ordinateur du designer) ?
 *
 * @param string $host Domaine du site.
 */
function nb_base_license_is_local( string $host ): bool {
	return in_array( $host, array( 'localhost', '127.0.0.1', '::1', '[::1]' ), true )
		|| (bool) preg_match( '/\.(localhost|local|test)$/', $host );
}

/**
 * Domaine d'une clé dont la signature est valable ('' sinon).
 *
 * @param string $key Clé de licence.
 */
function nb_base_license_key_domain( string $key ): string {
	$key = trim( $key );
	$sep = strrpos( $key, ':' );
	if ( false === $sep ) {
		return '';
	}
	$domain = substr( $key, 0, $sep );
	if ( nb_base_license_normalize_domain( $domain ) !== $domain ) {
		return '';
	}
	$signature = base64_decode( strtr( substr( $key, $sep + 1 ), '-_', '+/' ), true );
	if ( false === $signature || 64 !== strlen( $signature ) ) {
		return '';
	}
	if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}
	foreach ( NB_BASE_UPDATE_PUBLIC_KEYS as $public ) {
		$public = base64_decode( (string) $public, true );
		if ( false !== $public && SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES === strlen( $public )
			&& sodium_crypto_sign_verify_detached( $signature, 'nb-base-license:' . $domain, $public ) ) {
			return $domain;
		}
	}
	return '';
}

/**
 * La clé est-elle valable pour ce domaine (le domaine de la clé ou l'un de
 * ses sous-domaines) ?
 *
 * @param string $key  Clé de licence.
 * @param string $host Domaine du site.
 */
function nb_base_license_valid_for( string $key, string $host ): bool {
	$domain = nb_base_license_key_domain( $key );
	$host   = strtolower( $host );
	return '' !== $domain && ( $host === $domain || str_ends_with( $host, '.' . $domain ) );
}

/**
 * Clé enregistrée sur le site.
 */
function nb_base_license_key(): string {
	$key = get_option( NB_BASE_LICENSE_OPTION, '' );
	return is_string( $key ) ? trim( $key ) : '';
}

/**
 * Le site a-t-il une licence valable (ou est-il local) ?
 */
function nb_base_license_active(): bool {
	$host = nb_base_license_site_host();
	return nb_base_license_is_local( $host ) || nb_base_license_valid_for( nb_base_license_key(), $host );
}

/**
 * Page NB Base : onglet « Licence » (toujours présent).
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		$tabs['license'] = array(
			'label'  => __( 'License', 'nb-base' ),
			'render' => 'nb_base_license_admin_tab',
		);
		return $tabs;
	},
	1
);

/**
 * Contenu de l'onglet.
 */
function nb_base_license_admin_tab(): void {
	$key    = nb_base_license_key();
	$host   = nb_base_license_site_host();
	$domain = nb_base_license_key_domain( $key );
	?>
	<?php if ( nb_base_license_valid_for( $key, $host ) ) : ?>
		<div class="notice notice-success inline"><p>
			<?php
			/* translators: %s: domain name. */
			printf( esc_html__( 'Valid license for %s.', 'nb-base' ), '<strong>' . esc_html( $domain ) . '</strong>' );
			?>
		</p></div>
	<?php elseif ( nb_base_license_is_local( $host ) ) : ?>
		<div class="notice notice-info inline"><p><?php esc_html_e( 'Local site: no license needed. Add the key of the production domain before exporting the site.', 'nb-base' ); ?></p></div>
	<?php elseif ( '' !== $domain ) : ?>
		<div class="notice notice-error inline"><p>
			<?php
			/* translators: 1: domain of the key, 2: domain of the site. */
			printf( esc_html__( 'This key is for %1$s, not for this site (%2$s).', 'nb-base' ), '<strong>' . esc_html( $domain ) . '</strong>', '<strong>' . esc_html( $host ) . '</strong>' );
			?>
		</p></div>
	<?php else : ?>
		<div class="notice notice-error inline"><p><?php echo esc_html( '' === $key ? __( 'No license key.', 'nb-base' ) : __( 'Invalid license key.', 'nb-base' ) ); ?></p></div>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_license">
		<?php wp_nonce_field( 'nb_base_save_license' ); ?>
		<table class="form-table" role="presentation"><tbody>
			<tr>
				<th scope="row"><label for="nb-license-key"><?php esc_html_e( 'License key', 'nb-base' ); ?></label></th>
				<td>
					<input id="nb-license-key" class="large-text code" type="text" name="license" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" spellcheck="false">
					<p class="description"><?php esc_html_e( 'One key per domain (also valid for its subdomains: www, staging…). Without a valid key, the site keeps working but receives no theme update and the NB Base settings can no longer be saved.', 'nb-base' ); ?></p>
				</td>
			</tr>
		</tbody></table>
		<?php submit_button( __( 'Save license', 'nb-base' ) ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_license',
	static function () {
		nb_base_admin_guard( 'nb_base_save_license' );
		$key = isset( $_POST['license'] ) ? sanitize_text_field( wp_unslash( $_POST['license'] ) ) : '';
		update_option( NB_BASE_LICENSE_OPTION, substr( trim( $key ), 0, 400 ), true );
		nb_base_admin_redirect( 'license-saved', 'license' );
	}
);

/**
 * Avertissement sur tous les écrans de l'administration :
 * - au designer, dès que la licence manque ou ne vaut pas pour ce domaine ;
 * - aux autres administrateurs, seulement quand le site a une clé faite pour
 *   un autre domaine (nom de domaine changé, site copié) : message neutre,
 *   qui renvoie au concepteur du site. Sans clé du tout : rien pour eux.
 */
add_action(
	'admin_notices',
	static function () {
		if ( nb_base_license_active() ) {
			return;
		}
		if ( ! nb_base_is_designer() ) {
			if ( current_user_can( 'manage_options' ) && '' !== nb_base_license_key_domain( nb_base_license_key() ) ) {
				printf(
					'<div class="notice notice-warning"><p>%s</p></div>',
					esc_html__( 'The domain name of the site has changed: contact the site designer to update the theme license. Until then, theme updates are suspended.', 'nb-base' )
				);
			}
			return;
		}
		printf(
			'<div class="notice notice-error"><p>%s <a href="%s">%s</a></p></div>',
			esc_html__( 'NB Base: no valid license for this domain. Theme updates and NB Base settings are blocked.', 'nb-base' ),
			esc_url( nb_base_admin_tab_url( 'license' ) ),
			esc_html__( 'Enter the license', 'nb-base' )
		);
	}
);
