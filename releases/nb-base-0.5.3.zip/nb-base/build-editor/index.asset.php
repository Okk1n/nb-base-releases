<?php return array(
	'dependencies' => array(
		'react-jsx-runtime',
		'wp-block-editor',
		'wp-blocks',
		'wp-components',
		'wp-compose',
		'wp-data',
		'wp-editor',
		'wp-element',
		'wp-hooks',
		'wp-i18n',
		'wp-plugins'
	),
	'version' => 'ae92cdb5a1a3bbb36146'
);
