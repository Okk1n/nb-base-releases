<?php return array(
	'dependencies' => array(
		
	),
	'version' => 'e5bd7a621c337bbcbd2d'
);
