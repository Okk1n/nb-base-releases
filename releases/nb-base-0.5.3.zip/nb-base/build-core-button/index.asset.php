<?php return array(
	'dependencies' => array(
		
	),
	'version' => '87a12ec2b6759a0f08ef'
);
