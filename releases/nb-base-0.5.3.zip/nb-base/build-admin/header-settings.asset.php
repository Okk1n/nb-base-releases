<?php return array(
	'dependencies' => array(
		'react-jsx-runtime',
		'wp-components',
		'wp-core-data',
		'wp-data',
		'wp-element',
		'wp-html-entities',
		'wp-i18n',
		'wp-media-utils',
		'wp-notices'
	),
	'version' => 'd465a845aa78d28f4903'
);
