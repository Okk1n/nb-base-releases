<?php return array(
	'dependencies' => array(
		'react',
		'react-jsx-runtime',
		'wp-components',
		'wp-core-data',
		'wp-data',
		'wp-date',
		'wp-element',
		'wp-i18n',
		'wp-media-utils',
		'wp-notices'
	),
	'version' => 'f96315b709bb72cb3cb7'
);
