<?php
/**
 * En-tête du site (bloc nb-base/header, placé dans parts/header.html).
 *
 * Réglages modifiables par les administrateurs (client compris), page
 * Apparence → En-tête et pied de page (onglet « En-tête » ; pied de page :
 * inc/footer.php) :
 *  - logo normal : option native « site_logo » (même logo que l'identité du site) ;
 *  - option « nb_base_header » : logo clair, hauteur du logo, fond,
 *    affichage du téléphone, bouton devis ;
 *  - menu : emplacement « En-tête » (Apparence → Menus, menus classiques :
 *    l'éditeur de site est réservé au designer).
 *  - option « nb_base_phone » : téléphone du site (réutilisable ailleurs).
 *
 * Toutes ces options sont des réglages natifs exposés à l'API REST
 * (/wp/v2/settings, droit manage_options), bornés et nettoyés à
 * l'enregistrement : aucune valeur ne peut casser l'affichage.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_HEADER_ADMIN_SLUG = 'nb-base-header';
const NB_BASE_LOGO_HEIGHT_MIN   = 24;
const NB_BASE_LOGO_HEIGHT_MAX   = 120;

/**
 * Emplacement de menu de l'en-tête (Apparence → Menus).
 */
add_action(
	'after_setup_theme',
	static function () {
		register_nav_menus( array( 'header' => __( 'Header', 'nb-base' ) ) );
	}
);

/**
 * Valeurs par défaut des réglages de l'en-tête.
 */
function nb_base_header_defaults(): array {
	return array(
		'logoLight'    => 0,       // Logo clair (fonds sombres), 0 = logo normal partout.
		'logoHeight'   => 64,      // Hauteur du logo (px), bornée.
		'background'   => '',      // Fond (identifiant de inc/backgrounds.php), '' = fond par défaut.
		'showPhone'    => true,    // Afficher le téléphone du site.
		'buttonText'   => '',      // Bouton devis : vide = pas de bouton.
		'buttonType'   => 'page',  // « page » (page + ancre facultative) ou « url » (lien libre, ancre…).
		'buttonPage'   => 0,
		'buttonAnchor' => '',
		'buttonUrl'    => '',
	);
}

/**
 * Nettoyage des réglages (enregistrement et lecture).
 *
 * @param mixed $value Valeur reçue.
 */
function nb_base_sanitize_header( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = nb_base_header_defaults();
	$height   = (int) ( $value['logoHeight'] ?? $defaults['logoHeight'] );
	return array(
		'logoLight'    => max( 0, (int) ( $value['logoLight'] ?? 0 ) ),
		'logoHeight'   => max( NB_BASE_LOGO_HEIGHT_MIN, min( NB_BASE_LOGO_HEIGHT_MAX, $height ) ),
		'background'   => preg_match( '/^[a-z0-9-]*$/', (string) ( $value['background'] ?? '' ) ) ? (string) ( $value['background'] ?? '' ) : '',
		'showPhone'    => (bool) ( $value['showPhone'] ?? $defaults['showPhone'] ),
		'buttonText'   => sanitize_text_field( (string) ( $value['buttonText'] ?? '' ) ),
		'buttonType'   => 'url' === ( $value['buttonType'] ?? '' ) ? 'url' : 'page',
		'buttonPage'   => max( 0, (int) ( $value['buttonPage'] ?? 0 ) ),
		// Mêmes caractères que l'ancre HTML native des blocs.
		'buttonAnchor' => (string) preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $value['buttonAnchor'] ?? '' ) ),
		'buttonUrl'    => esc_url_raw( trim( (string) ( $value['buttonUrl'] ?? '' ) ) ),
	);
}

/**
 * Réglages de l'en-tête.
 */
function nb_base_header_settings(): array {
	return nb_base_sanitize_header( get_option( 'nb_base_header', array() ) );
}

/*
 * Lecture toujours nettoyée : une ancienne clé restée en base (ex. « menu »,
 * retirée lors du passage aux menus classiques) ferait échouer la validation
 * de l'API REST (« additionalProperties ») : la valeur deviendrait null et la
 * page de réglages ne se chargerait plus.
 */
add_filter( 'option_nb_base_header', 'nb_base_sanitize_header' );

/**
 * Image d'un logo (médiathèque), SVG compris. '' si aucun.
 *
 * @param int   $id    Fichier de la médiathèque.
 * @param array $attrs Attributs de la balise (class…).
 */
function nb_base_logo_html( int $id, array $attrs ): string {
	if ( ! $id ) {
		return '';
	}
	$attrs += array(
		'alt'      => get_bloginfo( 'name', 'display' ),
		'decoding' => 'async',
	);
	$html = wp_get_attachment_image( $id, 'full', false, $attrs );
	// SVG : WordPress ne le traite pas comme une image (pas de dimensions).
	if ( '' === $html && 'image/svg+xml' === get_post_mime_type( $id ) ) {
		$attrs['src'] = (string) wp_get_attachment_url( $id );
		$html         = '<img';
		foreach ( $attrs as $name => $value ) {
			$html .= ' ' . $name . '="' . esc_attr( $value ) . '"';
		}
		$html .= '>';
	}
	return $html;
}

add_action(
	'init',
	static function () {
		$props = array(
			'logoLight'    => array( 'type' => 'integer' ),
			'logoHeight'   => array( 'type' => 'integer' ),
			'background'   => array( 'type' => 'string' ),
			'showPhone'    => array( 'type' => 'boolean' ),
			'buttonText'   => array( 'type' => 'string' ),
			'buttonType'   => array( 'type' => 'string' ),
			'buttonPage'   => array( 'type' => 'integer' ),
			'buttonAnchor' => array( 'type' => 'string' ),
			'buttonUrl'    => array( 'type' => 'string' ),
		);
		register_setting(
			'nb_base',
			'nb_base_header',
			array(
				'type'              => 'object',
				'description'       => __( 'Site header settings.', 'nb-base' ),
				'default'           => nb_base_header_defaults(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => $props,
						'additionalProperties' => false,
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_header',
			)
		);
		register_setting(
			'nb_base',
			'nb_base_phone',
			array(
				'type'              => 'string',
				'description'       => __( 'Site phone number.', 'nb-base' ),
				'default'           => '',
				'show_in_rest'      => true,
				'sanitize_callback' => static fn( $v ) => sanitize_text_field( (string) $v ),
			)
		);
	}
);

/**
 * Lien d'appel : « 04 93 75 73 73 » → « tel:0493757373 » (chiffres et « + » initial).
 */
function nb_base_phone_href( string $phone ): string {
	$digits = preg_replace( '/[^\d+]/', '', $phone );
	$digits = ( str_starts_with( $digits, '+' ) ? '+' : '' ) . str_replace( '+', '', $digits );
	return '' === trim( $digits, '+' ) ? '' : 'tel:' . $digits;
}

/**
 * Adresse du bouton devis ('' si aucune : bouton masqué).
 */
function nb_base_header_button_url( array $settings ): string {
	if ( 'url' === $settings['buttonType'] ) {
		return $settings['buttonUrl'];
	}
	$page = $settings['buttonPage'] ? get_post( $settings['buttonPage'] ) : null;
	if ( ! $page || 'publish' !== $page->post_status ) {
		return '';
	}
	return get_permalink( $page ) . ( '' !== $settings['buttonAnchor'] ? '#' . $settings['buttonAnchor'] : '' );
}

/**
 * En-tête transparent superposé : la page commence par un hero (photo,
 * vidéo, ou hero d'un contenu structuré).
 */
function nb_base_header_overlay(): bool {
	$overlay = false;
	$post    = is_singular() ? get_queried_object() : null;
	if ( $post instanceof WP_Post && ! post_password_required( $post ) ) {
		foreach ( parse_blocks( $post->post_content ) as $block ) {
			if ( ! empty( $block['blockName'] ) ) {
				$overlay = in_array( $block['blockName'], array( 'nb-base/hero', 'nb-base/entry-hero' ), true );
				break;
			}
		}
	}
	/**
	 * Permet de forcer (ou d'empêcher) l'en-tête transparent.
	 */
	return (bool) apply_filters( 'nb_base_header_overlay', $overlay );
}

/**
 * Logos SVG : envoi réservé au designer. Les clients n'envoient que des
 * images classiques (PNG, JPG, WebP). Un SVG est affiché dans une balise
 * <img> : aucun script qu'il contiendrait ne peut s'exécuter.
 */
add_filter(
	'upload_mimes',
	static function ( array $mimes ): array {
		if ( nb_base_is_designer() && current_user_can( 'unfiltered_html' ) ) {
			$mimes['svg'] = 'image/svg+xml';
		}
		return $mimes;
	}
);

/**
 * Page Apparence → En-tête et pied de page (administrateurs, client compris).
 */
add_action(
	'admin_menu',
	static function () {
		$hook = add_theme_page(
			__( 'Header & footer', 'nb-base' ),
			__( 'Header & footer', 'nb-base' ),
			'manage_options',
			NB_BASE_HEADER_ADMIN_SLUG,
			static function () {
				echo '<div class="wrap"><h1>' . esc_html__( 'Header & footer', 'nb-base' ) . '</h1><div id="nb-base-header-settings"></div></div>';
			}
		);
		add_action(
			'admin_enqueue_scripts',
			static function ( string $current ) use ( $hook ) {
				$asset_file = NB_BASE_DIR . '/build-admin/header-settings.asset.php';
				if ( $current !== $hook || ! is_readable( $asset_file ) ) {
					return;
				}
				$asset = require $asset_file;
				wp_enqueue_media();
				wp_enqueue_script( 'nb-base-header-settings', NB_BASE_URI . '/build-admin/header-settings.js', $asset['dependencies'], $asset['version'], true );
				wp_enqueue_style( 'nb-base-header-settings', NB_BASE_URI . '/build-admin/header-settings.css', array( 'wp-components' ), $asset['version'] );
				wp_set_script_translations( 'nb-base-header-settings', 'nb-base', NB_BASE_DIR . '/languages' );
				$data = array(
					'backgrounds' => array_map(
						static fn( $bg ) => array(
							'slug'  => $bg['slug'],
							'label' => $bg['label'],
						),
						array_values( nb_base_backgrounds() )
					),
					'logoHeight'  => array(
						'min'     => NB_BASE_LOGO_HEIGHT_MIN,
						'max'     => NB_BASE_LOGO_HEIGHT_MAX,
						'default' => nb_base_header_defaults()['logoHeight'],
					),
					'menusUrl'    => admin_url( 'nav-menus.php' ),
					'menuName'    => ( static function () {
						$id   = get_nav_menu_locations()['header'] ?? 0;
						$menu = $id ? wp_get_nav_menu_object( $id ) : false;
						return $menu ? $menu->name : '';
					} )(),
					'footer'      => nb_base_footer_admin_data(),
					'businessUrl' => admin_url( 'admin.php?page=' . NB_BASE_BUSINESS_ADMIN_SLUG ),
				);
				wp_add_inline_script( 'nb-base-header-settings', 'window.nbBaseHeader = ' . wp_json_encode( $data ) . ';', 'before' );
			}
		);
	}
);
