<?php
/**
 * Consentement aux cookies : partie neutre, indépendante de l'extension.
 *
 * Le thème ne dépose aucun cookie et ne charge aucun service tiers : un site
 * du thème n'a pas besoin de bandeau tant que le client n'ajoute pas de
 * service tiers (statistiques, vidéo ou carte intégrée…). Dès qu'il en
 * ajoute, la fonctionnalité « cookies » est activée : l'extension de
 * consentement (Complianz aujourd'hui) devient indispensable.
 *
 * L'extension n'est connue que de son adaptateur (inc/cookies-complianz.php),
 * qui la déclare présente (filtre « nb_base_cookies_plugin_active ») et la
 * protège (seul le designer la désactive, mises à jour automatiques). Le
 * thème fonctionne sans elle ; si elle manque alors que la fonctionnalité
 * est activée, le designer est averti.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['cookies'] = array(
			'group'       => 'privacy',
			'label'       => __( 'Cookie consent', 'nb-base' ),
			'description' => __( 'Cookie banner and cookie policy (requires the Complianz plugin). Needed as soon as the site uses a third-party service that sets cookies: statistics, embedded videos or maps…', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * L'extension de consentement est-elle active ? (fournie par l'adaptateur)
 */
function nb_base_cookies_plugin_active(): bool {
	return (bool) apply_filters( 'nb_base_cookies_plugin_active', false );
}

/**
 * Avertissement au designer : fonctionnalité activée, extension absente.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! nb_base_feature_enabled( 'cookies' ) || nb_base_cookies_plugin_active() || ! nb_base_is_designer() ) {
			return;
		}
		echo '<div class="notice notice-error"><p>' . esc_html__( 'Cookie consent is enabled but the Complianz plugin is not active: the site shows no cookie banner. Install and activate Complianz.', 'nb-base' ) . '</p></div>';
	}
);
