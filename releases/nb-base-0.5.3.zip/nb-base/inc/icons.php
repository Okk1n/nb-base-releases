<?php
/**
 * Icônes Tabler (contour), rendues côté serveur à partir des fichiers SVG
 * embarqués dans le thème (assets/icons/outline/). Seules les icônes
 * utilisées dans la page sont lues.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Retourne le SVG d'une icône, ou une chaîne vide si elle n'existe pas.
 *
 * @param string $name  Nom Tabler (ex. « star », « arrow-right »).
 * @param string $class Classe CSS ajoutée au SVG.
 */
function nb_base_icon( string $name, string $class = '' ): string {
	static $cache = array();

	if ( ! preg_match( '/^[a-z0-9-]+$/', $name ) ) {
		return '';
	}
	if ( ! isset( $cache[ $name ] ) ) {
		$file           = NB_BASE_DIR . '/assets/icons/outline/' . $name . '.svg';
		$cache[ $name ] = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}
	if ( '' === $cache[ $name ] ) {
		return '';
	}

	// Fichiers du thème (source de confiance) : on ajoute seulement les attributs.
	$attrs = 'aria-hidden="true" focusable="false"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' );
	return preg_replace( '/^<svg /', '<svg ' . $attrs . ' ', $cache[ $name ], 1 );
}

/**
 * Palette du site (thème, puis styles globaux du client) :
 * slug => array( name, color ). Noms traduits par WordPress (theme.json).
 *
 * @return array<string, array{name: string, color: string}>
 */
function nb_base_editor_palette() {
	$palette = wp_get_global_settings( array( 'color', 'palette' ) );
	$colors  = array();
	foreach ( array( 'theme', 'custom' ) as $origin ) {
		foreach ( (array) ( $palette[ $origin ] ?? array() ) as $color ) {
			if ( ! empty( $color['slug'] ) && ! empty( $color['color'] ) ) {
				$colors[ (string) $color['slug'] ] = array(
					'name'  => (string) ( $color['name'] ?? $color['slug'] ),
					'color' => (string) $color['color'],
				);
			}
		}
	}
	return $colors;
}

/**
 * Adresse de l'index des icônes pour le sélecteur de l'éditeur.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		wp_register_script( 'nb-base-editor-data', false, array(), NB_BASE_VERSION, false );
		wp_enqueue_script( 'nb-base-editor-data' );
		wp_add_inline_script(
			'nb-base-editor-data',
			'window.nbBaseEditor = ' . wp_json_encode(
				array(
					'iconsUrl'   => NB_BASE_URI . '/assets/icons/outline.json?ver=' . NB_BASE_VERSION,
					// Réglages réservés au designer dans l'éditeur (fonds des sections des contenus…).
					'isDesigner' => nb_base_is_designer(),
					// Couleurs du site (styles du client compris), pour les choix de
					// couleur des blocs : la palette native est coupée dans l'éditeur.
					'palette'    => nb_base_editor_palette(),
				)
			) . ';'
		);
	}
);
