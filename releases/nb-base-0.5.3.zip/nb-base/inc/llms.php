<?php
/**
 * llms.txt (fonctionnalité « llms-txt », désactivée par défaut) : fiche du
 * site pour les assistants IA (format llmstxt.org, Markdown), à l'adresse
 * /llms.txt : établissement (activité, adresse, zone d'intervention,
 * coordonnées, horaires, SIRET), pages, contenus structurés (réalisations,
 * produits…) avec leur description, pages légales en « Optional ».
 *
 * Généré automatiquement : le texte est gardé en cache (option
 * nb_base_llms_txt) et effacé dès qu'une donnée utilisée change (contenu
 * enregistré ou supprimé, établissement, coordonnées, nom du site…) ; il est
 * reconstruit à la consultation suivante. Contenus masqués aux moteurs
 * (noindex, inc/seo.php) et protégés par mot de passe exclus.
 *
 * Adresse : règle de réécriture native (permaliens activés) ; un vrai
 * fichier llms.txt à la racine du site a priorité.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_LLMS_CACHE_OPTION = 'nb_base_llms_txt';
const NB_BASE_LLMS_QUERY_VAR    = 'nb_base_llms';
const NB_BASE_LLMS_MAX_ITEMS    = 200;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['llms-txt'] = array(
			'group'       => 'seo',
			'label'       => __( 'llms.txt', 'nb-base' ),
			'description' => __( 'File /llms.txt presenting the business and the site’s pages to AI assistants (ChatGPT, Claude, Perplexity…). Updated automatically when the content changes.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

function nb_base_llms_active(): bool {
	return nb_base_feature_enabled( 'llms-txt' );
}

/*
 * Adresse /llms.txt : la règle existe toujours (une règle restée en base
 * après désactivation ne doit pas afficher l'accueil) ; enregistrée une
 * seule fois dans les règles du site.
 */
add_action(
	'init',
	static function () {
		add_rewrite_rule( '^llms\.txt$', 'index.php?' . NB_BASE_LLMS_QUERY_VAR . '=1', 'top' );
		$rules = get_option( 'rewrite_rules' );
		if ( get_option( 'permalink_structure' ) && is_array( $rules ) && ! isset( $rules['^llms\.txt$'] ) ) {
			flush_rewrite_rules( false );
		}
	}
);

add_filter(
	'query_vars',
	static function ( array $vars ): array {
		$vars[] = NB_BASE_LLMS_QUERY_VAR;
		return $vars;
	}
);

add_action(
	'template_redirect',
	static function () {
		if ( ! get_query_var( NB_BASE_LLMS_QUERY_VAR ) ) {
			return;
		}
		if ( ! nb_base_llms_active() || ! get_option( 'blog_public' ) ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' ); // Pour les assistants, pas pour les résultats de recherche.
		echo nb_base_llms_txt(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- texte brut (Markdown).
		exit;
	},
	0
);

/**
 * Texte du fichier (cache, reconstruit si besoin).
 */
function nb_base_llms_txt(): string {
	$key    = NB_BASE_VERSION . '|' . get_locale();
	$cached = get_option( NB_BASE_LLMS_CACHE_OPTION );
	if ( is_array( $cached ) && ( $cached['key'] ?? '' ) === $key && isset( $cached['text'] ) ) {
		return (string) $cached['text'];
	}
	$text = nb_base_in_site_locale( 'nb_base_llms_build' );
	update_option(
		NB_BASE_LLMS_CACHE_OPTION,
		array(
			'key'  => $key,
			'text' => $text,
		),
		false
	);
	return $text;
}

/**
 * Efface le cache : le fichier sera reconstruit à la consultation suivante.
 */
function nb_base_llms_flush(): void {
	delete_option( NB_BASE_LLMS_CACHE_OPTION );
}

add_action(
	'save_post',
	static function ( $post_id, $post ) {
		if ( ! wp_is_post_revision( $post_id ) && ! wp_is_post_autosave( $post_id ) && is_post_type_viewable( $post->post_type ) ) {
			nb_base_llms_flush();
		}
	},
	10,
	2
);
add_action( 'deleted_post', 'nb_base_llms_flush' );
// Métadonnées enregistrées après le contenu (API REST) : masquage, description, modèle de page.
$nb_base_llms_meta = static function ( $meta_id, $object_id, $key ) {
	if ( in_array( $key, array( '_nb_base_noindex', '_nb_base_seo_description', '_wp_page_template' ), true ) ) {
		nb_base_llms_flush();
	}
};
foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $nb_base_llms_hook ) {
	add_action( $nb_base_llms_hook, $nb_base_llms_meta, 10, 3 );
}
unset( $nb_base_llms_meta, $nb_base_llms_hook );
add_action( 'after_switch_theme', 'nb_base_llms_flush' );

/**
 * Options utilisées par le fichier : leur modification efface le cache.
 */
foreach ( array( 'blogname', 'blogdescription', 'show_on_front', 'page_on_front', 'blog_public', 'nb_base_business', 'nb_base_contact', 'nb_base_phone', 'nb_base_footer', 'nb_base_features', 'nb_base_archive_seo', 'WPLANG' ) as $nb_base_llms_option ) {
	add_action( 'update_option_' . $nb_base_llms_option, 'nb_base_llms_flush' );
	add_action( 'add_option_' . $nb_base_llms_option, 'nb_base_llms_flush' );
}
unset( $nb_base_llms_option );

/**
 * Texte sur une ligne, sans caractère de mise en forme Markdown gênant.
 */
function nb_base_llms_line( string $text ): string {
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * Lien Markdown d'un contenu, avec sa description.
 */
function nb_base_llms_item( string $title, string $url, string $description = '' ): string {
	$title = str_replace( array( '[', ']' ), array( '(', ')' ), nb_base_llms_line( $title ) );
	$line  = '- [' . ( '' !== $title ? $title : $url ) . '](' . esc_url_raw( $url ) . ')';
	return '' !== $description ? $line . ': ' . nb_base_llms_line( $description ) : $line;
}

/**
 * Contenus publiés, non masqués, sans mot de passe.
 *
 * @return WP_Post[]
 */
function nb_base_llms_posts( string $type ): array {
	return get_posts(
		array(
			'post_type'        => $type,
			'post_status'      => 'publish',
			'has_password'     => false,
			'posts_per_page'   => NB_BASE_LLMS_MAX_ITEMS,
			'orderby'          => 'page' === $type ? array( 'menu_order' => 'ASC', 'title' => 'ASC' ) : array( 'date' => 'DESC' ),
			'meta_query'       => function_exists( 'nb_base_seo_indexable_meta_query' ) ? nb_base_seo_indexable_meta_query() : array(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);
}

/**
 * Construction du fichier (dans la langue du site).
 */
function nb_base_llms_build(): string {
	$business = function_exists( 'nb_base_business' ) ? nb_base_business() : array();
	$contact  = function_exists( 'nb_base_contact_settings' ) ? nb_base_contact_settings() : array();
	$summary  = function_exists( 'nb_base_seo_site_description' ) ? nb_base_seo_site_description() : nb_base_llms_line( (string) get_bloginfo( 'description' ) );
	$describe = static fn( WP_Post $post ): string => function_exists( 'nb_base_seo_description' ) ? nb_base_seo_description( $post ) : nb_base_llms_line( (string) $post->post_excerpt );

	$out = array( '# ' . nb_base_llms_line( (string) get_bloginfo( 'name' ) ) );
	if ( '' !== $summary ) {
		$out[] = '> ' . $summary;
	}

	// Établissement.
	$facts = array();
	$types = function_exists( 'nb_base_business_types' ) ? nb_base_business_types() : array();
	if ( ! empty( $business['type'] ) && 'LocalBusiness' !== $business['type'] && isset( $types[ $business['type'] ] ) ) {
		$facts[ __( 'Activity', 'nb-base' ) ] = $types[ $business['type'] ];
	}
	$address = function_exists( 'nb_base_business_address_text' ) ? nb_base_llms_line( str_replace( "\n", ', ', nb_base_business_address_text() ) ) : '';
	if ( '' === $address && ! empty( $contact['address'] ) ) {
		$address = nb_base_llms_line( str_replace( "\n", ', ', $contact['address'] ) );
	}
	if ( '' !== $address ) {
		$countries = function_exists( 'nb_base_business_countries' ) ? nb_base_business_countries() : array();
		$country   = $countries[ $business['country'] ?? '' ] ?? '';
		$facts[ __( 'Address', 'nb-base' ) ] = $address . ( '' !== $country ? ', ' . $country : '' );
	}
	$areas = array_filter( array_map( 'trim', explode( "\n", (string) ( $business['areaServed'] ?? '' ) ) ) );
	if ( $areas ) {
		$facts[ __( 'Service area', 'nb-base' ) ] = implode( ', ', $areas );
	}
	$phone = trim( (string) get_option( 'nb_base_phone', '' ) );
	if ( '' !== $phone ) {
		$facts[ __( 'Phone', 'nb-base' ) ] = $phone;
	}
	if ( ! empty( $contact['email'] ) ) {
		$facts[ __( 'Email', 'nb-base' ) ] = $contact['email'];
	}
	// Comme sur le site : texte libre des horaires, sinon horaires de l'établissement.
	$hours = function_exists( 'nb_base_business_hours_display' ) ? nb_base_business_hours_display() : array();
	if ( $hours ) {
		$facts[ __( 'Opening hours', 'nb-base' ) ] = implode( ' · ', array_map( 'nb_base_llms_line', $hours ) );
	}
	if ( ! empty( $business['siret'] ) ) {
		$facts['SIRET'] = $business['siret'];
	}
	$social = function_exists( 'nb_base_footer_settings' ) ? array_values( array_filter( (array) ( nb_base_footer_settings()['social'] ?? array() ) ) ) : array();
	if ( $social ) {
		$facts[ __( 'Social networks', 'nb-base' ) ] = implode( ', ', $social );
	}
	if ( $facts ) {
		$out[] = implode(
			"\n",
			array_map(
				/* translators: 1: label, 2: value (llms.txt line). */
				static fn( $label, $value ) => '- ' . sprintf( __( '%1$s: %2$s', 'nb-base' ), $label, nb_base_llms_line( (string) $value ) ),
				array_keys( $facts ),
				array_values( $facts )
			)
		);
	}

	// Pages (accueil en premier), pages légales à part.
	$front = (int) get_option( 'page_on_front' );
	$pages = array();
	$legal = array();
	if ( 'page' !== get_option( 'show_on_front' ) || ! $front ) {
		$pages[] = nb_base_llms_item( __( 'Home', 'nb-base' ), home_url( '/' ) );
	}
	foreach ( nb_base_llms_posts( 'page' ) as $page ) {
		$item = nb_base_llms_item( get_the_title( $page ), (string) get_permalink( $page ), $describe( $page ) );
		if ( 'page-legal' === get_page_template_slug( $page ) ) {
			$legal[] = nb_base_llms_item( get_the_title( $page ), (string) get_permalink( $page ) );
		} elseif ( $page->ID === $front ) {
			array_unshift( $pages, $item );
		} else {
			$pages[] = $item;
		}
	}
	if ( $pages ) {
		$out[] = '## ' . __( 'Pages', 'nb-base' ) . "\n\n" . implode( "\n", $pages );
	}

	// Contenus structurés (réalisations, produits…) et articles.
	$types = get_post_types(
		array(
			'public'   => true,
			'_builtin' => false,
		),
		'objects'
	);
	$types = array_merge( array( 'post' => get_post_type_object( 'post' ) ), $types );
	foreach ( $types as $type => $object ) {
		$posts = nb_base_llms_posts( $type );
		if ( ! $posts ) {
			continue;
		}
		$items   = array();
		$archive = get_post_type_archive_link( $type );
		if ( $archive && 'post' !== $type ) {
			$seo     = function_exists( 'nb_base_archive_seo' ) ? nb_base_archive_seo( $type )['description'] : '';
			$items[] = nb_base_llms_item( $object->labels->all_items ?? $object->labels->name, $archive, $seo );
		}
		foreach ( $posts as $post ) {
			$items[] = nb_base_llms_item( get_the_title( $post ), (string) get_permalink( $post ), $describe( $post ) );
		}
		$out[] = '## ' . nb_base_llms_line( $object->labels->name ) . "\n\n" . implode( "\n", $items );
	}

	// « Optional » : section facultative selon le format llms.txt (nom imposé).
	if ( $legal ) {
		$out[] = "## Optional\n\n" . implode( "\n", $legal );
	}

	return implode( "\n\n", $out ) . "\n";
}
