<?php
/**
 * Données structurées (schema.org, JSON-LD) des contenus structurés :
 * - produit avec un prix : Product (nom, description, photos, catégorie,
 *   URL) et Offer (prix TTC, devise ISO, TVA comprise). Sans prix : rien
 *   (Google exige une offre, un avis ou une note pour un Product) ;
 * - réalisation : CreativeWork (nom, description, photos, dates, catégorie,
 *   lieu = caractéristique « location » si renseignée, auteur = le site) ;
 * - fil d'Ariane : BreadcrumbList (contenus et pages liste) ;
 * - établissement, sur toutes les pages : type d'activité choisi
 *   (LocalBusiness…) s'il a une adresse, sinon Organization (nom, logo,
 *   description, téléphone, e-mail, adresse, horaires, zone d'intervention,
 *   réseaux sociaux, SIRET : inc/business.php) ; vendeur des produits et auteur des
 *   réalisations.
 *
 * Fonctionnalité « structured-data » (désactivée par défaut). Si une
 * extension SEO (Yoast, Rank Math… : nb_base_seo_plugin()) est active, elle
 * produit déjà l'établissement et le fil d'Ariane : le thème ne produit plus
 * que les données des contenus (produit, réalisation, FAQ), dont le vendeur
 * ou l'auteur devient une simple mention du site (nom, adresse), pour éviter
 * les doublons. Données d'un type : filtre
 * « nb_base_structured_data » (tableau des nœuds du graphe, contenu courant).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['structured-data'] = array(
			'group'       => 'seo',
			'label'       => __( 'Structured data', 'nb-base' ),
			'description' => __( 'schema.org data (JSON-LD) for search engines: business, products (price), projects, FAQ, breadcrumbs. When an SEO plugin (Yoast, Rank Math…) is active, only the data of the contents is kept (products, projects, FAQ): the plugin handles the rest.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Description d'un contenu : son extrait, sinon le texte d'un de ses blocs
 * (description du produit, phrase d'introduction d'une réalisation), en
 * texte brut, 60 mots au plus.
 *
 * @param string $block Bloc de repli (nom).
 */
function nb_base_structured_description( WP_Post $post, string $block ): string {
	if ( post_password_required( $post ) ) {
		return '';
	}
	$text = has_excerpt( $post ) ? $post->post_excerpt : '';
	if ( '' === trim( $text ) ) {
		foreach ( parse_blocks( $post->post_content ) as $item ) {
			if ( $block !== $item['blockName'] ) {
				continue;
			}
			$text = isset( $item['attrs']['text'] )
				? (string) $item['attrs']['text']
				: implode( ' ', array_map( 'render_block', $item['innerBlocks'] ) );
			break;
		}
	}
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	return wp_trim_words( trim( (string) preg_replace( '/\s+/', ' ', $text ) ), 60, '…' );
}

/**
 * Adresses des photos (taille originale).
 *
 * @param int[] $ids Identifiants des images.
 * @return string[]
 */
function nb_base_structured_images( array $ids ): array {
	return array_values( array_filter( array_map( static fn( $id ) => (string) wp_get_attachment_image_url( (int) $id, 'full' ), $ids ) ) );
}

/**
 * Noms des catégories d'un contenu (taxonomie du type).
 */
function nb_base_structured_terms( int $post_id, string $taxonomy ): string {
	$terms = get_the_terms( $post_id, $taxonomy );
	return is_array( $terms ) ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '';
}

/**
 * Identifiant de l'établissement dans le graphe.
 */
function nb_base_structured_business_id(): string {
	return home_url( '/#business' );
}

/**
 * L'établissement et le fil d'Ariane sont-ils produits par le thème ? Non
 * si une extension SEO est active (elle les produit déjà).
 */
function nb_base_structured_site_nodes(): bool {
	return ! function_exists( 'nb_base_seo_plugin' ) || '' === nb_base_seo_plugin();
}

/**
 * Référence à l'établissement (vendeur, auteur) : son identifiant dans le
 * graphe, sinon (extension SEO active) une simple mention du site.
 */
function nb_base_structured_business_ref(): array {
	if ( nb_base_structured_site_nodes() ) {
		return array( '@id' => nb_base_structured_business_id() );
	}
	return array(
		'@type' => 'Organization',
		'name'  => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
		'url'   => home_url( '/' ),
	);
}

/**
 * Établissement (toutes les pages).
 */
add_filter(
	'nb_base_structured_data',
	static function ( array $graph ): array {
		if ( ! nb_base_structured_site_nodes() ) {
			return $graph;
		}
		$business = function_exists( 'nb_base_business' ) ? nb_base_business() : array();
		$address  = array_filter(
			array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => preg_replace( '/\s*\n\s*/', ', ', trim( (string) ( $business['street'] ?? '' ) ) ),
				'postalCode'      => (string) ( $business['postalCode'] ?? '' ),
				'addressLocality' => (string) ( $business['city'] ?? '' ),
			)
		);
		$has_address = isset( $address['streetAddress'] ) || isset( $address['addressLocality'] );
		$contact     = function_exists( 'nb_base_contact_settings' ) ? nb_base_contact_settings() : array();
		$social      = function_exists( 'nb_base_footer_settings' ) ? array_values( array_filter( (array) ( nb_base_footer_settings()['social'] ?? array() ) ) ) : array();
		$logo        = (int) get_option( 'site_logo' );
		$logo_url    = $logo ? (string) wp_get_attachment_image_url( $logo, 'full' ) : '';

		$node = array(
			'@type'       => $has_address ? ( $business['type'] ?? 'LocalBusiness' ) : 'Organization',
			'@id'         => nb_base_structured_business_id(),
			'name'        => wp_strip_all_tags( get_bloginfo( 'name' ) ),
			'url'         => home_url( '/' ),
			'description' => (string) ( $business['description'] ?? '' ),
			'logo'        => $logo_url,
			'image'       => $logo_url,
			'telephone'   => trim( (string) get_option( 'nb_base_phone', '' ) ),
			'email'       => (string) ( $contact['email'] ?? '' ),
			'sameAs'      => $social,
			'areaServed'  => array_values( array_filter( array_map( 'trim', explode( "\n", (string) ( $business['areaServed'] ?? '' ) ) ) ) ),
		);
		if ( $has_address ) {
			$address['addressCountry'] = (string) ( $business['country'] ?? 'FR' );
			$node['address']           = $address;
			// Horaires (établissement local seulement) : une spécification par plage.
			$days = nb_base_business_days();
			foreach ( nb_base_business_hours_groups() as $group ) {
				foreach ( $group['slots'] as $slot ) {
					$node['openingHoursSpecification'][] = array(
						'@type'     => 'OpeningHoursSpecification',
						'dayOfWeek' => array_map( static fn( $day ) => $days[ $day ], $group['days'] ),
						'opens'     => $slot['opens'],
						'closes'    => '24:00' === $slot['closes'] ? '23:59' : $slot['closes'],
					);
				}
			}
		}
		if ( ! empty( $business['siret'] ) ) {
			$node['identifier'] = array(
				'@type'      => 'PropertyValue',
				'propertyID' => 'SIRET',
				'value'      => $business['siret'],
			);
		}
		$graph[] = array_filter( $node, static fn( $value ) => '' !== $value && array() !== $value );
		return $graph;
	},
	5
);

/**
 * Fil d'Ariane (BreadcrumbList) de la page affichée.
 */
add_filter(
	'nb_base_structured_data',
	static function ( array $graph ): array {
		if ( ! nb_base_structured_site_nodes() || ( ! is_singular( array( 'nb_product', 'nb_realisation' ) ) && ! is_post_type_archive( array( 'nb_product', 'nb_realisation' ) ) ) ) {
			return $graph;
		}
		$items = nb_base_breadcrumb_items();
		if ( count( $items ) < 2 ) {
			return $graph;
		}
		$list = array();
		foreach ( $items as $i => $item ) {
			$entry = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => wp_strip_all_tags( $item['label'] ),
			);
			// Dernier élément (page courante) : adresse de la page.
			$url = '' !== $item['url'] ? $item['url'] : ( is_singular() ? get_permalink() : get_post_type_archive_link( (string) get_query_var( 'post_type' ) ) );
			if ( $url ) {
				$entry['item'] = $url;
			}
			$list[] = $entry;
		}
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $list,
		);
		return $graph;
	}
);

/**
 * Produit.
 */
add_filter(
	'nb_base_structured_data',
	static function ( array $graph ): array {
		if ( ! is_singular( 'nb_product' ) || ! function_exists( 'nb_base_product_prices' ) ) {
			return $graph;
		}
		$post   = get_post();
		$prices = nb_base_product_prices( $post->ID );
		if ( null === $prices['ttc'] ) {
			return $graph;
		}
		$url     = (string) get_permalink( $post );
		$product = array(
			'@type'       => 'Product',
			'@id'         => $url . '#product',
			'name'        => wp_strip_all_tags( get_the_title( $post ) ),
			'url'         => $url,
			'description' => nb_base_structured_description( $post, 'nb-base/product-summary' ),
			'image'       => nb_base_structured_images( nb_base_product_image_ids( $post->ID ) ),
			'category'    => nb_base_structured_terms( $post->ID, 'nb_product_cat' ),
		);
		$price             = number_format( $prices['ttc'], 2, '.', '' );
		$currency          = nb_base_products_config()['currency_code'];
		$product['offers'] = array(
			'@type'              => 'Offer',
			'url'                => $url,
			'price'              => $price,
			'priceCurrency'      => $currency,
			'seller'             => nb_base_structured_business_ref(),
			'priceSpecification' => array(
				'@type'                 => 'UnitPriceSpecification',
				'price'                 => $price,
				'priceCurrency'         => $currency,
				'valueAddedTaxIncluded' => true,
			),
		);
		$graph[] = array_filter( $product, static fn( $value ) => '' !== $value && array() !== $value );
		return $graph;
	}
);

/**
 * Réalisation.
 */
add_filter(
	'nb_base_structured_data',
	static function ( array $graph ): array {
		if ( ! is_singular( 'nb_realisation' ) ) {
			return $graph;
		}
		$post   = get_post();
		$url    = (string) get_permalink( $post );
		$values = function_exists( 'nb_base_entry_characteristic_values' ) ? nb_base_entry_characteristic_values( $post->ID ) : array();
		$work   = array(
			'@type'         => 'CreativeWork',
			'@id'           => $url . '#project',
			'name'          => wp_strip_all_tags( get_the_title( $post ) ),
			'url'           => $url,
			'description'   => nb_base_structured_description( $post, 'nb-base/entry-intro' ),
			'image'         => nb_base_structured_images( array( (int) get_post_thumbnail_id( $post ) ) ),
			'datePublished' => get_the_date( 'c', $post ),
			'dateModified'  => get_the_modified_date( 'c', $post ),
			'genre'         => nb_base_structured_terms( $post->ID, 'nb_realisation_cat' ),
			'creator'       => nb_base_structured_business_ref(),
		);
		if ( ! empty( $values['location'] ) ) {
			$work['contentLocation'] = array(
				'@type' => 'Place',
				'name'  => $values['location'],
			);
		}
		$graph[] = array_filter( $work, static fn( $value ) => '' !== $value && array() !== $value );
		return $graph;
	}
);

/**
 * Sortie dans <head> : un seul bloc JSON-LD (@graph).
 */
add_action(
	'wp_head',
	static function () {
		if ( ! nb_base_feature_enabled( 'structured-data' ) ) {
			return;
		}
		// Contenu protégé par mot de passe : aucune donnée structurée (description, photos, FAQ…).
		if ( is_singular() && post_password_required( get_queried_object() ) ) {
			return;
		}
		$graph = (array) apply_filters( 'nb_base_structured_data', array() );
		if ( ! $graph ) {
			return;
		}
		$json = wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => array_values( $graph ),
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
		);
		if ( $json ) {
			wp_print_inline_script_tag( $json, array( 'type' => 'application/ld+json' ) );
		}
	}
);
