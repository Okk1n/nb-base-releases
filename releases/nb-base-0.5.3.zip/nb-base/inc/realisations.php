<?php
/**
 * Module « Réalisations » : type de contenu, catégorie, caractéristiques et
 * mise en page figée dans l'éditeur.
 *
 * Clés internes définitives : nb_realisation (type), nb_realisation_cat
 * (catégorie), nb_characteristics (métadonnée). Noms affichés, adresses et
 * caractéristiques : réglés par le designer (page NB Base), par site.
 *
 * Fonctionnalité « realisations » (désactivée par défaut). Désactivée alors
 * que des réalisations sont publiées : le type reste enregistré (les pages
 * restent en ligne) mais disparaît de l'administration.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_REALISATION_TYPE     = 'nb_realisation';
const NB_BASE_REALISATION_TAXONOMY = 'nb_realisation_cat';
const NB_BASE_REALISATIONS_OPTION  = 'nb_base_realisations';
const NB_BASE_FLUSH_REWRITE_OPTION = 'nb_base_flush_rewrite';

/**
 * Réglages par défaut (textes traduisibles). Les adresses ne sont pas
 * traduites : elles ne doivent pas dépendre de la langue de l'utilisateur.
 */
function nb_base_realisations_defaults(): array {
	return array(
		'name'            => __( 'Projects', 'nb-base' ),
		'singular_name'   => __( 'Project', 'nb-base' ),
		'slug'            => 'realisations',
		'tax_name'        => __( 'Categories', 'nb-base' ),
		'tax_singular'    => __( 'Category', 'nb-base' ),
		'gallery_title'   => __( 'Photo gallery', 'nb-base' ),
		'related_title'   => __( 'Other projects', 'nb-base' ),
		'view_all_label'  => __( 'View all projects', 'nb-base' ),
		'card_link_label' => __( 'View project', 'nb-base' ),
		'add_new_label'   => __( 'Add a project', 'nb-base' ),
		'characteristics' => array(
			array(
				'key'   => 'location',
				'label' => __( 'Location', 'nb-base' ),
				'type'  => 'text',
			),
			array(
				'key'   => 'category',
				'label' => '',
				'type'  => 'taxonomy',
			),
			array(
				'key'   => 'budget',
				'label' => __( 'Budget', 'nb-base' ),
				'type'  => 'text',
			),
		),
	);
}

/**
 * Réglages enregistrés par le designer (seules les valeurs modifiées).
 */
function nb_base_realisations_saved(): array {
	$saved = get_option( NB_BASE_REALISATIONS_OPTION, array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Réglages effectifs : valeurs du designer, sinon valeurs par défaut.
 */
function nb_base_realisations_config(): array {
	$defaults = nb_base_realisations_defaults();
	$saved    = nb_base_realisations_saved();
	$config   = $defaults;
	foreach ( $defaults as $key => $default ) {
		if ( 'characteristics' === $key ) {
			if ( isset( $saved['characteristics'] ) && is_array( $saved['characteristics'] ) ) {
				$config['characteristics'] = $saved['characteristics'];
			}
		} elseif ( isset( $saved[ $key ] ) && '' !== trim( (string) $saved[ $key ] ) ) {
			$config[ $key ] = (string) $saved[ $key ];
		}
	}
	// Caractéristique « catégorie » sans libellé : nom de la catégorie.
	foreach ( $config['characteristics'] as $i => $item ) {
		if ( 'taxonomy' === $item['type'] && '' === trim( (string) $item['label'] ) ) {
			$config['characteristics'][ $i ]['label'] = $config['tax_singular'];
		}
	}
	return $config;
}

/**
 * Fonctionnalité.
 */
add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['realisations'] = array(
			'group'       => 'content',
			'label'       => __( 'Projects', 'nb-base' ),
			'description' => __( 'Projects content type: category, characteristics, fixed page layout (hero, introduction, content, gallery, other projects).', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Le type est-il enregistré, et visible dans l'administration ?
 *
 * @return array{registered: bool, ui: bool}
 */
function nb_base_realisations_state(): array {
	if ( nb_base_feature_enabled( 'realisations' ) ) {
		return array(
			'registered' => true,
			'ui'         => true,
		);
	}
	// wp_count_posts() renvoie 0 pour un type pas encore enregistré : requête directe.
	$published = new WP_Query(
		array(
			'post_type'              => NB_BASE_REALISATION_TYPE,
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'suppress_filters'       => true,
		)
	);
	return array(
		'registered' => (bool) $published->posts,
		'ui'         => false,
	);
}

/**
 * Mise en page figée de chaque réalisation : blocs verrouillés (ni
 * déplacement, ni suppression, ni ajout), sauf dans la zone de contenu libre
 * et dans la liste des questions de la FAQ (fonctionnalité « faq » : section
 * masquée tant qu'aucune question n'est remplie).
 * Appliquée à la création ; les réalisations existantes gardent la leur.
 */
function nb_base_realisation_template(): array {
	return array_values(
		array_filter(
			array(
				array( 'nb-base/entry-hero' ),
				array( 'nb-base/entry-intro' ),
				array( 'nb-base/entry-details' ),
				array( 'nb-base/gallery', array( 'background' => 'alt' ) ),
				nb_base_faq_template_block(),
				array( 'nb-base/entry-carousel' ),
			)
		)
	);
}

add_action(
	'init',
	static function () {
		$state = nb_base_realisations_state();
		if ( ! $state['registered'] ) {
			return;
		}
		$config = nb_base_realisations_config();

		register_post_type(
			NB_BASE_REALISATION_TYPE,
			array(
				'labels'        => array(
					'name'          => $config['name'],
					'singular_name' => $config['singular_name'],
					'menu_name'     => $config['name'],
					'all_items'     => $config['name'],
					'add_new'       => $config['add_new_label'],
					'add_new_item'  => $config['add_new_label'],
				),
				'public'        => true,
				'show_ui'       => $state['ui'],
				'show_in_menu'  => $state['ui'],
				'show_in_rest'  => true,
				'menu_position' => 21,
				'menu_icon'     => 'dashicons-portfolio',
				'has_archive'   => $config['slug'],
				'rewrite'       => array(
					'slug'       => $config['slug'],
					'with_front' => false,
				),
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
				'template'      => nb_base_realisation_template(),
				'template_lock' => 'all',
			)
		);

		register_taxonomy(
			NB_BASE_REALISATION_TAXONOMY,
			NB_BASE_REALISATION_TYPE,
			array(
				'labels'            => array(
					'name'          => $config['tax_name'],
					'singular_name' => $config['tax_singular'],
					'menu_name'     => $config['tax_name'],
				),
				// Pas de page publique par catégorie (elle doublerait la page
				// liste) : utilisée dans l'administration et comme filtre seulement.
				'public'            => false,
				'hierarchical'      => true,
				'show_ui'           => $state['ui'],
				'show_in_rest'      => true,
				'show_admin_column' => true,
			)
		);

		register_post_meta(
			NB_BASE_REALISATION_TYPE,
			NB_BASE_CHARACTERISTICS_META,
			array(
				'type'              => 'object',
				'single'            => true,
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => array(),
						'additionalProperties' => array( 'type' => 'string' ),
					),
				),
				'sanitize_callback' => static function ( $value ) {
					$clean = array();
					foreach ( (array) $value as $key => $text ) {
						$key = sanitize_key( (string) $key );
						if ( '' !== $key && is_scalar( $text ) ) {
							$clean[ $key ] = sanitize_text_field( (string) $text );
						}
					}
					return $clean;
				},
				'auth_callback'     => static fn( $allowed, $meta_key, $post_id ) => current_user_can( 'edit_post', $post_id ),
			)
		);
	}
);

/**
 * Réglages communs aux blocs des contenus structurés (inc/entries.php).
 */
add_filter(
	'nb_base_entry_settings',
	static function ( $settings, string $post_type ) {
		if ( NB_BASE_REALISATION_TYPE !== $post_type ) {
			return $settings;
		}
		$config = nb_base_realisations_config();
		return array(
			'taxonomy'        => NB_BASE_REALISATION_TAXONOMY,
			'characteristics' => $config['characteristics'],
			'gallery_title'   => $config['gallery_title'],
			'related_title'   => $config['related_title'],
			'view_all_label'  => $config['view_all_label'],
			'card_link_label' => $config['card_link_label'],
			'title_placeholder' => __( 'Project title', 'nb-base' ),
		);
	},
	10,
	2
);

/**
 * Adresses : régénérées après un changement d'adresse ou de fonctionnalité.
 */
add_action(
	'init',
	static function () {
		if ( get_option( NB_BASE_FLUSH_REWRITE_OPTION ) ) {
			delete_option( NB_BASE_FLUSH_REWRITE_OPTION );
			flush_rewrite_rules( false );
		}
	},
	100
);

add_action(
	'update_option_' . NB_BASE_FEATURES_OPTION,
	static fn() => update_option( NB_BASE_FLUSH_REWRITE_OPTION, 1, true )
);
add_action(
	'add_option_' . NB_BASE_FEATURES_OPTION,
	static fn() => update_option( NB_BASE_FLUSH_REWRITE_OPTION, 1, true )
);
add_action( 'after_switch_theme', static fn() => update_option( NB_BASE_FLUSH_REWRITE_OPTION, 1, true ) );

/**
 * Éditeur d'une réalisation : le titre est saisi directement dans le hero.
 * Le champ de titre natif, en haut du contenu, est masqué (aucune API ne
 * permet de le retirer : voir README, « Points dépendant de l'interface »).
 */
add_action(
	'enqueue_block_assets',
	static function () {
		if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || NB_BASE_REALISATION_TYPE !== $screen->post_type ) {
			return;
		}
		wp_register_style( 'nb-base-entry-editor', false, array(), NB_BASE_VERSION );
		wp_enqueue_style( 'nb-base-entry-editor' );
		wp_add_inline_style( 'nb-base-entry-editor', '.editor-visual-editor__post-title-wrapper{display:none!important}' );
	}
);

/**
 * Page NB Base : onglet « Réalisations » (designer), affiché même si la fonctionnalité est désactivée.
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		$tabs['realisations'] = array(
			'label'  => __( 'Projects', 'nb-base' ),
			'render' => 'nb_base_realisations_admin_tab',
		);
		return $tabs;
	}
);

/**
 * Contenu de l'onglet.
 */
function nb_base_realisations_admin_tab(): void {
	$config   = nb_base_realisations_config();
	$saved    = nb_base_realisations_saved();
	$defaults = nb_base_realisations_defaults();
	$fields   = array(
		'name'            => __( 'Name (plural)', 'nb-base' ),
		'singular_name'   => __( 'Name (singular)', 'nb-base' ),
		'slug'            => __( 'URL slug', 'nb-base' ),
		'tax_name'        => __( 'Category name (plural)', 'nb-base' ),
		'tax_singular'    => __( 'Category name (singular)', 'nb-base' ),
		'gallery_title'   => __( 'Gallery title', 'nb-base' ),
		'related_title'   => __( '“Other projects” title', 'nb-base' ),
		'view_all_label'  => __( '“View all” button', 'nb-base' ),
		'card_link_label' => __( 'Card link', 'nb-base' ),
		'add_new_label'   => __( '“Add” button (administration)', 'nb-base' ),
	);
	// Liste telle qu'enregistrée (libellé de catégorie vide = nom de la catégorie).
	$rows = isset( $saved['characteristics'] ) && is_array( $saved['characteristics'] ) ? $saved['characteristics'] : $defaults['characteristics'];
	for ( $i = 0; $i < 3; $i++ ) {
		$rows[] = array(
			'key'   => '',
			'label' => '',
			'type'  => 'text',
		);
	}
	?>
	<?php if ( ! nb_base_feature_enabled( 'realisations' ) ) : ?>
		<p class="description"><?php esc_html_e( 'The “Projects” feature is disabled on this site.', 'nb-base' ); ?></p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_realisations">
		<?php wp_nonce_field( 'nb_base_save_realisations' ); ?>
		<p class="description"><?php esc_html_e( 'Leave a field empty to use the default value (shown in grey). Changing a URL slug changes the address of every page concerned.', 'nb-base' ); ?></p>
		<table class="form-table" role="presentation"><tbody>
		<?php foreach ( $fields as $key => $label ) : ?>
			<tr>
				<th scope="row"><label for="nb-real-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
				<td><input type="text" class="regular-text" id="nb-real-<?php echo esc_attr( $key ); ?>" name="realisations[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) ( $saved[ $key ] ?? '' ) ); ?>" placeholder="<?php echo esc_attr( $defaults[ $key ] ); ?>"></td>
			</tr>
		<?php endforeach; ?>
		</tbody></table>

		<h3><?php esc_html_e( 'Characteristics', 'nb-base' ); ?></h3>
		<p class="description"><?php esc_html_e( 'Shown in the card next to the content of each project; an empty characteristic is not displayed. The key is permanent once saved. “Category” type: shows the project’s categories (label left empty = category name).', 'nb-base' ); ?></p>
		<table class="widefat striped" style="max-width:720px;margin-top:12px">
			<thead><tr>
				<th><?php esc_html_e( 'Label', 'nb-base' ); ?></th>
				<th><?php esc_html_e( 'Type', 'nb-base' ); ?></th>
				<th><?php esc_html_e( 'Key', 'nb-base' ); ?></th>
				<th><?php esc_html_e( 'Remove', 'nb-base' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $rows as $i => $row ) : ?>
				<tr>
					<td><input type="text" name="characteristics[<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr( $row['label'] ); ?>"<?php echo 'taxonomy' === $row['type'] ? ' placeholder="' . esc_attr( $config['tax_singular'] ) . '"' : ''; ?>></td>
					<td>
						<select name="characteristics[<?php echo (int) $i; ?>][type]">
							<option value="text" <?php selected( $row['type'], 'text' ); ?>><?php esc_html_e( 'Text', 'nb-base' ); ?></option>
							<option value="taxonomy" <?php selected( $row['type'], 'taxonomy' ); ?>><?php esc_html_e( 'Category', 'nb-base' ); ?></option>
						</select>
					</td>
					<td>
						<?php if ( '' !== $row['key'] ) : ?>
							<code><?php echo esc_html( $row['key'] ); ?></code>
							<input type="hidden" name="characteristics[<?php echo (int) $i; ?>][key]" value="<?php echo esc_attr( $row['key'] ); ?>">
						<?php else : ?>
							<span class="description"><?php esc_html_e( 'Automatic', 'nb-base' ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php if ( '' !== $row['key'] ) : ?><input type="checkbox" name="characteristics[<?php echo (int) $i; ?>][remove]" value="1" aria-label="<?php esc_attr_e( 'Remove', 'nb-base' ); ?>"><?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php nb_base_archive_seo_fields( NB_BASE_REALISATION_TYPE ); ?>
		<?php submit_button( __( 'Save projects settings', 'nb-base' ) ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_realisations',
	static function () {
		nb_base_admin_guard( 'nb_base_save_realisations' );
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nettoyé champ par champ ci-dessous.
		$input = isset( $_POST['realisations'] ) && is_array( $_POST['realisations'] ) ? wp_unslash( $_POST['realisations'] ) : array();
		$chars = isset( $_POST['characteristics'] ) && is_array( $_POST['characteristics'] ) ? wp_unslash( $_POST['characteristics'] ) : array();
		// phpcs:enable

		$previous = nb_base_realisations_saved();
		$clean    = array();
		foreach ( array_keys( nb_base_realisations_defaults() ) as $key ) {
			if ( 'characteristics' === $key ) {
				continue;
			}
			$value = sanitize_text_field( (string) ( $input[ $key ] ?? '' ) );
			if ( 'slug' === $key ) {
				$value = sanitize_title( $value );
			}
			$clean[ $key ] = $value;
		}

		$list = array();
		$used = array();
		foreach ( $chars as $row ) {
			$label = sanitize_text_field( (string) ( $row['label'] ?? '' ) );
			$type  = 'taxonomy' === ( $row['type'] ?? '' ) ? 'taxonomy' : 'text';
			$key   = sanitize_key( (string) ( $row['key'] ?? '' ) );
			if ( ! empty( $row['remove'] ) || ( '' === $key && '' === $label ) ) {
				continue;
			}
			if ( '' === $key ) {
				// Nouvelle caractéristique : clé tirée du libellé, unique.
				$base = str_replace( '-', '_', sanitize_title( remove_accents( $label ) ) );
				$base = '' !== $base ? $base : 'item';
				$key  = $base;
				for ( $n = 2; in_array( $key, $used, true ); $n++ ) {
					$key = $base . '_' . $n;
				}
			}
			if ( in_array( $key, $used, true ) ) {
				continue;
			}
			$used[] = $key;
			$list[] = array(
				'key'   => $key,
				'label' => $label,
				'type'  => $type,
			);
		}
		$clean['characteristics'] = $list;

		update_option( NB_BASE_REALISATIONS_OPTION, $clean, true );
		nb_base_archive_seo_save( NB_BASE_REALISATION_TYPE );
		if ( ( $previous['slug'] ?? '' ) !== $clean['slug'] ) {
			update_option( NB_BASE_FLUSH_REWRITE_OPTION, 1, true );
		}
		nb_base_admin_redirect( 'realisations-saved', 'realisations' );
	}
);
