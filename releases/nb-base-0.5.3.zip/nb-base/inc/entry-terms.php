<?php
/**
 * Catégories des contenus structurés (réalisations, produits…) : image et
 * texte du lien (bloc nb-base/category-grid), paramètres d'adresse des
 * filtres de la page de liste.
 *
 * Clés définitives des métadonnées de catégorie : nb_image (id de la
 * médiathèque), nb_link_text (texte), nb_order (position, glisser-déposer
 * dans la liste des catégories). La description est le champ natif.
 * Champs affichés dans l'écran de la catégorie (Réalisations → Catégories)
 * quand la fonctionnalité « category-grid » est active.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_TERM_IMAGE_META     = 'nb_image';
const NB_BASE_TERM_LINK_TEXT_META = 'nb_link_text';
const NB_BASE_TERM_ORDER_META     = 'nb_order';

/**
 * Taxonomies principales des contenus structurés enregistrés.
 *
 * @return string[]
 */
function nb_base_entry_taxonomies(): array {
	$list = array();
	foreach ( get_post_types() as $post_type ) {
		$settings = nb_base_entry_settings( $post_type );
		if ( $settings && taxonomy_exists( $settings['taxonomy'] ) ) {
			$list[] = $settings['taxonomy'];
		}
	}
	return array_values( array_unique( $list ) );
}

/**
 * Métadonnées des catégories (API REST comprise, pour l'éditeur).
 */
add_action(
	'init',
	static function () {
		foreach ( nb_base_entry_taxonomies() as $taxonomy ) {
			$auth = static fn( $allowed, $meta_key, $term_id ) => current_user_can( 'edit_term', $term_id );
			register_term_meta(
				$taxonomy,
				NB_BASE_TERM_IMAGE_META,
				array(
					'type'              => 'integer',
					'single'            => true,
					'default'           => 0,
					'show_in_rest'      => true,
					'sanitize_callback' => 'absint',
					'auth_callback'     => $auth,
				)
			);
			register_term_meta(
				$taxonomy,
				NB_BASE_TERM_LINK_TEXT_META,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => $auth,
				)
			);
			register_term_meta(
				$taxonomy,
				NB_BASE_TERM_ORDER_META,
				array(
					'type'              => 'integer',
					'single'            => true,
					'default'           => 0,
					'show_in_rest'      => true,
					'sanitize_callback' => 'absint',
					'auth_callback'     => $auth,
				)
			);
		}
	},
	20 // Après l'enregistrement des types de contenu.
);

/**
 * Champs « Image » et « Link text » de l'écran d'une catégorie.
 */
add_action(
	'admin_init',
	static function () {
		if ( ! nb_base_feature_enabled( 'category-grid' ) ) {
			return;
		}
		foreach ( nb_base_entry_taxonomies() as $taxonomy ) {
			add_action( "{$taxonomy}_add_form_fields", static fn() => nb_base_term_fields_html( 0, false ) );
			add_action( "{$taxonomy}_edit_form_fields", static fn( WP_Term $term ) => nb_base_term_fields_html( $term->term_id, true ) );
			add_action( "created_{$taxonomy}", 'nb_base_save_term_fields' );
			add_action( "edited_{$taxonomy}", 'nb_base_save_term_fields' );
		}
	}
);

/**
 * HTML des champs (écran d'ajout : blocs div ; écran de modification : lignes de tableau).
 */
function nb_base_term_fields_html( int $term_id, bool $table ): void {
	$image_id  = $term_id ? (int) get_term_meta( $term_id, NB_BASE_TERM_IMAGE_META, true ) : 0;
	$link_text = $term_id ? (string) get_term_meta( $term_id, NB_BASE_TERM_LINK_TEXT_META, true ) : '';
	$preview   = $image_id ? wp_get_attachment_image( $image_id, 'thumbnail' ) : '';

	$image_field = '<div class="nb-term-image" data-nb-term-image>'
		. '<input type="hidden" name="nb_term_image" value="' . esc_attr( $image_id ? (string) $image_id : '' ) . '" data-nb-term-image-input>'
		. '<div class="nb-term-image__preview" data-nb-term-image-preview' . ( $preview ? '' : ' hidden' ) . '>' . $preview . '</div>'
		. '<p><button type="button" class="button" data-nb-term-image-choose>' . esc_html( $image_id ? __( 'Replace', 'nb-base' ) : __( 'Choose', 'nb-base' ) ) . '</button> '
		. '<button type="button" class="button-link button-link-delete" data-nb-term-image-remove' . ( $image_id ? '' : ' hidden' ) . '>' . esc_html__( 'Remove', 'nb-base' ) . '</button></p>'
		. '</div>';
	$image_help  = esc_html__( 'Shown on the category card (category grid section).', 'nb-base' );
	$link_field  = '<input type="text" name="nb_term_link_text" id="nb-term-link-text" value="' . esc_attr( $link_text ) . '">';
	$link_help   = esc_html__( 'Link of the category card. Empty: the text set in the section.', 'nb-base' );
	$nonce       = wp_nonce_field( 'nb_base_term_fields', 'nb_term_fields_nonce', false, false );

	if ( $table ) {
		echo '<tr class="form-field"><th scope="row">' . esc_html__( 'Image', 'nb-base' ) . '</th><td>' . $image_field . '<p class="description">' . $image_help . '</p>' . $nonce . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<tr class="form-field"><th scope="row"><label for="nb-term-link-text">' . esc_html__( 'Link text', 'nb-base' ) . '</label></th><td>' . $link_field . '<p class="description">' . $link_help . '</p></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return;
	}
	echo '<div class="form-field"><label>' . esc_html__( 'Image', 'nb-base' ) . '</label>' . $image_field . '<p>' . $image_help . '</p>' . $nonce . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<div class="form-field"><label for="nb-term-link-text">' . esc_html__( 'Link text', 'nb-base' ) . '</label>' . $link_field . '<p>' . $link_help . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Enregistrement des champs (création et modification d'une catégorie).
 */
function nb_base_save_term_fields( int $term_id ): void {
	if ( ! isset( $_POST['nb_term_fields_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['nb_term_fields_nonce'] ) ), 'nb_base_term_fields' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_term', $term_id ) ) {
		return;
	}
	$image_id = absint( wp_unslash( $_POST['nb_term_image'] ?? 0 ) );
	if ( $image_id && wp_attachment_is_image( $image_id ) ) {
		update_term_meta( $term_id, NB_BASE_TERM_IMAGE_META, $image_id );
	} else {
		delete_term_meta( $term_id, NB_BASE_TERM_IMAGE_META );
	}
	$link_text = sanitize_text_field( wp_unslash( $_POST['nb_term_link_text'] ?? '' ) );
	if ( '' !== $link_text ) {
		update_term_meta( $term_id, NB_BASE_TERM_LINK_TEXT_META, $link_text );
	} else {
		delete_term_meta( $term_id, NB_BASE_TERM_LINK_TEXT_META );
	}
}

/**
 * Script du champ image (sélecteur de la médiathèque).
 */
add_action(
	'admin_enqueue_scripts',
	static function ( string $hook ) {
		if ( ! in_array( $hook, array( 'edit-tags.php', 'term.php' ), true ) || ! nb_base_feature_enabled( 'category-grid' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->taxonomy, nb_base_entry_taxonomies(), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'nb-base-term-fields', NB_BASE_URI . '/assets/js/term-fields.js', array( 'jquery' ), NB_BASE_VERSION, true );
		wp_localize_script(
			'nb-base-term-fields',
			'nbBaseTermFields',
			array(
				'title'   => __( 'Category image', 'nb-base' ),
				'button'  => __( 'Use this image', 'nb-base' ),
				'choose'  => __( 'Choose', 'nb-base' ),
				'replace' => __( 'Replace', 'nb-base' ),
			)
		);
		wp_add_inline_style( 'common', '.nb-term-image__preview img{display:block;max-width:150px;height:auto;margin-bottom:8px}' );
	}
);

/**
 * Paramètre d'adresse d'une taxonomie de filtre de la page de liste
 * (?categorie=etancheite,maconnerie) : nom singulier de la taxonomie, en
 * minuscules sans accents ; clé de la taxonomie s'il est vide ou réservé
 * par WordPress.
 */
function nb_base_entry_filter_param( string $taxonomy ): string {
	global $wp;
	$object   = get_taxonomy( $taxonomy );
	$param    = $object ? sanitize_title( nb_base_in_site_locale( static fn() => (string) $object->labels->singular_name ) ) : '';
	$reserved = $wp instanceof WP ? array_merge( $wp->public_query_vars, $wp->private_query_vars ) : array();
	if ( '' === $param || in_array( $param, $reserved, true ) || taxonomy_exists( $param ) || post_type_exists( $param ) ) {
		$param = $taxonomy;
	}
	return (string) apply_filters( 'nb_base_entry_filter_param', $param, $taxonomy );
}

/**
 * Catégories demandées dans l'adresse pour une taxonomie de filtre (slugs).
 *
 * @return string[]
 */
function nb_base_entry_filter_request( string $taxonomy ): array {
	$param = nb_base_entry_filter_param( $taxonomy );
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- lecture seule (filtres d'affichage).
	$raw = isset( $_GET[ $param ] ) && is_string( $_GET[ $param ] ) ? sanitize_text_field( wp_unslash( $_GET[ $param ] ) ) : '';
	return array_values( array_filter( array_map( 'sanitize_title', explode( ',', $raw ) ) ) );
}

/**
 * Adresse de la page de liste d'un type, filtrée sur une catégorie.
 */
function nb_base_entry_term_archive_url( string $post_type, WP_Term $term ): string {
	$archive = get_post_type_archive_link( $post_type );
	return $archive ? add_query_arg( nb_base_entry_filter_param( $term->taxonomy ), $term->slug, $archive ) : '';
}

/**
 * Catégories affichées par le bloc « Category grid » : catégories
 * principales (sans parent) ayant au moins un contenu publié, directement ou
 * dans une sous-catégorie ; dans l'ordre choisi (nb_base_sort_terms()).
 * Sous-catégories non affichées.
 *
 * @return WP_Term[]
 */
function nb_base_entry_category_items( string $post_type ): array {
	$settings = nb_base_entry_settings( $post_type );
	if ( ! $settings || ! post_type_exists( $post_type ) || ! taxonomy_exists( $settings['taxonomy'] ) ) {
		return array();
	}
	$taxonomy = $settings['taxonomy'];
	// Catégories utilisées (tous niveaux), ramenées à leur catégorie principale.
	$used = get_terms(
		array(
			'taxonomy'     => $taxonomy,
			'hide_empty'   => true,
			'hierarchical' => false,
			'fields'       => 'ids',
		)
	);
	$top = array();
	foreach ( is_array( $used ) ? $used : array() as $term_id ) {
		$ancestors = get_ancestors( (int) $term_id, $taxonomy, 'taxonomy' );
		$top[]     = $ancestors ? (int) end( $ancestors ) : (int) $term_id;
	}
	if ( ! $top ) {
		return array();
	}
	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'include'    => array_values( array_unique( $top ) ),
			'parent'     => 0,
			'hide_empty' => false,
		)
	);
	return is_array( $terms ) ? nb_base_sort_terms( $terms ) : array();
}

/**
 * Répartition équilibrée de $count cartes en lignes de 3 au maximum
 * (4 = 2 + 2, 5 = 3 + 2, 7 = 3 + 2 + 2) : nombre de cartes par ligne.
 *
 * @return int[]
 */
function nb_base_balanced_rows( int $count, int $max = 3 ): array {
	if ( $count < 1 ) {
		return array();
	}
	$rows  = (int) ceil( $count / $max );
	$base  = intdiv( $count, $rows );
	$extra = $count % $rows;
	$list  = array();
	for ( $i = 0; $i < $rows; $i++ ) {
		$list[] = $base + ( $i < $extra ? 1 : 0 );
	}
	return $list;
}

/**
 * Ordre des catégories : celui choisi par glisser-déposer (nb_order ; sans
 * ordre : après, par ordre alphabétique), chaque catégorie suivie de ses
 * sous-catégories (par ordre alphabétique). Une catégorie dont le parent
 * n'est pas dans la liste est traitée comme une catégorie principale.
 *
 * @param WP_Term[] $terms
 * @return WP_Term[]
 */
function nb_base_sort_terms( array $terms ): array {
	$terms = array_values( array_filter( $terms, static fn( $term ) => $term instanceof WP_Term ) );
	$ids   = array_map( static fn( $term ) => (int) $term->term_id, $terms );
	update_termmeta_cache( $ids );

	$children = array();
	foreach ( $terms as $term ) {
		$parent                = in_array( (int) $term->parent, $ids, true ) ? (int) $term->parent : 0;
		$children[ $parent ][] = $term;
	}
	foreach ( $children as $parent => $group ) {
		usort(
			$group,
			static function ( WP_Term $a, WP_Term $b ) use ( $parent ): int {
				if ( 0 === $parent ) {
					$order_a = (int) get_term_meta( $a->term_id, NB_BASE_TERM_ORDER_META, true );
					$order_b = (int) get_term_meta( $b->term_id, NB_BASE_TERM_ORDER_META, true );
					$order_a = $order_a > 0 ? $order_a : PHP_INT_MAX;
					$order_b = $order_b > 0 ? $order_b : PHP_INT_MAX;
					if ( $order_a !== $order_b ) {
						return $order_a <=> $order_b;
					}
				}
				return strnatcasecmp( $a->name, $b->name );
			}
		);
		$children[ $parent ] = $group;
	}

	$sorted = array();
	$walk   = static function ( int $parent ) use ( &$walk, &$sorted, $children ) {
		foreach ( $children[ $parent ] ?? array() as $term ) {
			$sorted[] = $term;
			$walk( (int) $term->term_id );
		}
	};
	$walk( 0 );
	return $sorted;
}

/**
 * La liste des catégories (Réalisations → Catégories) est-elle affichée
 * dans l'ordre choisi, sans recherche ni tri par colonne ? Seul cas où le
 * glisser-déposer est proposé.
 */
function nb_base_term_order_screen(): bool {
	global $pagenow;
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- lecture seule.
	$taxonomy = isset( $_GET['taxonomy'] ) ? sanitize_key( wp_unslash( $_GET['taxonomy'] ) ) : '';
	return is_admin() && 'edit-tags.php' === $pagenow
		&& in_array( $taxonomy, nb_base_entry_taxonomies(), true )
		&& empty( $_GET['orderby'] ) && empty( $_GET['s'] );
	// phpcs:enable
}

/**
 * Liste des catégories : dans l'ordre choisi, toutes sur une seule page
 * (le glisser-déposer ne passe pas d'une page à l'autre).
 */
add_action(
	'load-edit-tags.php',
	static function () {
		if ( ! nb_base_term_order_screen() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- lecture seule ; présence vérifiée par nb_base_term_order_screen().
		$taxonomy = sanitize_key( wp_unslash( $_GET['taxonomy'] ) );
		add_filter( "edit_{$taxonomy}_per_page", static fn() => 999 );
		add_filter(
			'get_terms',
			static function ( $terms, $taxonomies, $args ) use ( $taxonomy ) {
				if ( ! is_array( $terms ) || array( $taxonomy ) !== (array) $taxonomies || 'all' !== ( $args['fields'] ?? 'all' ) ) {
					return $terms;
				}
				return nb_base_sort_terms( $terms );
			},
			10,
			3
		);
	}
);

/**
 * Script du glisser-déposer (jQuery UI Sortable, fourni par WordPress).
 */
add_action(
	'admin_enqueue_scripts',
	static function ( string $hook ) {
		if ( 'edit-tags.php' !== $hook || ! nb_base_term_order_screen() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- lecture seule ; présence vérifiée par nb_base_term_order_screen().
		$taxonomy = sanitize_key( wp_unslash( $_GET['taxonomy'] ) );
		$object   = get_taxonomy( $taxonomy );
		if ( ! $object || ! current_user_can( $object->cap->manage_terms ) ) {
			return;
		}
		wp_enqueue_script( 'nb-base-term-order', NB_BASE_URI . '/assets/js/term-order.js', array( 'jquery', 'jquery-ui-sortable', 'wp-a11y' ), NB_BASE_VERSION, true );
		wp_localize_script(
			'nb-base-term-order',
			'nbBaseTermOrder',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'nb_base_term_order' ),
				'taxonomy' => $taxonomy,
				'hint'     => __( 'Drag and drop the main categories to change their order on the site.', 'nb-base' ),
				'saved'    => __( 'Order saved.', 'nb-base' ),
				'error'    => __( 'The order could not be saved. Reload the page and try again.', 'nb-base' ),
			)
		);
		wp_add_inline_style(
			'common',
			'#the-list.nb-term-order tr.level-0{cursor:move}'
			. '#the-list.nb-term-order .ui-sortable-helper{display:table;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.2)}'
			. '#the-list.nb-term-order .nb-term-order__placeholder{visibility:visible!important;background:#f0f6fc;outline:1px dashed #2271b1}'
			. '.nb-term-order-hint{margin:8px 0}.nb-term-order-hint.is-error{color:#d63638}'
		);
	}
);

/**
 * Enregistrement de l'ordre (Ajax) : ids des catégories principales, dans l'ordre.
 */
add_action(
	'wp_ajax_nb_base_term_order',
	static function () {
		check_ajax_referer( 'nb_base_term_order', 'nonce' );
		$taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
		$object   = get_taxonomy( $taxonomy );
		if ( ! $object || ! in_array( $taxonomy, nb_base_entry_taxonomies(), true ) || ! current_user_can( $object->cap->manage_terms ) ) {
			wp_send_json_error( null, 403 );
		}
		$ids = array_map( 'absint', (array) wp_unslash( $_POST['ids'] ?? array() ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- absint.
		$position = 0;
		foreach ( $ids as $term_id ) {
			$term = get_term( $term_id, $taxonomy );
			if ( ! $term instanceof WP_Term || 0 !== (int) $term->parent || ! current_user_can( 'edit_term', $term_id ) ) {
				continue;
			}
			update_term_meta( $term_id, NB_BASE_TERM_ORDER_META, ++$position );
		}
		wp_send_json_success();
	}
);
