<?php
/**
 * Extensions du bouton natif (core/button) via les API publiques :
 * attributs « nbShowArrow » (flèche Tabler après le texte) et « nbIcon »
 * (icône Tabler avant le texte ; vide = aucune, par défaut).
 * Le HTML enregistré par le bloc natif n'est pas modifié : flèche et icône
 * sont ajoutées au rendu (filtre render_block).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Déclare l'attribut côté serveur (cohérence avec l'éditeur).
 */
add_filter(
	'register_block_type_args',
	static function ( array $args, string $name ): array {
		if ( 'core/button' === $name ) {
			$args['attributes']['nbShowArrow'] = array(
				'type'    => 'boolean',
				'default' => false,
			);
			$args['attributes']['nbIcon']      = array(
				'type'    => 'string',
				'default' => '',
			);
		}
		return $args;
	},
	10,
	2
);

/**
 * Ajoute l'icône (avant le texte) et la flèche (après) au rendu du bouton.
 */
add_filter(
	'render_block_core/button',
	static function ( string $content, array $block ): string {
		if ( '' === trim( $content ) ) {
			return $content;
		}
		$icon  = nb_base_icon( (string) ( $block['attrs']['nbIcon'] ?? '' ), 'nb-button__icon' );
		$arrow = empty( $block['attrs']['nbShowArrow'] ) ? '' : nb_base_icon( 'arrow-right', 'nb-button__arrow' );
		if ( '' === $icon && '' === $arrow ) {
			return $content;
		}

		$tags = new WP_HTML_Tag_Processor( $content );
		if ( $tags->next_tag() ) {
			if ( $icon ) {
				$tags->add_class( 'has-nb-icon' );
			}
			if ( $arrow ) {
				$tags->add_class( 'has-nb-arrow' );
			}
		}
		$content = $tags->get_updated_html();

		// Icône juste après l'ouverture du lien (ou du <button>).
		if ( $icon ) {
			$content = (string) preg_replace( '#(<(a|button)\b[^>]*>)#', '$1' . $icon, $content, 1 );
		}
		// Flèche juste avant la fermeture du lien (ou du <button>).
		if ( $arrow ) {
			$content = (string) preg_replace( '#(</(a|button)>)(?!.*</(a|button)>)#s', $arrow . '$1', $content, 1 );
		}
		return $content;
	},
	10,
	2
);

/**
 * Style « Outline » du thème. Le style natif « outline » embarque ses propres
 * marges (CSS du cœur), qui écraseraient celles réglées globalement sur le
 * bouton ; ce style-ci hérite des réglages du bouton. Couleurs et bordure :
 * theme.json → styles.blocks.core/button.variations.nb-outline.
 */
add_action(
	'init',
	static function () {
		register_block_style(
			'core/button',
			array(
				'name'  => 'nb-outline',
				'label' => __( 'Outline', 'nb-base' ),
			)
		);
		// Style « Link » : texte seul, sans fond ni contour (cartes…).
		// Couleur : theme.json → styles.blocks.core/button.variations.nb-link.
		register_block_style(
			'core/button',
			array(
				'name'  => 'nb-link',
				'label' => __( 'Link', 'nb-base' ),
			)
		);
	}
);

/**
 * CSS de la flèche et de l'icône (site + éditeur), chargé seulement quand un bouton est présent.
 */
add_action(
	'init',
	static function () {
		wp_enqueue_block_style(
			'core/button',
			array(
				'handle' => 'nb-base-core-button',
				'src'    => NB_BASE_URI . '/assets/css/core-button.css',
				'path'   => NB_BASE_DIR . '/assets/css/core-button.css',
				'ver'    => NB_BASE_VERSION,
			)
		);
		// Mobile : boutons en pleine largeur, sauf dans les cartes (src/core-button/).
		if ( is_readable( NB_BASE_DIR . '/build-core-button/style-index.css' ) ) {
			wp_enqueue_block_style(
				'core/button',
				array(
					'handle' => 'nb-base-core-button-responsive',
					'src'    => NB_BASE_URI . '/build-core-button/style-index.css',
					'path'   => NB_BASE_DIR . '/build-core-button/style-index.css',
					'ver'    => NB_BASE_VERSION,
				)
			);
		}
	}
);
