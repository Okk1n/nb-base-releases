<?php
/**
 * Référencement technique (fonctionnalité « seo », désactivée par défaut) :
 * - titre et description propres à chaque contenu (métadonnées natives,
 *   panneau « Search engines » de la colonne de droite) ; description par
 *   défaut : extrait, phrase d'introduction, premier texte de la page ;
 * - partage sur les réseaux (Open Graph, Twitter/X) : titre, description,
 *   image (image mise en avant, photo du produit, image du hero, logo) ;
 * - « Hide from search engines » (noindex, panneau « Advanced ») : retire
 *   aussi le contenu du plan du site et du llms.txt ; noindex automatique
 *   des pages d'auteur, de date et des fichiers joints ;
 * - plan du site natif (wp-sitemap.xml) complété : date de modification,
 *   pages liste des contenus structurés, contenus masqués exclus, pas de
 *   liste des comptes (noms de connexion) ;
 * - adresse canonique des pages liste (les filtres « ?categorie= » ne
 *   créent pas de doublons) ;
 * - robots.txt : réglages du designer (NB Base → Search engines) ;
 * - titre et description des pages liste des contenus structurés : réglés
 *   par le designer dans l'onglet du type (NB Base), option
 *   « nb_base_archive_seo » (type => titre, description) ;
 * - validation de propriété (Google Search Console, Bing Webmaster Tools) :
 *   codes collés par le designer (NB Base → Search engines), balises
 *   affichées dès qu'un code est saisi, même fonctionnalité coupée ou
 *   extension SEO active (sinon l'outil perdrait la validation).
 *
 * Tout est coupé si une extension de référencement est active
 * (nb_base_seo_plugin()) : elle gère déjà ces points, pour éviter les
 * doublons.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_SEO_TITLE_META       = '_nb_base_seo_title';
const NB_BASE_SEO_DESCRIPTION_META = '_nb_base_seo_description';
const NB_BASE_SEO_NOINDEX_META     = '_nb_base_noindex';
const NB_BASE_ROBOTS_OPTION        = 'nb_base_robots';
const NB_BASE_ARCHIVE_SEO_OPTION   = 'nb_base_archive_seo';
const NB_BASE_VERIFICATION_OPTION  = 'nb_base_verification';

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['seo'] = array(
			'group'       => 'seo',
			'label'       => __( 'Search engine optimization', 'nb-base' ),
			'description' => __( 'Title and description of each page, social sharing (Open Graph), “Hide from search engines” option, complete sitemap, robots.txt settings. Turned off automatically when an SEO plugin (Yoast, Rank Math…) is active.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Nom de l'extension de référencement active, ou chaîne vide.
 */
function nb_base_seo_plugin(): string {
	$plugins = array(
		'WPSEO_VERSION'              => 'Yoast SEO',
		'RANK_MATH_VERSION'          => 'Rank Math',
		'AIOSEO_VERSION'             => 'All in One SEO',
		'SEOPRESS_VERSION'           => 'SEOPress',
		'THE_SEO_FRAMEWORK_VERSION'  => 'The SEO Framework',
		'SLIM_SEO_VER'               => 'Slim SEO',
		'SQ_VERSION'                 => 'Squirrly SEO',
	);
	foreach ( $plugins as $constant => $name ) {
		if ( defined( $constant ) ) {
			return $name;
		}
	}
	/**
	 * Autre extension de référencement : renvoyer son nom.
	 */
	return (string) apply_filters( 'nb_base_seo_plugin', '' );
}

/**
 * Le référencement du thème est-il en service ?
 */
function nb_base_seo_active(): bool {
	return nb_base_feature_enabled( 'seo' ) && '' === nb_base_seo_plugin();
}

/**
 * Titre et description de la page liste d'un type (valeurs du designer,
 * vides = valeurs par défaut).
 *
 * @return array{title: string, description: string}
 */
function nb_base_archive_seo( string $post_type ): array {
	$all   = get_option( NB_BASE_ARCHIVE_SEO_OPTION, array() );
	$saved = is_array( $all ) && isset( $all[ $post_type ] ) && is_array( $all[ $post_type ] ) ? $all[ $post_type ] : array();
	return array(
		'title'       => trim( (string) ( $saved['title'] ?? '' ) ),
		'description' => trim( (string) ( $saved['description'] ?? '' ) ),
	);
}

/**
 * Champs « Search engines » de l'onglet d'un type (dans son formulaire).
 * Masqués si le référencement du thème est coupé (les valeurs restent).
 */
function nb_base_archive_seo_fields( string $post_type ): void {
	$plugin = nb_base_seo_plugin();
	$object = get_post_type_object( $post_type );
	?>
	<h3><?php esc_html_e( 'List page: search engines', 'nb-base' ); ?></h3>
	<?php if ( '' !== $plugin ) : ?>
		<p class="description">
			<?php
			/* translators: %s: SEO plugin name. */
			echo esc_html( sprintf( __( '%s is active: set the title and description of this page in its settings.', 'nb-base' ), $plugin ) );
			?>
		</p>
	<?php elseif ( ! nb_base_feature_enabled( 'seo' ) ) : ?>
		<p class="description"><?php esc_html_e( 'Available when the “Search engine optimization” feature is enabled.', 'nb-base' ); ?></p>
	<?php else : ?>
		<?php $values = nb_base_archive_seo( $post_type ); ?>
		<input type="hidden" name="archive_seo[present]" value="1">
		<table class="form-table" role="presentation"><tbody>
			<tr>
				<th scope="row"><label for="nb-archive-seo-title"><?php esc_html_e( 'Title', 'nb-base' ); ?></label></th>
				<td>
					<input type="text" class="large-text" id="nb-archive-seo-title" name="archive_seo[title]" maxlength="200" value="<?php echo esc_attr( $values['title'] ); ?>" placeholder="<?php echo esc_attr( $object ? wp_strip_all_tags( (string) $object->labels->name ) : '' ); ?>">
					<p class="description"><?php esc_html_e( 'Shown in search results and the browser tab. Empty: the name of the content type.', 'nb-base' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nb-archive-seo-description"><?php esc_html_e( 'Description', 'nb-base' ); ?></label></th>
				<td>
					<textarea class="large-text" rows="3" id="nb-archive-seo-description" name="archive_seo[description]" maxlength="400"><?php echo esc_textarea( $values['description'] ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Shown under the title in search results (about 150 characters). Empty: none.', 'nb-base' ); ?></p>
				</td>
			</tr>
		</tbody></table>
	<?php endif; ?>
	<?php
}

/**
 * Enregistrement des champs ci-dessus (appelé par l'enregistrement de
 * l'onglet du type, droits et nonce déjà vérifiés).
 */
function nb_base_archive_seo_save( string $post_type ): void {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce vérifié par l'appelant, nettoyé ci-dessous.
	$input = isset( $_POST['archive_seo'] ) && is_array( $_POST['archive_seo'] ) ? wp_unslash( $_POST['archive_seo'] ) : array();
	if ( empty( $input['present'] ) ) {
		return; // Champs non affichés : valeurs conservées.
	}
	$all = get_option( NB_BASE_ARCHIVE_SEO_OPTION, array() );
	$all = is_array( $all ) ? $all : array();
	$all[ $post_type ] = array(
		'title'       => mb_substr( sanitize_text_field( (string) ( $input['title'] ?? '' ) ), 0, 200 ),
		'description' => mb_substr( sanitize_textarea_field( (string) ( $input['description'] ?? '' ) ), 0, 400 ),
	);
	update_option( NB_BASE_ARCHIVE_SEO_OPTION, $all, false );
}

/**
 * Types de contenu concernés : publics, gérés dans l'éditeur, sauf les
 * fichiers joints.
 *
 * @return string[]
 */
function nb_base_seo_post_types(): array {
	$types = get_post_types(
		array(
			'public'       => true,
			'show_in_rest' => true,
		)
	);
	unset( $types['attachment'] );
	return array_values( array_filter( $types, static fn( $type ) => post_type_supports( $type, 'custom-fields' ) ) );
}

/**
 * Le contenu est-il masqué aux moteurs de recherche ?
 */
function nb_base_seo_noindex( int $post_id ): bool {
	return (bool) get_post_meta( $post_id, NB_BASE_SEO_NOINDEX_META, true );
}

/**
 * Condition de requête : contenus non masqués (plan du site, llms.txt).
 */
function nb_base_seo_indexable_meta_query(): array {
	return array(
		'relation' => 'OR',
		array(
			'key'     => NB_BASE_SEO_NOINDEX_META,
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => NB_BASE_SEO_NOINDEX_META,
			'value'   => '1',
			'compare' => '!=',
		),
	);
}

/**
 * Texte brut sur une ligne, coupé à la fin d'un mot.
 */
function nb_base_seo_plain( string $text, int $max = 160 ): string {
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut   = mb_substr( $text, 0, $max - 1 );
	$space = mb_strrpos( $cut, ' ' );
	return rtrim( false !== $space && $space > $max / 2 ? mb_substr( $cut, 0, $space ) : $cut, ' ,;:.' ) . '…';
}

/**
 * Premier texte suffisamment long des blocs (attribut « text »,
 * « description »… des blocs du thème), en profondeur.
 *
 * @param array $blocks Blocs analysés (parse_blocks()).
 */
function nb_base_seo_first_text( array $blocks ): string {
	foreach ( $blocks as $block ) {
		foreach ( array( 'text', 'description', 'content' ) as $key ) {
			$value = $block['attrs'][ $key ] ?? '';
			if ( is_string( $value ) && mb_strlen( nb_base_seo_plain( $value, 1000 ) ) >= 50 ) {
				return $value;
			}
		}
		if ( 'core/paragraph' === $block['blockName'] && mb_strlen( nb_base_seo_plain( (string) $block['innerHTML'], 1000 ) ) >= 50 ) {
			return (string) $block['innerHTML'];
		}
		$inner = nb_base_seo_first_text( $block['innerBlocks'] ?? array() );
		if ( '' !== $inner ) {
			return $inner;
		}
	}
	return '';
}

/**
 * Description d'un contenu : celle saisie, sinon l'extrait, la phrase
 * d'introduction (contenus structurés), le premier texte de la page ;
 * page d'accueil : description de l'établissement, sinon slogan du site.
 */
function nb_base_seo_description( WP_Post $post ): string {
	// Contenu protégé par mot de passe : rien de son texte dans les balises.
	if ( post_password_required( $post ) ) {
		return '';
	}
	$custom = trim( (string) get_post_meta( $post->ID, NB_BASE_SEO_DESCRIPTION_META, true ) );
	if ( '' !== $custom ) {
		return nb_base_seo_plain( $custom, 400 );
	}
	$text = has_excerpt( $post ) ? $post->post_excerpt : '';
	if ( '' === trim( $text ) ) {
		/**
		 * Bloc d'introduction d'un type de contenu (description par défaut).
		 */
		$intro = (array) apply_filters(
			'nb_base_seo_intro_blocks',
			array(
				'nb_product'     => 'nb-base/product-summary',
				'nb_realisation' => 'nb-base/entry-intro',
			)
		);
		if ( isset( $intro[ $post->post_type ] ) && function_exists( 'nb_base_structured_description' ) ) {
			$text = nb_base_structured_description( $post, $intro[ $post->post_type ] );
		}
	}
	if ( '' === trim( $text ) ) {
		$text = nb_base_seo_first_text( parse_blocks( $post->post_content ) );
	}
	if ( '' === trim( $text ) && (int) get_option( 'page_on_front' ) === $post->ID ) {
		$text = nb_base_seo_site_description();
	}
	return nb_base_seo_plain( $text );
}

/**
 * Description du site : celle de l'établissement, sinon le slogan.
 */
function nb_base_seo_site_description(): string {
	$business = function_exists( 'nb_base_business' ) ? (string) nb_base_business()['description'] : '';
	return nb_base_seo_plain( '' !== trim( $business ) ? $business : (string) get_bloginfo( 'description' ) );
}

/**
 * Image de partage d'un contenu : image mise en avant, première photo du
 * produit, image du hero (ou d'un autre bloc), sinon 0.
 */
function nb_base_seo_image_id( WP_Post $post ): int {
	if ( post_password_required( $post ) ) {
		return 0;
	}
	$id = (int) get_post_thumbnail_id( $post );
	if ( ! $id && function_exists( 'nb_base_product_image_ids' ) && 'nb_product' === $post->post_type ) {
		$id = (int) ( nb_base_product_image_ids( $post->ID )[0] ?? 0 );
	}
	if ( ! $id ) {
		$find = static function ( array $blocks ) use ( &$find ): int {
			foreach ( $blocks as $block ) {
				if ( ! empty( $block['attrs']['imageId'] ) ) {
					return (int) $block['attrs']['imageId'];
				}
				$inner = $find( $block['innerBlocks'] ?? array() );
				if ( $inner ) {
					return $inner;
				}
			}
			return 0;
		};
		$id = $find( parse_blocks( $post->post_content ) );
	}
	return $id && wp_attachment_is_image( $id ) ? $id : 0;
}

/**
 * Données de la page affichée pour les balises de partage.
 *
 * @return array{title: string, description: string, url: string, image: int, type: string}
 */
function nb_base_seo_current(): array {
	$data = array(
		'title'       => wp_strip_all_tags( get_bloginfo( 'name' ) ),
		'description' => '',
		'url'         => '',
		'image'       => 0,
		'type'        => 'website',
	);
	if ( is_singular() ) {
		$post                = get_queried_object();
		$custom              = trim( (string) get_post_meta( $post->ID, NB_BASE_SEO_TITLE_META, true ) );
		$data['title']       = '' !== $custom ? $custom : ( is_front_page() ? $data['title'] : wp_strip_all_tags( get_the_title( $post ) ) );
		$data['description'] = nb_base_seo_description( $post );
		$data['url']         = (string) get_permalink( $post );
		$data['image']       = nb_base_seo_image_id( $post );
		$data['type']        = is_front_page() ? 'website' : 'article';
	} elseif ( is_post_type_archive() ) {
		$type                = get_queried_object();
		$custom              = nb_base_archive_seo( (string) ( $type->name ?? '' ) );
		$data['title']       = '' !== $custom['title'] ? $custom['title'] : wp_strip_all_tags( post_type_archive_title( '', false ) );
		$data['description'] = nb_base_seo_plain( '' !== $custom['description'] ? $custom['description'] : (string) ( $type->description ?? '' ), 400 );
		$data['url']         = (string) get_post_type_archive_link( $type->name );
	} elseif ( is_front_page() || is_home() ) {
		$data['description'] = nb_base_seo_site_description();
		$data['url']         = home_url( '/' );
	}
	if ( ! $data['image'] ) {
		$data['image'] = (int) get_option( 'site_logo' );
	}
	return $data;
}

/*
 * Métadonnées des contenus (titre, description, masquage), modifiables par
 * ceux qui peuvent modifier le contenu.
 */
add_action(
	'init',
	static function () {
		if ( ! nb_base_seo_active() ) {
			return;
		}
		$auth = static fn( $allowed, $key, $post_id ) => current_user_can( 'edit_post', (int) $post_id );
		foreach ( nb_base_seo_post_types() as $type ) {
			register_post_meta(
				$type,
				NB_BASE_SEO_TITLE_META,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => static fn( $value ) => mb_substr( sanitize_text_field( (string) $value ), 0, 200 ),
					'auth_callback'     => $auth,
				)
			);
			register_post_meta(
				$type,
				NB_BASE_SEO_DESCRIPTION_META,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => static fn( $value ) => mb_substr( sanitize_textarea_field( (string) $value ), 0, 400 ),
					'auth_callback'     => $auth,
				)
			);
			register_post_meta(
				$type,
				NB_BASE_SEO_NOINDEX_META,
				array(
					'type'          => 'boolean',
					'single'        => true,
					'default'       => false,
					'show_in_rest'  => true,
					'auth_callback' => $auth,
				)
			);
		}
	},
	99
);

/**
 * Panneaux de la colonne de droite (src/editor/seo-panel.js) : réglages.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		if ( ! nb_base_seo_active() ) {
			return;
		}
		wp_add_inline_script(
			'nb-base-editor',
			'window.nbBaseSeo = ' . wp_json_encode(
				array(
					'postTypes' => nb_base_seo_post_types(),
					'siteName'  => wp_strip_all_tags( get_bloginfo( 'name' ) ),
					'frontPage' => (int) get_option( 'page_on_front' ),
				)
			) . ';',
			'before'
		);
	},
	20
);

/**
 * Titre de la page (onglet du navigateur, résultats de recherche).
 */
add_filter(
	'pre_get_document_title',
	static function ( $title ) {
		if ( ! nb_base_seo_active() ) {
			return $title;
		}
		if ( is_post_type_archive() ) {
			$type = get_queried_object();
			return nb_base_archive_seo( (string) ( $type->name ?? '' ) )['title'] ?: $title;
		}
		if ( ! is_singular() ) {
			return $title;
		}
		$custom = trim( (string) get_post_meta( get_queried_object_id(), NB_BASE_SEO_TITLE_META, true ) );
		return '' !== $custom ? $custom : $title;
	}
);

/**
 * Description, adresse canonique des pages liste, balises de partage.
 */
add_action(
	'wp_head',
	static function () {
		if ( ! nb_base_seo_active() || is_404() || is_search() ) {
			return;
		}
		$data = nb_base_seo_current();
		$tags = array();
		if ( '' !== $data['description'] ) {
			$tags[] = '<meta name="description" content="' . esc_attr( $data['description'] ) . '">';
		}
		// Pages liste : une seule adresse, quels que soient les filtres (le reste : WordPress).
		if ( is_post_type_archive() && '' !== $data['url'] ) {
			$tags[] = '<link rel="canonical" href="' . esc_url( $data['url'] ) . '">';
		}

		$og = array(
			'og:locale'      => get_locale(),
			'og:type'        => $data['type'],
			'og:site_name'   => wp_strip_all_tags( get_bloginfo( 'name' ) ),
			'og:title'       => $data['title'],
			'og:description' => $data['description'],
			'og:url'         => $data['url'],
		);
		$image = $data['image'] ? wp_get_attachment_image_src( $data['image'], 'full' ) : false;
		if ( $image ) {
			$og['og:image']        = $image[0];
			$og['og:image:width']  = (string) $image[1];
			$og['og:image:height'] = (string) $image[2];
			$og['og:image:alt']    = trim( (string) get_post_meta( $data['image'], '_wp_attachment_image_alt', true ) );
		}
		foreach ( array_filter( $og, static fn( $value ) => '' !== $value ) as $property => $value ) {
			$url    = in_array( $property, array( 'og:url', 'og:image' ), true );
			$tags[] = '<meta property="' . esc_attr( $property ) . '" content="' . ( $url ? esc_url( $value ) : esc_attr( $value ) ) . '">';
		}
		$tags[] = '<meta name="twitter:card" content="' . ( $image ? 'summary_large_image' : 'summary' ) . '">';

		echo "\n" . implode( "\n", $tags ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- échappé ci-dessus.
	},
	1
);

/**
 * Directives aux robots : contenus masqués ; pages d'auteur, de date et
 * fichiers joints (doublons sans intérêt). Les liens restent suivis.
 */
add_filter(
	'wp_robots',
	static function ( array $robots ): array {
		if ( ! nb_base_seo_active() ) {
			return $robots;
		}
		$hidden = ( is_singular() && nb_base_seo_noindex( get_queried_object_id() ) ) || is_author() || is_date() || is_attachment();
		if ( $hidden ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['max-image-preview'] );
		}
		return $robots;
	}
);

/*
 * Plan du site (wp-sitemap.xml).
 */

// Pas de liste des comptes : elle dévoile les noms de connexion, sans intérêt pour les moteurs.
add_filter(
	'wp_sitemaps_add_provider',
	static fn( $provider, string $name ) => ( 'users' === $name && nb_base_seo_active() ) ? false : $provider,
	10,
	2
);

// Contenus masqués exclus.
add_filter(
	'wp_sitemaps_posts_query_args',
	static function ( array $args ): array {
		if ( nb_base_seo_active() ) {
			$args['meta_query'] = nb_base_seo_indexable_meta_query(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}
		return $args;
	}
);

// Date de dernière modification.
add_filter(
	'wp_sitemaps_posts_entry',
	static function ( array $entry, WP_Post $post ): array {
		if ( nb_base_seo_active() ) {
			$entry['lastmod'] = get_post_modified_time( DATE_W3C, true, $post );
		}
		return $entry;
	},
	10,
	2
);

/**
 * Pages liste des types de contenu (réalisations, produits…), absentes du
 * plan du site natif : fournisseur « archives » (API publique des plans du
 * site), date = dernière modification d'un de leurs contenus.
 */
class NB_Base_Sitemaps_Archives extends WP_Sitemaps_Provider {

	public function __construct() {
		$this->name        = 'archives';
		$this->object_type = 'archive';
	}

	/**
	 * Types de contenu ayant une page liste et au moins un contenu publié.
	 *
	 * @return string[]
	 */
	private function types(): array {
		$types = get_post_types(
			array(
				'public'      => true,
				'has_archive' => true,
			)
		);
		return array_values( array_filter( $types, static fn( $type ) => (int) ( wp_count_posts( $type )->publish ?? 0 ) > 0 ) );
	}

	public function get_url_list( $page_num, $object_subtype = '' ) {
		$list = array();
		foreach ( $this->types() as $type ) {
			$url = get_post_type_archive_link( $type );
			if ( ! $url ) {
				continue;
			}
			$latest = get_posts(
				array(
					'post_type'      => $type,
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'orderby'        => 'modified',
					'order'          => 'DESC',
					'has_password'   => false,
					'no_found_rows'  => true,
				)
			);
			$entry = array( 'loc' => $url );
			if ( $latest ) {
				$entry['lastmod'] = get_post_modified_time( DATE_W3C, true, $latest[0] );
			}
			$list[] = $entry;
		}
		return $list;
	}

	public function get_max_num_pages( $object_subtype = '' ) {
		return $this->types() ? 1 : 0;
	}
}

add_action(
	'init',
	static function () {
		if ( nb_base_seo_active() && function_exists( 'wp_register_sitemap_provider' ) ) {
			wp_register_sitemap_provider( 'archives', new NB_Base_Sitemaps_Archives() );
		}
	}
);

/*
 * robots.txt (fichier virtuel de WordPress ; sans effet si un vrai fichier
 * robots.txt existe à la racine du site).
 */

/**
 * Robots d'entraînement des IA (bloquables). Les robots qui citent le site
 * dans les réponses des assistants (OAI-SearchBot, ChatGPT-User,
 * Claude-SearchBot, PerplexityBot…) et Google / Bing ne sont pas concernés.
 *
 * @return string[]
 */
function nb_base_robots_ai_training_bots(): array {
	return array( 'GPTBot', 'ClaudeBot', 'Google-Extended', 'Applebot-Extended', 'CCBot', 'meta-externalagent', 'Bytespider' );
}

function nb_base_robots_defaults(): array {
	return array(
		'blockAiTraining' => false,
		'rules'           => '',
	);
}

/**
 * Réglages nettoyés. Règles supplémentaires : lignes « Directive: valeur »
 * ou commentaires « # … » seulement.
 *
 * @param mixed $value Valeur enregistrée ou reçue.
 */
function nb_base_sanitize_robots( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$lines = array();
	foreach ( preg_split( '/\R/', wp_strip_all_tags( (string) ( $value['rules'] ?? '' ) ) ) as $line ) {
		$line = trim( (string) preg_replace( '/[\x00-\x1F\x7F]/', '', $line ) );
		if ( '' === $line || preg_match( '/^(#.*|[A-Za-z][A-Za-z-]*:\s*\S.*)$/', $line ) ) {
			$lines[] = $line;
		}
	}
	return array(
		'blockAiTraining' => ! empty( $value['blockAiTraining'] ),
		'rules'           => trim( implode( "\n", array_slice( $lines, 0, 200 ) ) ),
	);
}

function nb_base_robots_settings(): array {
	return nb_base_sanitize_robots( get_option( NB_BASE_ROBOTS_OPTION, array() ) );
}

add_filter(
	'robots_txt',
	static function ( $output, $public ) {
		if ( ! nb_base_seo_active() || ! $public ) {
			return $output; // Site masqué (Réglages → Lecture) : « Disallow: / » de WordPress.
		}
		$settings = nb_base_robots_settings();
		$extra    = array();
		if ( $settings['blockAiTraining'] ) {
			$agents  = array_map( static fn( $bot ) => 'User-agent: ' . $bot, nb_base_robots_ai_training_bots() );
			$extra[] = "# AI training\n" . implode( "\n", $agents ) . "\nDisallow: /";
		}
		if ( '' !== $settings['rules'] ) {
			$extra[] = $settings['rules'];
		}
		return $extra ? rtrim( (string) $output ) . "\n\n" . implode( "\n\n", $extra ) . "\n" : $output;
	},
	20,
	2
);

/**
 * Outils de validation : clé => (libellé, nom de la balise meta).
 *
 * @return array<string, array{label: string, meta: string}>
 */
function nb_base_verification_tools(): array {
	return array(
		'google' => array(
			'label' => 'Google Search Console',
			'meta'  => 'google-site-verification',
		),
		'bing'   => array(
			'label' => 'Bing Webmaster Tools',
			'meta'  => 'msvalidate.01',
		),
	);
}

/**
 * Codes de validation nettoyés. Accepte le code seul ou la balise entière
 * collée telle quelle (on en garde la valeur de « content »).
 *
 * @param mixed $value Valeur brute.
 * @return array<string, string>
 */
function nb_base_sanitize_verification( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$clean = array();
	foreach ( array_keys( nb_base_verification_tools() ) as $key ) {
		$code = trim( (string) ( $value[ $key ] ?? '' ) );
		if ( preg_match( '/content\s*=\s*["\']([^"\']*)["\']/i', $code, $match ) ) {
			$code = trim( $match[1] );
		}
		$clean[ $key ] = preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $code ) ? $code : '';
	}
	return $clean;
}

function nb_base_verification_settings(): array {
	return nb_base_sanitize_verification( get_option( NB_BASE_VERIFICATION_OPTION, array() ) );
}

/**
 * Balises de validation (page d'accueil suffit, mais présentes partout :
 * sans effet ailleurs).
 */
add_action(
	'wp_head',
	static function () {
		$codes = nb_base_verification_settings();
		foreach ( nb_base_verification_tools() as $key => $tool ) {
			if ( '' !== $codes[ $key ] ) {
				echo '<meta name="' . esc_attr( $tool['meta'] ) . '" content="' . esc_attr( $codes[ $key ] ) . '">' . "\n";
			}
		}
	},
	1
);

add_action(
	'admin_post_nb_base_save_verification',
	static function () {
		nb_base_admin_guard( 'nb_base_save_verification' );
		$value = isset( $_POST['verification'] ) && is_array( $_POST['verification'] ) ? wp_unslash( $_POST['verification'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nettoyé par nb_base_sanitize_verification().
		update_option( NB_BASE_VERIFICATION_OPTION, nb_base_sanitize_verification( $value ), false );
		nb_base_admin_redirect( 'seo-saved', 'seo' );
	}
);

/*
 * Onglet « Search engines » de la page NB Base (designer).
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		if ( nb_base_feature_enabled( 'seo' ) || nb_base_feature_enabled( 'llms-txt' ) ) {
			$tabs['seo'] = array(
				'label'  => __( 'Search engines', 'nb-base' ),
				'render' => 'nb_base_seo_admin_tab',
			);
		}
		return $tabs;
	}
);

function nb_base_seo_admin_tab(): void {
	$plugin   = nb_base_seo_plugin();
	$settings = nb_base_robots_settings();
	?>
	<?php if ( '' !== $plugin ) : ?>
		<div class="notice notice-info inline"><p>
			<?php
			/* translators: %s: SEO plugin name. */
			echo esc_html( sprintf( __( '%s is active: it handles titles, descriptions, social sharing, the sitemap and robots.txt. The theme’s equivalents are turned off.', 'nb-base' ), $plugin ) );
			if ( nb_base_feature_enabled( 'structured-data' ) ) {
				echo ' ' . esc_html__( 'Structured data: the theme only adds the data of the contents (products, projects, FAQ).', 'nb-base' );
			}
			?>
		</p></div>
	<?php endif; ?>
	<?php if ( ! get_option( 'blog_public' ) ) : ?>
		<div class="notice notice-warning inline"><p>
			<?php esc_html_e( 'Search engines are asked not to index this site.', 'nb-base' ); ?>
			<a href="<?php echo esc_url( admin_url( 'options-reading.php' ) ); ?>"><?php esc_html_e( 'Settings → Reading', 'nb-base' ); ?></a>
		</p></div>
	<?php endif; ?>

	<h3><?php esc_html_e( 'Files for search engines and AI', 'nb-base' ); ?></h3>
	<ul>
		<?php if ( function_exists( 'get_sitemap_url' ) && get_sitemap_url( 'index' ) ) : ?>
			<li><a href="<?php echo esc_url( (string) get_sitemap_url( 'index' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Sitemap', 'nb-base' ); ?></a></li>
		<?php endif; ?>
		<li><a href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank" rel="noopener">robots.txt</a></li>
		<?php if ( function_exists( 'nb_base_llms_active' ) && nb_base_llms_active() ) : ?>
			<li><a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener">llms.txt</a></li>
		<?php endif; ?>
	</ul>
	<?php foreach ( array( 'robots.txt', 'llms.txt' ) as $file ) : ?>
		<?php if ( file_exists( ABSPATH . $file ) ) : ?>
			<div class="notice notice-warning inline"><p>
				<?php
				/* translators: %s: file name. */
				echo esc_html( sprintf( __( 'A %s file exists at the root of the site: it replaces the one generated by the theme. Delete it to use these settings.', 'nb-base' ), $file ) );
				?>
			</p></div>
		<?php endif; ?>
	<?php endforeach; ?>

	<h3><?php esc_html_e( 'Site verification', 'nb-base' ); ?></h3>
	<p class="description"><?php esc_html_e( 'To prove to Google or Bing that you own the site without access to the domain name: choose the “HTML tag” method in the tool and paste the code (or the whole tag) here.', 'nb-base' ); ?></p>
	<?php $nb_codes = nb_base_verification_settings(); ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_verification">
		<?php wp_nonce_field( 'nb_base_save_verification' ); ?>
		<table class="form-table" role="presentation"><tbody>
			<?php foreach ( nb_base_verification_tools() as $key => $tool ) : ?>
				<tr>
					<th scope="row"><label for="nb-verification-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $tool['label'] ); ?></label></th>
					<td><input type="text" class="large-text code" id="nb-verification-<?php echo esc_attr( $key ); ?>" name="verification[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $nb_codes[ $key ] ); ?>" placeholder="<?php echo esc_attr( '<meta name="' . $tool['meta'] . '" content="…">' ); ?>"></td>
				</tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php submit_button( __( 'Save', 'nb-base' ), 'primary', 'submit-verification' ); ?>
	</form>

	<?php if ( nb_base_feature_enabled( 'seo' ) ) : ?>
		<h3>robots.txt</h3>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="nb_base_save_robots">
			<?php wp_nonce_field( 'nb_base_save_robots' ); ?>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'AI training', 'nb-base' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="robots[blockAiTraining]" value="1" <?php checked( $settings['blockAiTraining'] ); ?>>
							<?php esc_html_e( 'Block the robots that collect content to train AI models', 'nb-base' ); ?>
						</label>
						<p class="description">
							<?php
							/* translators: %s: list of robot names. */
							echo esc_html( sprintf( __( 'Robots blocked: %s. The site remains visible in Google, Bing and in the answers of AI assistants (ChatGPT, Claude, Perplexity…), whose search robots are not blocked.', 'nb-base' ), implode( ', ', nb_base_robots_ai_training_bots() ) ) );
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nb-robots-rules"><?php esc_html_e( 'Additional rules', 'nb-base' ); ?></label></th>
					<td>
						<textarea id="nb-robots-rules" class="large-text code" rows="6" name="robots[rules]" placeholder="User-agent: *&#10;Disallow: /private/"><?php echo esc_textarea( $settings['rules'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Added at the end of the file. Only “Directive: value” lines and comments (#) are kept. The default rules and the sitemap address are always present.', 'nb-base' ); ?></p>
					</td>
				</tr>
			</tbody></table>
			<?php submit_button( __( 'Save', 'nb-base' ) ); ?>
		</form>
	<?php endif; ?>
	<?php
}

add_action(
	'admin_post_nb_base_save_robots',
	static function () {
		nb_base_admin_guard( 'nb_base_save_robots' );
		$value = isset( $_POST['robots'] ) && is_array( $_POST['robots'] ) ? wp_unslash( $_POST['robots'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nettoyé par nb_base_sanitize_robots().
		update_option( NB_BASE_ROBOTS_OPTION, nb_base_sanitize_robots( $value ), false );
		nb_base_admin_redirect( 'seo-saved', 'seo' );
	}
);
