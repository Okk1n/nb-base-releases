<?php
/**
 * Restrictions d'édition pour les non-designers (client, partenaire).
 *
 * Ils peuvent : créer/modifier des pages avec les blocs autorisés, gérer les
 * menus (Apparence → Menus), régler l'en-tête (Apparence → En-tête).
 * Ils ne peuvent pas : ouvrir l'éditeur de site, modifier les styles
 * globaux, les templates, les template parts, les polices, ni utiliser des
 * réglages visuels libres.
 *
 * Deux niveaux :
 *  1. Serveur (REST) : toute écriture sur ces ressources est refusée.
 *  2. Interface : les entrées correspondantes sont masquées.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Routes REST en écriture réservées au designer.
 */
function nb_base_designer_only_routes(): array {
	return array(
		'/wp/v2/global-styles',
		'/wp/v2/templates',
		'/wp/v2/template-parts',
		'/wp/v2/font-families',
		'/wp/v2/font-collections',
	);
}

/**
 * 1. Blocage serveur des écritures (couvre aussi les requêtes groupées /batch).
 */
add_filter(
	'rest_request_before_callbacks',
	static function ( $response, $handler, WP_REST_Request $request ) {
		if ( 'GET' === $request->get_method() || 'HEAD' === $request->get_method() || nb_base_is_designer() ) {
			return $response;
		}
		// WordPress associe les routes sans tenir compte de la casse (/wp/v2/Templates = /wp/v2/templates).
		$route = strtolower( $request->get_route() );
		foreach ( nb_base_designer_only_routes() as $prefix ) {
			if ( str_starts_with( $route, $prefix ) ) {
				return new WP_Error(
					'nb_base_forbidden',
					__( 'This action is restricted to the site designer.', 'nb-base' ),
					array( 'status' => 403 )
				);
			}
		}
		return $response;
	},
	10,
	3
);

/**
 * 2a. Réglages de l'éditeur pour les non-designers.
 */
add_filter(
	'block_editor_settings_all',
	static function ( array $settings, $context ): array {
		$is_site_editor = $context instanceof WP_Block_Editor_Context && 'core/edit-site' === $context->name;

		// Largeur large / pleine largeur : réservée au designer dans l'éditeur de site.
		if ( ! $is_site_editor || ! nb_base_is_designer() ) {
			$settings['alignWide'] = false;
		}

		if ( nb_base_is_designer() ) {
			return $settings;
		}
		$settings['supportsTemplateMode'] = false; // Pas de « Modifier le template » depuis une page.
		$settings['fontLibraryEnabled']   = false; // Pas de bibliothèque de polices.
		$settings['codeEditingEnabled']   = false; // Pas d'éditeur de code HTML.
		$settings['canLockBlocks']        = false; // Ne peut pas déverrouiller les blocs verrouillés.
		return $settings;
	},
	10,
	2
);

/**
 * 2b. Réglages visuels des blocs (couleurs, tailles, polices, marges,
 * dimensions, variantes…) : coupés pour tout le monde, sauf pour le designer
 * dans l'éditeur de site. Voir assets/js/editor-restrictions.js.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		global $pagenow;
		if ( 'site-editor.php' === $pagenow && nb_base_is_designer() ) {
			return;
		}
		wp_enqueue_script(
			'nb-base-editor-restrictions',
			NB_BASE_URI . '/assets/js/editor-restrictions.js',
			array( 'wp-hooks' ),
			NB_BASE_VERSION,
			false // Dans le <head> : doit être chargé avant l'enregistrement des blocs.
		);
	}
);

/**
 * 2c. Éditeur de code : WordPress se contente de le griser (codeEditingEnabled).
 * On masque tout le groupe « Éditeur » (visuel / code) du menu ⋮, devenu
 * inutile puisqu'il ne reste qu'un seul choix.
 *
 * Verrous : sans le droit de déverrouiller (canLockBlocks), WordPress affiche
 * quand même un cadenas grisé dans la barre d'outils des blocs verrouillés
 * et dans la vue en liste. Aucune API ne permet de le retirer : masqué ici.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		if ( nb_base_is_designer() ) {
			return;
		}
		$css = '.components-menu-group:has(.components-menu-items-choice:is([disabled],[aria-disabled="true"])),'
			. '.block-editor-block-lock-toolbar:has(:is([disabled],[aria-disabled="true"])),'
			. '.block-editor-list-view-block-select-button__lock'
			. '{display:none!important}';
		wp_register_style( 'nb-base-editor-restrictions', false, array(), NB_BASE_VERSION );
		wp_enqueue_style( 'nb-base-editor-restrictions' );
		wp_add_inline_style( 'nb-base-editor-restrictions', $css );
	}
);

/**
 * 2d. Éditeur de site (Apparence → Éditeur) : réservé au designer.
 * Les clients gèrent les menus dans Apparence → Menus (inc/header.php) et
 * les pages dans Pages. Entrée de menu et lien « Modifier le site » de la
 * barre d'administration retirés ; accès direct refusé.
 */
add_action(
	'admin_menu',
	static function () {
		if ( ! nb_base_is_designer() ) {
			remove_submenu_page( 'themes.php', 'site-editor.php' );
		}
	},
	999
);

add_action(
	'load-site-editor.php',
	static function () {
		if ( ! nb_base_is_designer() ) {
			wp_die( esc_html__( 'This action is restricted to the site designer.', 'nb-base' ), 403 );
		}
	}
);

add_action(
	'admin_bar_menu',
	static function ( WP_Admin_Bar $bar ) {
		if ( ! nb_base_is_designer() ) {
			$bar->remove_node( 'site-editor' );
		}
	},
	999
);
