<?php
/**
 * Pied de page du site (bloc nb-base/footer, placé dans parts/footer.html).
 *
 * Réglages modifiables par les administrateurs (client compris), page
 * Apparence → En-tête et pied de page, onglet « Pied de page » (mise en
 * page) : option « nb_base_footer » : fond, hauteur du logo, phrase
 * d'accroche, titres et textes (newsletter, réseaux sociaux).
 * Informations sur l'entreprise, page Établissement (inc/business.php) :
 *  - liens des réseaux (nb_base_footer.social) ;
 *  - option « nb_base_contact » : e-mail, texte libre des horaires ; son
 *    champ « address » (ancien texte libre) ne sert plus qu'en repli ;
 *  - téléphone « nb_base_phone » (commun avec l'en-tête) ;
 *  - note Google : options communes « nb_base_google_rating » / « nb_base_google_url »
 *    (inc/google-rating.php) ;
 *  - menus : emplacement « En-tête » (le même menu) et « Pied de page – liens
 *    légaux » (Apparence → Menus).
 * Logo : celui de l'en-tête (logo clair sur fond sombre s'il existe).
 * Formulaire de newsletter : pas encore choisi ; HTML fourni par le filtre
 * « nb_base_footer_newsletter ». Sans formulaire, la colonne n'est pas affichée.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Réseaux sociaux proposés, dans l'ordre d'affichage : clé (définitive) →
 * nom affiché et icône Tabler.
 *
 * @return array<string, array{label: string, icon: string}>
 */
function nb_base_social_networks(): array {
	return array(
		'facebook'  => array( 'label' => 'Facebook', 'icon' => 'brand-facebook' ),
		'x'         => array( 'label' => 'X', 'icon' => 'brand-x' ),
		'bluesky'   => array( 'label' => 'Bluesky', 'icon' => 'brand-bluesky' ),
		'instagram' => array( 'label' => 'Instagram', 'icon' => 'brand-instagram' ),
		'linkedin'  => array( 'label' => 'LinkedIn', 'icon' => 'brand-linkedin' ),
		'youtube'   => array( 'label' => 'YouTube', 'icon' => 'brand-youtube' ),
		'tiktok'    => array( 'label' => 'TikTok', 'icon' => 'brand-tiktok' ),
		'pinterest' => array( 'label' => 'Pinterest', 'icon' => 'brand-pinterest' ),
	);
}

add_action(
	'after_setup_theme',
	static function () {
		register_nav_menus( array( 'footer-legal' => __( 'Footer – legal links', 'nb-base' ) ) );
	}
);

/**
 * Valeurs par défaut du pied de page.
 */
function nb_base_footer_defaults(): array {
	return array(
		'background'      => 'dark', // Fond (identifiant de inc/backgrounds.php).
		'logoHeight'      => 64,     // Hauteur du logo (px), bornée comme celle de l'en-tête.
		'tagline'         => '',     // Phrase d'accroche sous le logo (facultative).
		'showNewsletter'  => true, // Newsletter affichée (si la fonctionnalité est active).
		'newsletterTitle' => '',
		'newsletterText'  => '',
		'socialTitle'     => '',
		'socialText'      => '',
		'social'          => array_fill_keys( array_keys( nb_base_social_networks() ), '' ),
	);
}

/**
 * Lien d'un réseau social : adresse web (http/https) uniquement.
 */
function nb_base_sanitize_social_url( $url ): string {
	return esc_url_raw( trim( (string) $url ), array( 'http', 'https' ) );
}

/**
 * Nettoyage des réglages du pied de page (enregistrement et lecture).
 *
 * @param mixed $value Valeur reçue.
 */
function nb_base_sanitize_footer( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = nb_base_footer_defaults();
	$height   = (int) ( $value['logoHeight'] ?? $defaults['logoHeight'] );
	$bg       = (string) ( $value['background'] ?? $defaults['background'] );
	$social   = is_array( $value['social'] ?? null ) ? $value['social'] : array();
	$clean    = array(
		'background' => preg_match( '/^[a-z0-9-]*$/', $bg ) ? $bg : $defaults['background'],
		'logoHeight' => max( NB_BASE_LOGO_HEIGHT_MIN, min( NB_BASE_LOGO_HEIGHT_MAX, $height ) ),
		'tagline'    => sanitize_textarea_field( (string) ( $value['tagline'] ?? '' ) ),
		'showNewsletter' => array_key_exists( 'showNewsletter', $value ) ? (bool) $value['showNewsletter'] : $defaults['showNewsletter'],
		'social'     => array(),
	);
	foreach ( array( 'newsletterTitle', 'socialTitle' ) as $key ) {
		$clean[ $key ] = sanitize_text_field( (string) ( $value[ $key ] ?? '' ) );
	}
	foreach ( array( 'newsletterText', 'socialText' ) as $key ) {
		$clean[ $key ] = sanitize_textarea_field( (string) ( $value[ $key ] ?? '' ) );
	}
	foreach ( array_keys( nb_base_social_networks() ) as $key ) {
		$clean['social'][ $key ] = nb_base_sanitize_social_url( $social[ $key ] ?? '' );
	}
	return $clean;
}

/**
 * Coordonnées du site (le téléphone est l'option nb_base_phone).
 */
function nb_base_contact_defaults(): array {
	return array(
		'email'   => '',
		'address' => '', // Plusieurs lignes.
		'hours'   => '',
	);
}

/**
 * @param mixed $value Valeur reçue.
 */
function nb_base_sanitize_contact( $value ): array {
	$value = is_array( $value ) ? $value : array();
	return array(
		'email'   => (string) sanitize_email( (string) ( $value['email'] ?? '' ) ),
		'address' => sanitize_textarea_field( (string) ( $value['address'] ?? '' ) ),
		'hours'   => sanitize_text_field( (string) ( $value['hours'] ?? '' ) ),
	);
}

function nb_base_footer_settings(): array {
	return nb_base_sanitize_footer( get_option( 'nb_base_footer', array() ) );
}

function nb_base_contact_settings(): array {
	return nb_base_sanitize_contact( get_option( 'nb_base_contact', array() ) );
}

/**
 * Lignes de coordonnées du site, dans l'ordre d'affichage (pied de page,
 * bloc Formulaire de contact) : téléphone, e-mail, adresse (→ Google Maps,
 * nouvel onglet), horaires. Champ vide = ligne absente.
 *
 * @return array<int, array{icon: string, html: string, href: string, external: bool}>
 */
function nb_base_contact_items(): array {
	$contact = nb_base_contact_settings();
	$lines   = static fn( string $text ): string => nl2br( esc_html( $text ), false );
	$phone   = trim( (string) get_option( 'nb_base_phone', '' ) );
	$items   = array();

	$tel = nb_base_phone_href( $phone );
	if ( '' !== $tel ) {
		$items[] = array( 'icon' => 'phone', 'html' => esc_html( $phone ), 'href' => $tel, 'external' => false );
	}
	if ( '' !== $contact['email'] ) {
		$items[] = array( 'icon' => 'mail', 'html' => esc_html( $contact['email'] ), 'href' => 'mailto:' . $contact['email'], 'external' => false );
	}
	// Adresse de la fiche Établissement ; ancien texte libre en repli (sites non convertis).
	$address = function_exists( 'nb_base_business_address_text' ) ? nb_base_business_address_text() : '';
	$address = '' !== $address ? $address : $contact['address'];
	if ( '' !== $address ) {
		$maps    = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( preg_replace( '/\s+/', ' ', $address ) );
		$items[] = array( 'icon' => 'map-pin', 'html' => $lines( $address ), 'href' => $maps, 'external' => true );
	}
	// Texte libre des horaires, sinon résumé des horaires par jour (fiche Établissement).
	$hours = function_exists( 'nb_base_business_hours_display' ) ? nb_base_business_hours_display() : array_filter( array( $contact['hours'] ) );
	if ( $hours ) {
		$items[] = array( 'icon' => 'clock', 'html' => implode( '<br>', array_map( 'esc_html', $hours ) ), 'href' => '', 'external' => false );
	}

	return $items;
}

add_action(
	'init',
	static function () {
		$string = array( 'type' => 'string' );
		register_setting(
			'nb_base',
			'nb_base_footer',
			array(
				'type'              => 'object',
				'description'       => __( 'Site footer settings.', 'nb-base' ),
				'default'           => nb_base_footer_defaults(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => array(
							'background'      => $string,
							'logoHeight'      => array( 'type' => 'integer' ),
							'tagline'         => $string,
							'showNewsletter'  => array( 'type' => 'boolean' ),
							'newsletterTitle' => $string,
							'newsletterText'  => $string,
							'socialTitle'     => $string,
							'socialText'      => $string,
							'social'          => array(
								'type'                 => 'object',
								'properties'           => array_fill_keys( array_keys( nb_base_social_networks() ), $string ),
								'additionalProperties' => false,
							),
						),
						'additionalProperties' => false,
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_footer',
			)
		);
		register_setting(
			'nb_base',
			'nb_base_contact',
			array(
				'type'              => 'object',
				'description'       => __( 'Site contact details.', 'nb-base' ),
				'default'           => nb_base_contact_defaults(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => array(
							'email'   => $string,
							'address' => $string,
							'hours'   => $string,
						),
						'additionalProperties' => false,
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_contact',
			)
		);
	}
);

/*
 * Lecture toujours nettoyée : une clé ajoutée puis retirée du code (ancienne
 * valeur en base) ne doit jamais faire échouer la validation de l'API REST
 * (« additionalProperties » : la valeur deviendrait null et la page de
 * réglages ne se chargerait plus).
 */
add_filter( 'option_nb_base_footer', 'nb_base_sanitize_footer' );
add_filter( 'option_nb_base_contact', 'nb_base_sanitize_contact' );

/**
 * Données de l'onglet « Pied de page » de la page d'administration.
 */
function nb_base_footer_admin_data(): array {
	$menu_name = static function ( string $location ): string {
		$id   = get_nav_menu_locations()[ $location ] ?? 0;
		$menu = $id ? wp_get_nav_menu_object( $id ) : false;
		return $menu ? $menu->name : '';
	};
	return array(
		'social'        => array_map(
			static fn( $key, $network ) => array(
				'key'   => $key,
				'label' => $network['label'],
			),
			array_keys( nb_base_social_networks() ),
			nb_base_social_networks()
		),
		'legalMenuName' => $menu_name( 'footer-legal' ),
		'hasNewsletter' => '' !== nb_base_footer_newsletter_form(),
		// Newsletter du thème : fonctionnalité active, lien vers les textes du formulaire.
		'newsletter'    => function_exists( 'nb_base_newsletter_available' ) && nb_base_newsletter_available()
			? array(
				'formId'  => nb_base_newsletter_settings()['formId'],
				'editUrl' => '' !== nb_base_newsletter_settings()['formId'] ? str_replace( '{id}', nb_base_newsletter_settings()['formId'], (string) apply_filters( 'nb_base_form_edit_url', '' ) ) : '',
			)
			: null,
	);
}

/**
 * Formulaire d'inscription à la newsletter (HTML), fourni par le filtre
 * « nb_base_footer_newsletter » (inc/newsletter.php ; vide si masquée).
 */
function nb_base_footer_newsletter_form(): string {
	return trim( (string) apply_filters( 'nb_base_footer_newsletter', '' ) );
}
