<?php
/**
 * Enregistrement des blocs du thème et liste blanche des blocs autorisés.
 *
 * Les sources des blocs sont dans /src/blocks (hors thème) et compilées dans
 * /nb-base/build/<bloc>/ par `npm run build`.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enregistre chaque bloc compilé présent dans build/.
 */
add_action(
	'init',
	static function () {
		$build_dir = NB_BASE_DIR . '/build';
		if ( ! is_dir( $build_dir ) ) {
			return;
		}
		foreach ( glob( $build_dir . '/*/block.json' ) ?: array() as $block_json ) {
			register_block_type( dirname( $block_json ) );
		}
	}
);

/**
 * Catégories de l'inserteur, en tête de liste (slugs définitifs, titres
 * libres) :
 * - « Sections » (nb-blocks) : sections à remplir (hero, about, text-image,
 *   card-grid, FAQ, témoignages…) ;
 * - « Dynamic content » (nb-dynamic) : blocs alimentés automatiquement par
 *   les données du site (derniers contenus, catégories, coordonnées et
 *   formulaire, note Google) ;
 * - « Elements » (nb-base) : composants des sections (écusson, cartes, liste
 *   à icônes…), réutilisables seuls.
 * Les blocs n'ont pas de préfixe dans leur titre : les catégories suffisent
 * à les distinguer des blocs de WordPress.
 */
add_filter(
	'block_categories_all',
	static function ( array $categories ): array {
		array_unshift(
			$categories,
			array(
				'slug'  => 'nb-blocks',
				'title' => __( 'Sections', 'nb-base' ),
				'icon'  => null,
			),
			array(
				'slug'  => 'nb-dynamic',
				'title' => __( 'Dynamic content', 'nb-base' ),
				'icon'  => null,
			),
			array(
				'slug'  => 'nb-base',
				'title' => __( 'Elements', 'nb-base' ),
				'icon'  => null,
			)
		);
		return $categories;
	}
);

/**
 * Fonctionnalités liées aux blocs (voir inc/features.php).
 */
add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['hero'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Hero', 'nb-base' ),
			'description' => __( 'Full-screen header section with a background photo or video.', 'nb-base' ),
			'default'     => true,
			'blocks'      => array( 'nb-base/hero' ),
		);
		$features['about'] = array(
			'group'       => 'blocks',
			'label'       => __( 'About', 'nb-base' ),
			'description' => __( '“About us” section: text, key figures, Google rating and image.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/about' ),
		);
		$features['text-image'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Text-image', 'nb-base' ),
			'description' => __( 'Section with text and an image side by side.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/text-image' ),
		);
		$features['card-grid'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Card grid', 'nb-base' ),
			'description' => __( 'Section with a title and a grid of 2 to 8 cards.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/card-grid' ),
		);
		$features['content-grid'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Content grid', 'nb-base' ),
			'description' => __( 'Section showing the latest projects (or another content type) as a grid or a carousel, with category filters.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/content-grid' ),
		);
		$features['category-grid'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Category grid', 'nb-base' ),
			'description' => __( 'Section showing the categories of a content type (projects…) as cards linking to the filtered list.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/category-grid' ),
		);
		$features['testimonials'] = array(
			'group'       => 'blocks',
			'label'       => __( 'Testimonials', 'nb-base' ),
			'description' => __( 'Section with a carousel of testimonials: 9:16 videos or photos, text and signature.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/testimonials' ),
		);
		return $features;
	}
);

/**
 * Blocs natifs autorisés dans l'éditeur de pages, en plus des blocs nb-base/*.
 */
function nb_base_allowed_core_blocks(): array {
	return apply_filters(
		'nb_base_allowed_core_blocks',
		array(
			'core/paragraph',
			'core/heading',
			'core/list',
			'core/list-item',
			'core/image',
			'core/buttons',
			'core/button',
			'core/separator',
			'core/block', // Compositions synchronisées.
		)
	);
}

/**
 * Blocs natifs autorisés dans une **page** : les pages sont faites des blocs
 * du thème uniquement. Restent : les boutons (placés dans les blocs du thème,
 * jamais directement dans la page : voir nb_base_page_root_restrictions()),
 * les compositions synchronisées ; pages au modèle « Page légale » : titres,
 * paragraphes et listes (texte des mentions légales…).
 */
function nb_base_page_core_blocks( ?WP_Post $post ): array {
	$blocks = array( 'core/buttons', 'core/button', 'core/block' );
	if ( $post && 'page-legal' === get_page_template_slug( $post ) ) {
		$blocks = array_merge( $blocks, array( 'core/heading', 'core/paragraph', 'core/list', 'core/list-item' ) );
	}
	return (array) apply_filters( 'nb_base_page_core_blocks', $blocks, $post );
}

/**
 * Éditeur de pages et de contenus : liste blanche pour tout le monde
 * (designer compris, pour voir exactement ce que voit le client).
 * Éditeur de site : pas de restriction (les enregistrements y sont de toute
 * façon réservés au designer, sauf les menus).
 */
add_filter(
	'allowed_block_types_all',
	static function ( $allowed, $context ) {
		if ( ! $context instanceof WP_Block_Editor_Context || 'core/edit-post' !== $context->name ) {
			return $allowed;
		}

		$own_blocks = array_filter(
			array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() ),
			static fn( $name ) => str_starts_with( $name, 'nb-base/' )
		);

		$is_page = $context->post instanceof WP_Post && 'page' === $context->post->post_type;
		$core    = $is_page ? nb_base_page_core_blocks( $context->post ) : nb_base_allowed_core_blocks();
		return array_values( array_merge( $core, $own_blocks ) );
	},
	10,
	2
);

/**
 * Pages : les boutons natifs ne s'insèrent qu'à l'intérieur d'un bloc du
 * thème (propriété native « ancestor » ajoutée par src/editor/page-blocks.js,
 * filtre public blocks.registerBlockType), pages légales comprises.
 */
function nb_base_page_root_restrictions(): ?array {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'post' !== $screen->base || 'page' !== $screen->post_type ) {
		return null;
	}
	$own = array_values(
		array_filter(
			array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() ),
			static fn( $name ) => str_starts_with( $name, 'nb-base/' )
		)
	);
	return array( 'core/buttons' => $own );
}

/**
 * Script d'éditeur commun à tous les blocs NB Base (navigation « Retour à »,
 * sélecteur d'icônes…). Source : src/editor/.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$asset_file = NB_BASE_DIR . '/build-editor/index.asset.php';
		if ( ! is_readable( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		// Dans le <head> : les filtres blocks.registerBlockType doivent précéder l'enregistrement des blocs.
		wp_enqueue_script( 'nb-base-editor', NB_BASE_URI . '/build-editor/index.js', $asset['dependencies'], $asset['version'], false );
		wp_enqueue_style( 'nb-base-editor', NB_BASE_URI . '/build-editor/index.css', array(), $asset['version'] );
		wp_set_script_translations( 'nb-base-editor', 'nb-base', NB_BASE_DIR . '/languages' );
		$restrictions = nb_base_page_root_restrictions();
		if ( $restrictions ) {
			wp_add_inline_script( 'nb-base-editor', 'window.nbBasePageAncestors = ' . wp_json_encode( $restrictions ) . ';', 'before' );
		}
	}
);

/**
 * Valeur CSS simple -> pixels (« 0.25rem » -> « 4px »), pour l'affichage
 * dans l'éditeur. Les valeurs non convertibles sont renvoyées telles quelles.
 */
function nb_base_css_to_px( string $value ): string {
	$value = trim( $value );
	if ( preg_match( '/^(\d*\.?\d+)(px|rem|em)?$/', $value, $m ) ) {
		$px = (float) $m[1] * ( in_array( $m[2] ?? '', array( 'rem', 'em' ), true ) ? 16 : 1 );
		return rtrim( rtrim( number_format( $px, 2, '.', '' ), '0' ), '.' ) . 'px';
	}
	return $value;
}

/**
 * Feuille de style du site uniquement (wp_enqueue_scripts n'est pas exécuté
 * dans l'éditeur) : espacement nul entre les blocs de premier niveau.
 */
add_action(
	'wp_enqueue_scripts',
	static function () {
		wp_enqueue_style( 'nb-base-front', NB_BASE_URI . '/assets/css/front.css', array( 'global-styles' ), NB_BASE_VERSION );
	},
	20
);

/**
 * Styles des templates du thème (page légale…), compilés depuis src/front/ :
 * site et éditeur.
 */
add_action(
	'enqueue_block_assets',
	static function () {
		if ( is_readable( NB_BASE_DIR . '/build-front/index.css' ) ) {
			wp_enqueue_style( 'nb-base-templates', NB_BASE_URI . '/build-front/index.css', array(), NB_BASE_VERSION );
		}
	}
);

/**
 * Version des feuilles de style du thème = date de modification du fichier.
 * Les styles déclarés dans block.json sont sinon versionnés par la version
 * du bloc (?ver=1.0.0) : après une modification ou une mise à jour du thème,
 * les navigateurs garderaient l'ancien CSS en cache.
 * (Les scripts sont déjà versionnés par empreinte via index.asset.php.)
 */
add_filter(
	'style_loader_src',
	static function ( $src ) {
		if ( ! is_string( $src ) || ! str_starts_with( $src, NB_BASE_URI . '/' ) ) {
			return $src;
		}
		$path = NB_BASE_DIR . substr( strtok( $src, '?' ), strlen( NB_BASE_URI ) );
		return is_readable( $path ) ? add_query_arg( 'ver', (string) filemtime( $path ), $src ) : $src;
	}
);

/**
 * Traductions des scripts d'éditeur des blocs (fichiers JSON du thème).
 * WordPress les cherche sinon dans wp-content/languages.
 */
add_action(
	'init',
	static function () {
		foreach ( WP_Block_Type_Registry::get_instance()->get_all_registered() as $name => $block_type ) {
			if ( ! str_starts_with( $name, 'nb-base/' ) ) {
				continue;
			}
			foreach ( $block_type->editor_script_handles as $handle ) {
				wp_set_script_translations( $handle, 'nb-base', NB_BASE_DIR . '/languages' );
			}
		}
	},
	20
);

/**
 * Script et styles communs des carrousels (Swiper, embarqué ; source :
 * src/carousel/). Déclarés ici, chargés seulement par les blocs qui les
 * demandent (block.json : "viewScript" / "viewStyle" : "nb-base-carousel").
 */
add_action(
	'init',
	static function () {
		$asset_file = NB_BASE_DIR . '/build-carousel/index.asset.php';
		if ( ! is_readable( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_register_script(
			'nb-base-carousel',
			NB_BASE_URI . '/build-carousel/index.js',
			$asset['dependencies'],
			$asset['version'],
			array( 'in_footer' => true, 'strategy' => 'defer' )
		);
		wp_register_style( 'nb-base-carousel', NB_BASE_URI . '/build-carousel/index.css', array(), $asset['version'] );
	},
	5
);

/**
 * Pages : retire les blocs de texte natifs **vides** (paragraphe, titre)
 * placés directement dans la page et non autorisés sur cette page (ex.
 * paragraphe vide créé avant la restriction des blocs). Les blocs avec du
 * texte ne sont jamais retirés (aucune perte de contenu).
 *
 * @return string|null Contenu nettoyé, ou null si rien à retirer.
 */
function nb_base_page_clean_content( string $content, ?WP_Post $post ): ?string {
	if ( ! has_blocks( $content ) ) {
		return null;
	}
	$allowed = nb_base_page_core_blocks( $post );
	$blocks  = parse_blocks( $content );
	$kept    = array_filter(
		$blocks,
		static function ( array $block ) use ( $allowed ): bool {
			$name = (string) $block['blockName'];
			if ( ! in_array( $name, array( 'core/paragraph', 'core/heading' ), true ) || in_array( $name, $allowed, true ) ) {
				return true;
			}
			return ! empty( $block['innerBlocks'] ) || '' !== trim( html_entity_decode( wp_strip_all_tags( (string) $block['innerHTML'] ), ENT_QUOTES, 'UTF-8' ), " \t\n\r\0\x0B\xC2\xA0" );
		}
	);
	return count( $kept ) === count( $blocks ) ? null : serialize_blocks( array_values( $kept ) );
}

add_filter(
	'wp_insert_post_data',
	static function ( array $data, array $postarr ): array {
		if ( 'page' !== ( $data['post_type'] ?? '' ) ) {
			return $data;
		}
		$post  = ! empty( $postarr['ID'] ) ? get_post( (int) $postarr['ID'] ) : null;
		$clean = nb_base_page_clean_content( wp_unslash( (string) $data['post_content'] ), $post );
		if ( null !== $clean ) {
			$data['post_content'] = wp_slash( $clean );
		}
		return $data;
	},
	9,
	2
);

/** Option : pages existantes nettoyées (1 = fait). */
const NB_BASE_PAGES_CLEANED_OPTION = 'nb_base_pages_cleaned';

/**
 * Pages existantes : nettoyage une fois par site (premier passage dans
 * l'administration), sans révision, date de modification conservée.
 */
function nb_base_clean_existing_pages(): int {
	update_option( NB_BASE_PAGES_CLEANED_OPTION, 1, true );
	$ids = get_posts(
		array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		)
	);
	$keep_dates = static function ( array $data, array $postarr ): array {
		if ( ! empty( $postarr['nb_base_keep_dates'] ) ) {
			$data['post_modified']     = $postarr['nb_base_keep_dates'][0];
			$data['post_modified_gmt'] = $postarr['nb_base_keep_dates'][1];
		}
		return $data;
	};
	add_filter( 'wp_insert_post_data', $keep_dates, 10, 2 );
	add_filter( 'wp_revisions_to_keep', '__return_zero', 999 );
	$kses = false !== has_filter( 'content_save_pre', 'wp_filter_post_kses' );
	if ( $kses ) {
		kses_remove_filters();
	}
	$count = 0;
	foreach ( $ids as $id ) {
		$post = get_post( $id );
		if ( ! $post || null === nb_base_page_clean_content( $post->post_content, $post ) ) {
			continue;
		}
		// Le nettoyage lui-même : filtre wp_insert_post_data ci-dessus.
		$result = wp_update_post(
			wp_slash(
				array(
					'ID'                 => $post->ID,
					'post_content'       => $post->post_content,
					'nb_base_keep_dates' => array( $post->post_modified, $post->post_modified_gmt ),
				)
			),
			true
		);
		if ( ! is_wp_error( $result ) ) {
			++$count;
		}
	}
	if ( $kses ) {
		kses_init_filters();
	}
	remove_filter( 'wp_revisions_to_keep', '__return_zero', 999 );
	remove_filter( 'wp_insert_post_data', $keep_dates, 10 );
	return $count;
}

add_action(
	'admin_init',
	static function () {
		if ( ! get_option( NB_BASE_PAGES_CLEANED_OPTION ) ) {
			nb_base_clean_existing_pages();
		}
	}
);
