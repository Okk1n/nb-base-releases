<?php
/**
 * Contenus structurés (réalisations, futurs produits…) : outils communs aux
 * blocs de mise en page de ces contenus (nb-base/entry-*, gallery,
 * breadcrumb).
 *
 * Chaque module de contenu (inc/realisations.php…) déclare ses réglages par
 * le filtre « nb_base_entry_settings ».
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/** Métadonnée des caractéristiques : objet { clé: valeur }. */
const NB_BASE_CHARACTERISTICS_META = 'nb_characteristics';

/** Nombre maximum de contenus dans un carrousel. */
const NB_BASE_CAROUSEL_MAX = 6;

/**
 * Réglages d'un type de contenu structuré, ou null s'il n'en est pas un.
 *
 * @return array{
 *     taxonomy: string,
 *     characteristics: array<int, array{key: string, label: string, type: string}>,
 *     gallery_title: string,
 *     related_title: string,
 *     view_all_label: string,
 *     card_link_label: string,
 *     title_placeholder?: string
 * }|null
 */
function nb_base_entry_settings( string $post_type ): ?array {
	// Textes affichés sur le site : dans la langue du site, y compris dans
	// les aperçus de l'éditeur (dont la langue est celle de l'utilisateur).
	$settings = nb_base_in_site_locale( static fn() => apply_filters( 'nb_base_entry_settings', null, $post_type ) );
	return is_array( $settings ) ? $settings : null;
}

/**
 * Exécute $callback dans la langue du site (textes destinés au site, calculés
 * dans l'administration ou une requête REST de l'éditeur).
 *
 * @param callable $callback Fonction à exécuter.
 * @return mixed Valeur renvoyée par $callback.
 */
function nb_base_in_site_locale( callable $callback ) {
	$switched = determine_locale() !== get_locale() && switch_to_locale( get_locale() );
	try {
		return $callback();
	} finally {
		if ( $switched ) {
			restore_previous_locale();
		}
	}
}

/**
 * Valeurs des caractéristiques d'un contenu (clé => valeur).
 *
 * @return array<string, string>
 */
function nb_base_entry_characteristic_values( int $post_id ): array {
	$values = get_post_meta( $post_id, NB_BASE_CHARACTERISTICS_META, true );
	return is_array( $values ) ? array_map( 'strval', $values ) : array();
}

/**
 * Caractéristiques à afficher (libellé + valeur), vides exclues.
 *
 * @return array<int, array{label: string, value: string}>
 */
function nb_base_entry_characteristics( int $post_id ): array {
	$settings = nb_base_entry_settings( (string) get_post_type( $post_id ) );
	if ( ! $settings ) {
		return array();
	}
	$values = nb_base_entry_characteristic_values( $post_id );
	$rows   = array();
	foreach ( $settings['characteristics'] as $item ) {
		if ( 'taxonomy' === $item['type'] ) {
			$terms = get_the_terms( $post_id, $settings['taxonomy'] );
			$value = is_array( $terms ) ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '';
		} else {
			$value = trim( $values[ $item['key'] ] ?? '' );
		}
		if ( '' !== $value && '' !== trim( $item['label'] ) ) {
			$rows[] = array(
				'label' => $item['label'],
				'value' => $value,
			);
		}
	}
	return $rows;
}

/**
 * Contenus affichés dans le carrousel « Autres … ».
 *
 * - auto : les plus récents de la même catégorie en priorité, complétés par
 *   les plus récents des autres catégories ;
 * - manual : sélection du client, dans son ordre (contenus non publiés ignorés).
 *
 * @param int    $post_id Contenu courant (exclu).
 * @param string $mode    « auto » ou « manual ».
 * @param int[]  $manual  Sélection manuelle.
 * @return int[]
 */
function nb_base_entry_related_ids( int $post_id, string $mode, array $manual ): array {
	$post_type = (string) get_post_type( $post_id );
	$settings  = nb_base_entry_settings( $post_type );
	if ( ! $settings ) {
		return array();
	}

	$base = array(
		'post_type'      => $post_type,
		'post_status'    => 'publish',
		'posts_per_page' => NB_BASE_CAROUSEL_MAX,
		'no_found_rows'  => true,
		'fields'         => 'ids',
		'orderby'        => 'date',
		'order'          => 'DESC',
	);

	if ( 'manual' === $mode ) {
		$ids = array_slice( array_values( array_unique( array_filter( array_map( 'intval', $manual ) ) ) ), 0, NB_BASE_CAROUSEL_MAX );
		$ids = array_values( array_diff( $ids, array( $post_id ) ) );
		if ( ! $ids ) {
			return array();
		}
		return get_posts(
			array_merge(
				$base,
				array(
					'post__in' => $ids,
					'orderby'  => 'post__in',
				)
			)
		);
	}

	$ids   = array();
	$terms = wp_get_post_terms( $post_id, $settings['taxonomy'], array( 'fields' => 'ids' ) );
	if ( is_array( $terms ) && $terms ) {
		$ids = get_posts(
			array_merge(
				$base,
				array(
					'post__not_in' => array( $post_id ),
					'tax_query'    => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => $settings['taxonomy'],
							'terms'    => $terms,
						),
					),
				)
			)
		);
	}
	if ( count( $ids ) < NB_BASE_CAROUSEL_MAX ) {
		$ids = array_merge(
			$ids,
			get_posts(
				array_merge(
					$base,
					array(
						'posts_per_page' => NB_BASE_CAROUSEL_MAX - count( $ids ),
						'post__not_in'   => array_merge( array( $post_id ), $ids ),
					)
				)
			)
		);
	}
	return array_map( 'intval', $ids );
}

/**
 * Contenus d'une grille ou d'un carrousel de contenus (bloc content-grid),
 * avec leurs filtres par catégorie.
 *
 * - groups['all'] : les $count plus récents ;
 * - groups[<id de catégorie>] : les $count plus récents de la catégorie
 *   (catégories sans contenu publié ignorées) ;
 * - ids : tous les contenus utilisés, du plus récent au plus ancien.
 *
 * @param string $post_type  Type de contenu structuré.
 * @param int    $count      Nombre de contenus par groupe.
 * @param bool   $with_terms Calculer les groupes par catégorie.
 * @param int    $exclude    Contenu à exclure (page affichée).
 * @return array{ids: int[], groups: array<string, int[]>, terms: WP_Term[]}
 */
function nb_base_entry_grid_items( string $post_type, int $count, bool $with_terms, int $exclude = 0 ): array {
	$empty    = array(
		'ids'    => array(),
		'groups' => array(),
		'terms'  => array(),
	);
	$settings = nb_base_entry_settings( $post_type );
	if ( ! $settings || ! post_type_exists( $post_type ) || $count < 1 ) {
		return $empty;
	}

	$base   = array(
		'post_type'      => $post_type,
		'post_status'    => 'publish',
		'posts_per_page' => $count,
		'no_found_rows'  => true,
		'fields'         => 'ids',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'post__not_in'   => $exclude ? array( $exclude ) : array(),
	);
	$groups = array( 'all' => array_map( 'intval', get_posts( $base ) ) );
	if ( ! $groups['all'] ) {
		return $empty;
	}

	$used_terms = array();
	if ( $with_terms && taxonomy_exists( $settings['taxonomy'] ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $settings['taxonomy'],
				'hide_empty' => true,
			)
		);
		foreach ( is_array( $terms ) ? nb_base_sort_terms( $terms ) : array() as $term ) {
			$ids = get_posts(
				array_merge(
					$base,
					array(
						'tax_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
							array(
								'taxonomy'         => $settings['taxonomy'],
								'terms'            => array( $term->term_id ),
								'include_children' => true,
							),
						),
					)
				)
			);
			if ( $ids ) {
				$groups[ (string) $term->term_id ] = array_map( 'intval', $ids );
				$used_terms[]                      = $term;
			}
		}
	}

	$all_ids = array_values( array_unique( array_merge( ...array_values( $groups ) ) ) );
	$ordered = get_posts(
		array_merge(
			$base,
			array(
				'posts_per_page' => count( $all_ids ),
				'post__in'       => $all_ids,
			)
		)
	);

	return array(
		'ids'    => array_map( 'intval', $ordered ),
		'groups' => $groups,
		'terms'  => $used_terms,
	);
}

/**
 * Taxonomies proposées comme filtres sur la page de liste d'un type.
 *
 * @return string[]
 */
function nb_base_entry_filter_taxonomies( string $post_type ): array {
	$settings = nb_base_entry_settings( $post_type );
	if ( ! $settings ) {
		return array();
	}
	$list = isset( $settings['filter_taxonomies'] ) && is_array( $settings['filter_taxonomies'] )
		? $settings['filter_taxonomies']
		: array( $settings['taxonomy'] );
	return array_values( array_filter( array_map( 'strval', $list ), 'taxonomy_exists' ) );
}

/**
 * Page de liste d'un type de contenu (bloc nb-base/entry-archive) : tous les
 * contenus publiés, du plus récent au plus ancien, et les filtres.
 *
 * - ids : contenus ;
 * - terms[<id>] : catégories de chaque contenu, catégories parentes comprises
 *   (cocher une catégorie parente affiche aussi le contenu de ses enfants) ;
 * - groups : un groupe par taxonomie de filtre ayant au moins une catégorie
 *   utilisée (libellé = nom pluriel de la taxonomie).
 *
 * @return array{ids: int[], terms: array<int, int[]>, groups: array<int, array{taxonomy: string, label: string, terms: WP_Term[]}>}
 */
function nb_base_entry_archive_items( string $post_type ): array {
	$ids = array_map(
		'intval',
		get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'fields'         => 'ids',
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		)
	);
	$data = array(
		'ids'    => $ids,
		'terms'  => array_fill_keys( $ids, array() ),
		'groups' => array(),
	);
	if ( ! $ids ) {
		return $data;
	}

	update_object_term_cache( $ids, $post_type );
	foreach ( nb_base_entry_filter_taxonomies( $post_type ) as $taxonomy ) {
		$used = array();
		foreach ( $ids as $id ) {
			$terms = get_the_terms( $id, $taxonomy );
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$used[ $term->term_id ] = $term;
				$data['terms'][ $id ]   = array_merge( $data['terms'][ $id ], array( (int) $term->term_id ), array_map( 'intval', get_ancestors( $term->term_id, $taxonomy, 'taxonomy' ) ) );
			}
		}
		if ( ! $used ) {
			continue;
		}
		$used = nb_base_sort_terms( array_values( $used ) );
		$object           = get_taxonomy( $taxonomy );
		$data['groups'][] = array(
			'taxonomy' => $taxonomy,
			'label'    => $object ? (string) $object->labels->name : $taxonomy,
			'terms'    => $used,
		);
	}
	$data['terms'] = array_map( static fn( $terms ) => array_values( array_unique( $terms ) ), $data['terms'] );
	return $data;
}

/**
 * Page de liste d'un type de contenu structuré : tous les contenus sur une
 * seule page (le filtrage se fait dans la page, sans rechargement).
 */
add_action(
	'pre_get_posts',
	static function ( WP_Query $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive() ) {
			return;
		}
		$type = $query->get( 'post_type' );
		if ( is_string( $type ) && nb_base_entry_settings( $type ) ) {
			$query->set( 'posts_per_page', -1 );
		}
	}
);

/**
 * HTML de boutons natifs (core/buttons), rendus par WordPress : mêmes styles
 * et mêmes extensions (flèche) que les boutons placés dans les pages.
 *
 * @param array<int, array{text: string, url: string, style?: string, arrow?: bool}> $buttons
 */
function nb_base_buttons_html( array $buttons ): string {
	$markup = '';
	foreach ( $buttons as $button ) {
		$attrs = array();
		$class = 'wp-block-button';
		if ( ! empty( $button['style'] ) ) {
			$attrs['className'] = 'is-style-' . $button['style'];
			$class             .= ' is-style-' . $button['style'];
		}
		if ( ! empty( $button['arrow'] ) ) {
			$attrs['nbShowArrow'] = true;
		}
		$markup .= '<!-- wp:button ' . ( $attrs ? wp_json_encode( $attrs ) . ' ' : '' ) . '-->'
			. '<div class="' . esc_attr( $class ) . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $button['url'] ) . '">' . esc_html( $button['text'] ) . '</a></div>'
			. '<!-- /wp:button -->';
	}
	return do_blocks( '<!-- wp:buttons --><div class="wp-block-buttons">' . $markup . '</div><!-- /wp:buttons -->' );
}

/**
 * Carte d'un contenu (image mise en avant, titre, extrait, lien), même
 * balisage que les cartes des grilles statiques, cliquable sur toute sa
 * surface (classe nb-card--linked).
 */
function nb_base_entry_card_html( int $post_id, string $link_label ): string {
	// Carte propre au type de contenu, s'il en déclare une.
	$settings = nb_base_entry_settings( (string) get_post_type( $post_id ) );
	if ( $settings && isset( $settings['card_callback'] ) && is_callable( $settings['card_callback'] ) ) {
		return (string) call_user_func( $settings['card_callback'], $post_id, $link_label );
	}
	return nb_base_card_html(
		array(
			'image_id' => (int) get_post_thumbnail_id( $post_id ),
			'title'    => esc_html( get_the_title( $post_id ) ),
			'text'     => esc_html( has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : '' ),
			'actions'  => nb_base_buttons_html(
				array(
					array(
						'text'  => $link_label,
						'url'   => (string) get_permalink( $post_id ),
						'style' => 'nb-link',
						'arrow' => true,
					),
				)
			),
		),
		// Carte entièrement cliquable (lien étendu, voir src/blocks/card/style.scss).
		'class="wp-block-nb-base-card nb-card--linked"'
	);
}

/**
 * Supprime les éléments de texte vides (paragraphe, titre) d'un contenu libre :
 * un élément vide n'est jamais affiché.
 */
function nb_base_strip_empty_text( string $html ): string {
	return (string) preg_replace( '#<(p|h[1-6])\b[^>]*>(\s|&nbsp;|<br\s*/?>)*</\1>#i', '', $html );
}

/**
 * Éléments du fil d'Ariane : Accueil, page des contenus (ou pages parentes),
 * page courante (sans lien).
 *
 * @return array<int, array{label: string, url: string}>
 */
function nb_base_breadcrumb_items( int $post_id = 0 ): array {
	$items = array(
		array(
			'label' => __( 'Home', 'nb-base' ),
			'url'   => home_url( '/' ),
		),
	);

	if ( ! $post_id && is_singular() ) {
		$post_id = (int) get_queried_object_id();
	}

	if ( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || (int) get_option( 'page_on_front' ) === $post_id ) {
			return array();
		}
		$type = get_post_type_object( $post->post_type );
		if ( $type && $type->has_archive ) {
			$items[] = array(
				'label' => (string) $type->labels->name,
				'url'   => (string) get_post_type_archive_link( $post->post_type ),
			);
		} elseif ( 'post' === $post->post_type && get_option( 'page_for_posts' ) ) {
			$blog    = (int) get_option( 'page_for_posts' );
			$items[] = array(
				'label' => get_the_title( $blog ),
				'url'   => (string) get_permalink( $blog ),
			);
		}
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
			$items[] = array(
				'label' => get_the_title( $ancestor ),
				'url'   => (string) get_permalink( $ancestor ),
			);
		}
		$items[] = array(
			'label' => get_the_title( $post ),
			'url'   => '',
		);
		return $items;
	}

	if ( is_post_type_archive() ) {
		$items[] = array(
			'label' => post_type_archive_title( '', false ),
			'url'   => '',
		);
	} elseif ( is_tax() || is_category() || is_tag() ) {
		$items[] = array(
			'label' => single_term_title( '', false ),
			'url'   => '',
		);
	} else {
		return array();
	}
	return $items;
}

/**
 * HTML du fil d'Ariane (vide s'il n'y a rien avant la page courante).
 *
 * @param int    $post_id            Contenu courant (0 = page affichée).
 * @param string $wrapper_attributes Attributs de l'élément racine.
 */
function nb_base_breadcrumb_html( int $post_id = 0, string $wrapper_attributes = 'class="wp-block-nb-base-breadcrumb"' ): string {
	return nb_base_breadcrumb_list_html( nb_base_breadcrumb_items( $post_id ), $wrapper_attributes );
}

/**
 * HTML d'un fil d'Ariane à partir de ses éléments (vide s'il y en a moins de deux).
 *
 * @param array<int, array{label: string, url: string}> $items
 * @param string                                        $wrapper_attributes Attributs de l'élément racine.
 */
function nb_base_breadcrumb_list_html( array $items, string $wrapper_attributes = 'class="wp-block-nb-base-breadcrumb"' ): string {
	if ( count( $items ) < 2 ) {
		return '';
	}
	$html = '<nav ' . $wrapper_attributes . ' aria-label="' . esc_attr__( 'Breadcrumb', 'nb-base' ) . '"><ol class="nb-breadcrumb__list">';
	foreach ( $items as $item ) {
		$label = esc_html( wp_strip_all_tags( $item['label'] ) );
		$html .= '<li class="nb-breadcrumb__item">'
			. ( '' !== $item['url'] ? '<a href="' . esc_url( $item['url'] ) . '">' . $label . '</a>' : '<span aria-current="page">' . $label . '</span>' )
			. '</li>';
	}
	return $html . '</ol></nav>';
}

/**
 * Réglages des contenus structurés pour l'éditeur (window.nbBaseEntries).
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$data = array();
		foreach ( get_post_types( array( 'show_in_rest' => true ), 'objects' ) as $type ) {
			$settings = nb_base_entry_settings( $type->name );
			if ( ! $settings ) {
				continue;
			}
			$taxonomy                 = get_taxonomy( $settings['taxonomy'] );
			$data[ $type->name ]      = array(
				'taxonomy'         => $settings['taxonomy'],
				'taxonomyRestBase' => $taxonomy ? ( $taxonomy->rest_base ? $taxonomy->rest_base : $taxonomy->name ) : '',
				'taxonomyLabel'    => $taxonomy ? (string) $taxonomy->labels->singular_name : '',
				'taxonomyName'     => $taxonomy ? (string) $taxonomy->labels->name : '',
				'categoryLinkLabel' => nb_base_in_site_locale( static fn() => __( 'Discover', 'nb-base' ) ),
				'name'             => (string) $type->labels->name,
				'filterAllLabel'   => nb_base_in_site_locale( static fn() => __( 'All', 'nb-base' ) ),
				'hasArchive'       => (bool) $type->has_archive,
				'archiveLabel'     => $type->has_archive ? (string) $type->labels->name : '',
				'characteristics'  => $settings['characteristics'],
				'galleryTitle'     => $settings['gallery_title'],
				'relatedTitle'     => $settings['related_title'],
				'viewAllLabel'     => $settings['view_all_label'],
				'cardLinkLabel'    => $settings['card_link_label'],
				'titlePlaceholder' => (string) ( $settings['title_placeholder'] ?? '' ),
			);
		}
		wp_add_inline_script(
			'nb-base-editor',
			'window.nbBaseEntries = ' . wp_json_encode( (object) $data ) . ';',
			'before'
		);
	}
);
