<?php
/**
 * Module « Produits » : type de contenu, catégorie, prix, photos, arguments
 * communs (« Produit en stock », « Livraison »…) et mise en page figée dans
 * l'éditeur (fiche produit, autres produits). Page liste : même bloc que les
 * réalisations (nb-base/entry-archive).
 *
 * Clés internes définitives : nb_product (type), nb_product_cat (catégorie),
 * métadonnées nb_price_ht, nb_price_ttc, nb_product_images ; option du site
 * nb_base_product_features (arguments, modifiables par le client depuis la
 * fiche). Noms affichés, adresse, taux de TVA… : page NB Base, par site.
 *
 * Fonctionnalité « products » (désactivée par défaut). Désactivée alors que
 * des produits sont publiés : le type reste enregistré (les pages restent en
 * ligne) mais disparaît de l'administration.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_PRODUCT_TYPE      = 'nb_product';
const NB_BASE_PRODUCT_TAXONOMY  = 'nb_product_cat';
const NB_BASE_PRODUCTS_OPTION   = 'nb_base_products';
const NB_BASE_PRODUCT_FEATURES  = 'nb_base_product_features';
const NB_BASE_PRICE_HT_META     = 'nb_price_ht';
const NB_BASE_PRICE_TTC_META    = 'nb_price_ttc';
const NB_BASE_PRODUCT_IMAGES    = 'nb_product_images';
const NB_BASE_PRODUCT_MAX_IMAGE = 12;

/**
 * Réglages par défaut (textes traduisibles ; l'adresse n'est pas traduite).
 */
function nb_base_products_defaults(): array {
	return array(
		'name'            => __( 'Products', 'nb-base' ),
		'singular_name'   => __( 'Product', 'nb-base' ),
		'slug'            => 'produits',
		'tax_name'        => __( 'Categories', 'nb-base' ),
		'tax_singular'    => __( 'Category', 'nb-base' ),
		'related_title'   => __( 'Other products', 'nb-base' ),
		'view_all_label'  => __( 'View all products', 'nb-base' ),
		'card_link_label' => __( 'View product', 'nb-base' ),
		'add_new_label'   => __( 'Add a product', 'nb-base' ),
		'quote_label'     => __( 'Request a quote', 'nb-base' ),
		'quote_url'       => '#devis',
		'vat_rate'        => '20',
		'currency'        => '€',
		'currency_code'   => 'EUR',
	);
}

/**
 * Réglages enregistrés par le designer (seules les valeurs modifiées).
 */
function nb_base_products_saved(): array {
	$saved = get_option( NB_BASE_PRODUCTS_OPTION, array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Réglages effectifs : valeurs du designer, sinon valeurs par défaut.
 */
function nb_base_products_config(): array {
	$config = nb_base_products_defaults();
	foreach ( nb_base_products_saved() as $key => $value ) {
		if ( array_key_exists( $key, $config ) && '' !== trim( (string) $value ) ) {
			$config[ $key ] = (string) $value;
		}
	}
	return $config;
}

/**
 * Taux de TVA (%), entre 0 et 100.
 */
function nb_base_products_vat_rate(): float {
	$rate = nb_base_price_to_number( nb_base_products_config()['vat_rate'] );
	return null === $rate ? 20.0 : max( 0.0, min( 100.0, $rate ) );
}

/**
 * Fonctionnalité.
 */
add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['products'] = array(
			'group'       => 'content',
			'label'       => __( 'Products', 'nb-base' ),
			'description' => __( 'Products content type: category, photos, price excl. and incl. VAT, quote button, shared highlights, fixed page layout (product sheet, other products). Same list page as projects.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Le type est-il enregistré, et visible dans l'administration ?
 *
 * @return array{registered: bool, ui: bool}
 */
function nb_base_products_state(): array {
	if ( nb_base_feature_enabled( 'products' ) ) {
		return array(
			'registered' => true,
			'ui'         => true,
		);
	}
	// wp_count_posts() renvoie 0 pour un type pas encore enregistré : requête directe.
	$published = new WP_Query(
		array(
			'post_type'              => NB_BASE_PRODUCT_TYPE,
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'suppress_filters'       => true,
		)
	);
	return array(
		'registered' => (bool) $published->posts,
		'ui'         => false,
	);
}

/**
 * Mise en page figée de chaque produit (blocs verrouillés, sauf la
 * description et les questions de la FAQ) : fiche, FAQ (fonctionnalité
 * « faq » ; masquée tant qu'aucune question n'est remplie), « Autres
 * produits » sur fond alt ; puis formulaire de devis sans fond (template
 * single-nb_product.html). Appliquée à la création ; les produits existants
 * gardent la leur.
 */
function nb_base_product_template(): array {
	return array_values(
		array_filter(
			array(
				array( 'nb-base/product-summary' ),
				nb_base_faq_template_block(),
				array( 'nb-base/entry-carousel', array( 'background' => 'alt' ) ),
			)
		)
	);
}

/* -------------------------------------------------------------------------
 * Prix.
 * ---------------------------------------------------------------------- */

/**
 * Prix saisi (« 1 250,50 », « 1250.5 », « 1 250 € »…) → nombre, ou null.
 *
 * @param mixed $value Valeur saisie.
 */
function nb_base_price_to_number( $value ): ?float {
	$value = preg_replace( '/[^0-9,.\-]/', '', (string) $value );
	if ( '' === $value || '-' === $value ) {
		return null;
	}
	// Dernière virgule ou dernier point = décimales ; les autres = milliers.
	$last = max( (int) strrpos( $value, ',' ), (int) strrpos( $value, '.' ) );
	if ( false !== strpbrk( $value, ',.' ) && strlen( $value ) - $last - 1 <= 2 ) {
		$value = str_replace( array( ',', '.' ), '', substr( $value, 0, $last ) ) . '.' . substr( $value, $last + 1 );
	} else {
		$value = str_replace( array( ',', '.' ), '', $value );
	}
	return is_numeric( $value ) ? round( (float) $value, 2 ) : null;
}

/**
 * Métadonnée de prix nettoyée : nombre au format « 1250.50 », ou chaîne vide.
 *
 * @param mixed $value Valeur reçue.
 */
function nb_base_sanitize_price( $value ): string {
	$number = nb_base_price_to_number( $value );
	return null === $number || $number < 0 ? '' : number_format( $number, 2, '.', '' );
}

/**
 * Prix d'un produit : HT saisi ; TTC saisi, sinon calculé (taux du site).
 *
 * @return array{ht: ?float, ttc: ?float}
 */
function nb_base_product_prices( int $post_id ): array {
	$ht  = nb_base_price_to_number( get_post_meta( $post_id, NB_BASE_PRICE_HT_META, true ) );
	$ttc = nb_base_price_to_number( get_post_meta( $post_id, NB_BASE_PRICE_TTC_META, true ) );
	if ( null === $ttc && null !== $ht ) {
		$ttc = round( $ht * ( 1 + nb_base_products_vat_rate() / 100 ), 2 );
	}
	return array(
		'ht'  => $ht,
		'ttc' => $ttc,
	);
}

/**
 * Prix affiché : « 1 250,00€ » (séparateurs de la langue du site).
 */
function nb_base_format_price( float $price ): string {
	return number_format_i18n( $price, 2 ) . nb_base_products_config()['currency'];
}

/* -------------------------------------------------------------------------
 * Photos.
 * ---------------------------------------------------------------------- */

/**
 * Photos d'un produit : image mise en avant (reprise par les cartes), puis
 * photos supplémentaires. Identifiants d'images existantes, sans doublon.
 *
 * @return int[]
 */
function nb_base_product_image_ids( int $post_id ): array {
	$ids = array_merge(
		array( (int) get_post_thumbnail_id( $post_id ) ),
		array_map( 'intval', (array) get_post_meta( $post_id, NB_BASE_PRODUCT_IMAGES, true ) )
	);
	$ids = array_values( array_unique( array_filter( $ids, static fn( $id ) => $id > 0 && wp_attachment_is_image( $id ) ) ) );
	return array_slice( $ids, 0, NB_BASE_PRODUCT_MAX_IMAGE + 1 );
}

/* -------------------------------------------------------------------------
 * Arguments communs (« Produit en stock à l'atelier »…).
 * ---------------------------------------------------------------------- */

/**
 * Arguments nettoyés : liste de { icon, text }, 8 au plus, texte non vide.
 *
 * @param mixed $value Valeur enregistrée ou reçue.
 * @return array<int, array{icon: string, text: string}>
 */
function nb_base_sanitize_product_features( $value ): array {
	$clean = array();
	foreach ( (array) $value as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		$text = sanitize_text_field( (string) ( $item['text'] ?? '' ) );
		if ( '' === $text ) {
			continue;
		}
		$clean[] = array(
			'icon' => sanitize_key( (string) ( $item['icon'] ?? '' ) ),
			'text' => $text,
		);
	}
	return array_slice( $clean, 0, 8 );
}

/**
 * Arguments affichés sur toutes les fiches produit.
 *
 * @return array<int, array{icon: string, text: string}>
 */
function nb_base_product_features(): array {
	return nb_base_sanitize_product_features( get_option( NB_BASE_PRODUCT_FEATURES, array() ) );
}

/* -------------------------------------------------------------------------
 * Enregistrement.
 * ---------------------------------------------------------------------- */

add_action(
	'init',
	static function () {
		// Arguments communs : option du site, modifiable par le client depuis la fiche.
		register_setting(
			'nb_base',
			NB_BASE_PRODUCT_FEATURES,
			array(
				'type'              => 'array',
				'description'       => __( 'Highlights shown on every product sheet.', 'nb-base' ),
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'icon' => array( 'type' => 'string' ),
								'text' => array( 'type' => 'string' ),
							),
						),
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_product_features',
			)
		);

		$state = nb_base_products_state();
		if ( ! $state['registered'] ) {
			return;
		}
		$config = nb_base_products_config();

		register_post_type(
			NB_BASE_PRODUCT_TYPE,
			array(
				'labels'        => array(
					'name'          => $config['name'],
					'singular_name' => $config['singular_name'],
					'menu_name'     => $config['name'],
					'all_items'     => $config['name'],
					'add_new'       => $config['add_new_label'],
					'add_new_item'  => $config['add_new_label'],
				),
				'public'        => true,
				'show_ui'       => $state['ui'],
				'show_in_menu'  => $state['ui'],
				'show_in_rest'  => true,
				'menu_position' => 22,
				'menu_icon'     => 'dashicons-products',
				'has_archive'   => $config['slug'],
				'rewrite'       => array(
					'slug'       => $config['slug'],
					'with_front' => false,
				),
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
				'template'      => nb_base_product_template(),
				'template_lock' => 'all',
			)
		);

		register_taxonomy(
			NB_BASE_PRODUCT_TAXONOMY,
			NB_BASE_PRODUCT_TYPE,
			array(
				'labels'            => array(
					'name'          => $config['tax_name'],
					'singular_name' => $config['tax_singular'],
					'menu_name'     => $config['tax_name'],
				),
				// Pas de page publique par catégorie (elle doublerait la page
				// liste) : utilisée dans l'administration et comme filtre seulement.
				'public'            => false,
				'hierarchical'      => true,
				'show_ui'           => $state['ui'],
				'show_in_rest'      => true,
				'show_admin_column' => true,
			)
		);

		$auth = static fn( $allowed, $meta_key, $post_id ) => current_user_can( 'edit_post', $post_id );
		foreach ( array( NB_BASE_PRICE_HT_META, NB_BASE_PRICE_TTC_META ) as $key ) {
			register_post_meta(
				NB_BASE_PRODUCT_TYPE,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'nb_base_sanitize_price',
					'auth_callback'     => $auth,
				)
			);
		}
		register_post_meta(
			NB_BASE_PRODUCT_TYPE,
			NB_BASE_PRODUCT_IMAGES,
			array(
				'type'              => 'array',
				'single'            => true,
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'integer' ),
					),
				),
				'sanitize_callback' => static fn( $value ) => array_slice( array_values( array_filter( array_map( 'absint', (array) $value ) ) ), 0, NB_BASE_PRODUCT_MAX_IMAGE ),
				'auth_callback'     => $auth,
			)
		);
	}
);
add_filter( 'option_' . NB_BASE_PRODUCT_FEATURES, 'nb_base_sanitize_product_features' );

/**
 * Réglages communs aux blocs des contenus structurés (inc/entries.php).
 */
add_filter(
	'nb_base_entry_settings',
	static function ( $settings, string $post_type ) {
		if ( NB_BASE_PRODUCT_TYPE !== $post_type ) {
			return $settings;
		}
		$config = nb_base_products_config();
		return array(
			'taxonomy'          => NB_BASE_PRODUCT_TAXONOMY,
			'characteristics'   => array(),
			'gallery_title'     => '',
			'related_title'     => $config['related_title'],
			'view_all_label'    => $config['view_all_label'],
			'card_link_label'   => $config['card_link_label'],
			'title_placeholder' => __( 'Product name', 'nb-base' ),
		);
	},
	10,
	2
);

/**
 * Réglages de la fiche produit pour l'éditeur (window.nbBaseProducts) :
 * aperçu des prix et du bouton, dans la langue du site.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		if ( ! nb_base_products_state()['registered'] ) {
			return;
		}
		$config = nb_base_in_site_locale( 'nb_base_products_config' );
		wp_add_inline_script(
			'nb-base-editor',
			'window.nbBaseProducts = ' . wp_json_encode(
				array(
					'vatRate'    => nb_base_products_vat_rate(),
					'currency'   => $config['currency'],
					'quoteLabel' => $config['quote_label'],
					'maxImages'  => NB_BASE_PRODUCT_MAX_IMAGE,
					'locale'     => str_replace( '_', '-', get_locale() ),
				)
			) . ';',
			'before'
		);
	}
);

/**
 * Éditeur d'un produit : le titre est saisi directement dans la fiche ; le
 * champ de titre natif est masqué (aucune API ne permet de le retirer : voir
 * README, « Points dépendant de l'interface »), comme pour les réalisations.
 */
add_action(
	'enqueue_block_assets',
	static function () {
		if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || NB_BASE_PRODUCT_TYPE !== $screen->post_type ) {
			return;
		}
		wp_register_style( 'nb-base-product-editor', false, array(), NB_BASE_VERSION );
		wp_enqueue_style( 'nb-base-product-editor' );
		wp_add_inline_style( 'nb-base-product-editor', '.editor-visual-editor__post-title-wrapper{display:none!important}' );
	}
);

/* -------------------------------------------------------------------------
 * Page NB Base : onglet « Produits » (designer), affiché même si la
 * fonctionnalité est désactivée.
 * ---------------------------------------------------------------------- */

add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		$tabs['products'] = array(
			'label'  => __( 'Products', 'nb-base' ),
			'render' => 'nb_base_products_admin_tab',
		);
		return $tabs;
	}
);

/**
 * Contenu de l'onglet.
 */
function nb_base_products_admin_tab(): void {
	$saved    = nb_base_products_saved();
	$defaults = nb_base_products_defaults();
	$fields   = array(
		'name'            => __( 'Name (plural)', 'nb-base' ),
		'singular_name'   => __( 'Name (singular)', 'nb-base' ),
		'slug'            => __( 'URL slug', 'nb-base' ),
		'tax_name'        => __( 'Category name (plural)', 'nb-base' ),
		'tax_singular'    => __( 'Category name (singular)', 'nb-base' ),
		'related_title'   => __( '“Other products” title', 'nb-base' ),
		'view_all_label'  => __( '“View all” button', 'nb-base' ),
		'card_link_label' => __( 'Card link', 'nb-base' ),
		'add_new_label'   => __( '“Add” button (administration)', 'nb-base' ),
		'quote_label'     => __( 'Quote button', 'nb-base' ),
		'quote_url'       => __( 'Quote button link', 'nb-base' ),
		'vat_rate'        => __( 'VAT rate (%)', 'nb-base' ),
		'currency'        => __( 'Currency symbol', 'nb-base' ),
		'currency_code'   => __( 'Currency code (ISO)', 'nb-base' ),
	);
	$help     = array(
		'quote_url' => __( 'Anchor of the quote form at the bottom of the product sheet (#devis), or a page address.', 'nb-base' ),
		'currency_code' => __( 'Three letters (EUR, CHF…), for search engines (structured data).', 'nb-base' ),
		'vat_rate'  => __( 'Used to compute the price incl. VAT from the price excl. VAT (the price incl. VAT can be adjusted on each product).', 'nb-base' ),
	);
	?>
	<?php if ( ! nb_base_feature_enabled( 'products' ) ) : ?>
		<p class="description"><?php esc_html_e( 'The “Products” feature is disabled on this site.', 'nb-base' ); ?></p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_products">
		<?php wp_nonce_field( 'nb_base_save_products' ); ?>
		<p class="description"><?php esc_html_e( 'Leave a field empty to use the default value (shown in grey). Changing a URL slug changes the address of every page concerned.', 'nb-base' ); ?></p>
		<table class="form-table" role="presentation"><tbody>
		<?php foreach ( $fields as $key => $label ) : ?>
			<tr>
				<th scope="row"><label for="nb-prod-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
				<td>
					<input type="text" class="<?php echo in_array( $key, array( 'vat_rate', 'currency', 'currency_code' ), true ) ? 'small-text' : 'regular-text'; ?>" id="nb-prod-<?php echo esc_attr( $key ); ?>" name="products[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) ( $saved[ $key ] ?? '' ) ); ?>" placeholder="<?php echo esc_attr( $defaults[ $key ] ); ?>">
					<?php if ( isset( $help[ $key ] ) ) : ?>
						<p class="description"><?php echo esc_html( $help[ $key ] ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody></table>
		<p class="description"><?php esc_html_e( 'The highlights shown on every product sheet (icon and text) are edited by the client from any product sheet (right column).', 'nb-base' ); ?></p>
		<?php nb_base_archive_seo_fields( NB_BASE_PRODUCT_TYPE ); ?>
		<?php submit_button( __( 'Save products settings', 'nb-base' ) ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_products',
	static function () {
		nb_base_admin_guard( 'nb_base_save_products' );
		$input    = isset( $_POST['products'] ) && is_array( $_POST['products'] ) ? wp_unslash( $_POST['products'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$previous = nb_base_products_saved();
		$clean    = array();
		foreach ( array_keys( nb_base_products_defaults() ) as $key ) {
			$value = sanitize_text_field( (string) ( $input[ $key ] ?? '' ) );
			if ( 'slug' === $key ) {
				$value = sanitize_title( $value );
			} elseif ( 'vat_rate' === $key && '' !== $value ) {
				$rate  = nb_base_price_to_number( $value );
				$value = null === $rate ? '' : (string) max( 0, min( 100, $rate ) );
			} elseif ( 'quote_url' === $key && '' !== $value && '#' !== $value[0] ) {
				$value = esc_url_raw( $value );
			} elseif ( 'quote_url' === $key ) {
				$value = '' === $value ? '' : '#' . sanitize_html_class( substr( $value, 1 ) );
			} elseif ( 'currency_code' === $key ) {
				$value = preg_match( '/^[A-Za-z]{3}$/', $value ) ? strtoupper( $value ) : '';
			} elseif ( 'currency' === $key ) {
				$value = mb_substr( $value, 0, 5 );
			}
			$clean[ $key ] = $value;
		}

		update_option( NB_BASE_PRODUCTS_OPTION, $clean, true );
		nb_base_archive_seo_save( NB_BASE_PRODUCT_TYPE );
		if ( ( $previous['slug'] ?? '' ) !== $clean['slug'] ) {
			update_option( NB_BASE_FLUSH_REWRITE_OPTION, 1, true );
		}
		nb_base_admin_redirect( 'products-saved', 'products' );
	}
);
