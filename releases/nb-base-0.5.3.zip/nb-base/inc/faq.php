<?php
/**
 * FAQ (blocs nb-base/faq > faq-list > faq-item) :
 * - fonctionnalité « faq » (désactivée par défaut) : bloc dans l'inserteur
 *   des pages et section FAQ dans la mise en page des contenus structurés
 *   (réalisations, produits) créés ensuite ;
 * - questions d'une liste de blocs (rendu et données structurées) ;
 * - contenus structurés existants (créés avant l'activation) : section FAQ
 *   ajoutée automatiquement, une fois par site (voir plus bas) ;
 * - données structurées FAQPage (fonctionnalité « structured-data ») : une
 *   seule FAQPage par page, toutes sections FAQ confondues, uniquement les
 *   questions affichées (question et réponse remplies).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/** Option : section FAQ ajoutée aux contenus structurés existants (1 = fait). */
const NB_BASE_FAQ_ENTRIES_OPTION = 'nb_base_faq_entries_done';

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['faq'] = array(
			'group'       => 'blocks',
			'label'       => __( 'FAQ', 'nb-base' ),
			'description' => __( 'Section with frequently asked questions in an accordion, on pages and in projects and products (with schema.org FAQPage data when structured data is enabled).', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/faq' ),
		);
		return $features;
	}
);

/**
 * Texte d'une question ou d'une réponse (HTML du champ) en texte brut ;
 * les retours à la ligne (<br>) deviennent des sauts de ligne.
 */
function nb_base_faq_plain( string $html ): string {
	$text = (string) preg_replace( '/<br\s*\/?>/i', "\n", $html );
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	$text = (string) preg_replace( '/[ \t]+/', ' ', $text );
	return trim( (string) preg_replace( '/ *\n */', "\n", $text ) );
}

/**
 * Question complète d'un bloc nb-base/faq-item, sinon null.
 *
 * @param array $attributes Attributs du bloc.
 * @return array{question: string, answer: string}|null
 */
function nb_base_faq_entry( array $attributes ): ?array {
	$question = str_replace( "\n", ' ', nb_base_faq_plain( (string) ( $attributes['question'] ?? '' ) ) );
	$answer   = nb_base_faq_plain( (string) ( $attributes['answer'] ?? '' ) );
	if ( '' === $question || '' === $answer ) {
		return null;
	}
	return array(
		'question' => $question,
		'answer'   => $answer,
	);
}

/**
 * Questions complètes contenues dans une liste de blocs analysés
 * (parse_blocks()), compositions synchronisées comprises.
 *
 * @param array $blocks Blocs analysés.
 * @param int   $depth  Profondeur des compositions synchronisées (anti-boucle).
 * @return array<int, array{question: string, answer: string}>
 */
function nb_base_faq_entries( array $blocks, int $depth = 0 ): array {
	$entries = array();
	foreach ( $blocks as $block ) {
		$name = $block['blockName'] ?? '';
		if ( 'nb-base/faq-item' === $name ) {
			$entry = nb_base_faq_entry( (array) ( $block['attrs'] ?? array() ) );
			if ( $entry ) {
				$entries[] = $entry;
			}
			continue;
		}
		if ( 'core/block' === $name && $depth < 3 && ! empty( $block['attrs']['ref'] ) ) {
			$pattern = get_post( (int) $block['attrs']['ref'] );
			if ( $pattern && 'wp_block' === $pattern->post_type && 'publish' === $pattern->post_status ) {
				$entries = array_merge( $entries, nb_base_faq_entries( parse_blocks( $pattern->post_content ), $depth + 1 ) );
			}
			continue;
		}
		if ( ! empty( $block['innerBlocks'] ) ) {
			$entries = array_merge( $entries, nb_base_faq_entries( $block['innerBlocks'], $depth ) );
		}
	}
	return $entries;
}

/**
 * Section FAQ ajoutée à la mise en page des contenus structurés : en-tête
 * « Questions fréquentes » (langue du site), une question vide. Tant
 * qu'aucune question n'est remplie, la section n'est pas affichée.
 * Fonctionnalité désactivée : rien (tableau vide).
 *
 * @return array Bloc au format des modèles de type de contenu, ou array().
 */
function nb_base_faq_template_block(): array {
	if ( ! nb_base_feature_enabled( 'faq' ) ) {
		return array();
	}
	$lock  = array(
		'move'   => true,
		'remove' => true,
	);
	$title = nb_base_in_site_locale( static fn() => __( 'Frequently asked questions', 'nb-base' ) );
	return array(
		'nb-base/faq',
		array(),
		array(
			array(
				'nb-base/section-header',
				array(
					'lock'      => $lock,
					'alignment' => 'center',
					'title'     => $title,
				),
			),
			array( 'nb-base/faq-list', array( 'lock' => $lock ), array( array( 'nb-base/faq-item' ) ) ),
		),
	);
}

/**
 * Données structurées : FAQPage de la page ou du contenu affiché.
 */
add_filter(
	'nb_base_structured_data',
	static function ( array $graph ): array {
		if ( ! is_singular() ) {
			return $graph;
		}
		$post = get_queried_object();
		if ( ! ( $post instanceof WP_Post ) || ( ! has_block( 'nb-base/faq', $post ) && ! has_block( 'core/block', $post ) ) ) {
			return $graph;
		}
		$questions = array();
		foreach ( nb_base_faq_entries( parse_blocks( $post->post_content ) ) as $entry ) {
			// Même question en double : une seule fois.
			$questions[ $entry['question'] ] = array(
				'@type'          => 'Question',
				'name'           => $entry['question'],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $entry['answer'],
				),
			);
		}
		if ( ! $questions ) {
			return $graph;
		}
		$graph[] = array(
			'@type'      => 'FAQPage',
			'@id'        => get_permalink( $post ) . '#faq',
			'url'        => get_permalink( $post ),
			'mainEntity' => array_values( $questions ),
		);
		return $graph;
	}
);

/* -------------------------------------------------------------------------
 * Contenus structurés existants : ajout de la section FAQ.
 *
 * La mise en page d'un type n'est appliquée qu'à la création : les
 * réalisations et produits créés avant l'activation de la FAQ (ou avant la
 * mise à jour du thème) n'ont pas la section, et leur mise en page
 * verrouillée empêche de l'insérer. Une fois par site, dans
 * l'administration, la section (vide, donc invisible sur le site) est
 * ajoutée avant « Autres réalisations / produits » (sinon à la fin) de
 * chaque contenu qui ne l'a pas. Relancé après chaque changement des
 * fonctionnalités (contenus créés pendant que la FAQ était désactivée,
 * nouveau type activé). Contenu existant inchangé, date de modification
 * conservée, pas de révision.
 * ---------------------------------------------------------------------- */

/**
 * Types de contenu dont la mise en page comprend la FAQ.
 *
 * @return string[]
 */
function nb_base_faq_post_types(): array {
	$types = array();
	if ( defined( 'NB_BASE_REALISATION_TYPE' ) ) {
		$types[] = NB_BASE_REALISATION_TYPE;
	}
	if ( defined( 'NB_BASE_PRODUCT_TYPE' ) ) {
		$types[] = NB_BASE_PRODUCT_TYPE;
	}
	return (array) apply_filters( 'nb_base_faq_post_types', $types );
}

/**
 * Bloc au format des modèles (nom, attributs, blocs intérieurs) -> bloc
 * analysé, pour serialize_blocks(). Blocs dynamiques : pas de HTML propre.
 *
 * @param array $item Bloc au format des modèles.
 */
function nb_base_faq_template_to_block( array $item ): array {
	$inner = array_map( 'nb_base_faq_template_to_block', (array) ( $item[2] ?? array() ) );
	$parts = array();
	foreach ( $inner as $unused ) {
		$parts[] = "\n";
		$parts[] = null;
	}
	if ( $inner ) {
		$parts[] = "\n";
	}
	return array(
		'blockName'    => $item[0],
		'attrs'        => (array) ( $item[1] ?? array() ),
		'innerBlocks'  => $inner,
		'innerHTML'    => $inner ? str_repeat( "\n", count( $inner ) + 1 ) : '',
		'innerContent' => $parts,
	);
}

/**
 * Contenu avec la section FAQ ajoutée, ou null s'il en a déjà une.
 *
 * @param string $content Contenu (blocs sérialisés).
 */
function nb_base_faq_add_to_content( string $content ): ?string {
	$template = nb_base_faq_template_block();
	if ( ! $template ) {
		return null;
	}
	$blocks = parse_blocks( $content );
	foreach ( $blocks as $block ) {
		if ( 'nb-base/faq' === ( $block['blockName'] ?? '' ) ) {
			return null;
		}
	}
	$position = count( $blocks );
	foreach ( $blocks as $i => $block ) {
		if ( 'nb-base/entry-carousel' === ( $block['blockName'] ?? '' ) ) {
			$position = $i;
			break;
		}
	}
	$faq = nb_base_faq_template_to_block( $template );
	// Séparateur entre blocs (comme l'éditeur) : bloc « vide » de saut de ligne.
	$newline = array(
		'blockName'    => null,
		'attrs'        => array(),
		'innerBlocks'  => array(),
		'innerHTML'    => "\n\n",
		'innerContent' => array( "\n\n" ),
	);
	array_splice( $blocks, $position, 0, array( $faq, $newline ) );
	return serialize_blocks( $blocks );
}

/**
 * Ajoute la section FAQ aux contenus structurés qui ne l'ont pas.
 *
 * @return int Nombre de contenus modifiés.
 */
function nb_base_faq_update_entries(): int {
	$types = array_values( array_filter( nb_base_faq_post_types(), 'post_type_exists' ) );
	if ( ! $types || ! nb_base_feature_enabled( 'faq' ) ) {
		return 0;
	}
	$ids = get_posts(
		array(
			'post_type'        => $types,
			'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		)
	);

	// Pas de révision, date de modification conservée, contenu non filtré
	// (il ne contient que des blocs déjà enregistrés et la section ajoutée).
	$keep_dates = static function ( array $data, array $postarr ): array {
		if ( ! empty( $postarr['nb_base_keep_dates'] ) ) {
			$data['post_modified']     = $postarr['nb_base_keep_dates'][0];
			$data['post_modified_gmt'] = $postarr['nb_base_keep_dates'][1];
		}
		return $data;
	};
	add_filter( 'wp_insert_post_data', $keep_dates, 10, 2 );
	add_filter( 'wp_revisions_to_keep', '__return_zero', 999 );
	$kses = false !== has_filter( 'content_save_pre', 'wp_filter_post_kses' );
	if ( $kses ) {
		kses_remove_filters();
	}

	$count = 0;
	foreach ( $ids as $id ) {
		$post    = get_post( $id );
		$content = $post ? nb_base_faq_add_to_content( $post->post_content ) : null;
		if ( null === $content ) {
			continue;
		}
		$result = wp_update_post(
			wp_slash(
				array(
					'ID'                 => $post->ID,
					'post_content'       => $content,
					'nb_base_keep_dates' => array( $post->post_modified, $post->post_modified_gmt ),
				)
			),
			true
		);
		if ( ! is_wp_error( $result ) ) {
			++$count;
		}
	}

	if ( $kses ) {
		kses_init_filters();
	}
	remove_filter( 'wp_revisions_to_keep', '__return_zero', 999 );
	remove_filter( 'wp_insert_post_data', $keep_dates, 10 );
	return $count;
}

add_action(
	'admin_init',
	static function () {
		if ( get_option( NB_BASE_FAQ_ENTRIES_OPTION ) || ! nb_base_feature_enabled( 'faq' ) ) {
			return;
		}
		update_option( NB_BASE_FAQ_ENTRIES_OPTION, 1, true );
		nb_base_faq_update_entries();
	}
);

// Fonctionnalités modifiées : vérification relancée au prochain passage.
add_action( 'update_option_' . NB_BASE_FEATURES_OPTION, static fn() => delete_option( NB_BASE_FAQ_ENTRIES_OPTION ) );
add_action( 'add_option_' . NB_BASE_FEATURES_OPTION, static fn() => delete_option( NB_BASE_FAQ_ENTRIES_OPTION ) );
