<?php
/**
 * Sécurité du site public (fonctionnalités du thème « security », désactivées
 * par défaut, à activer à la mise en ligne de chaque site).
 *
 * - « hide-accounts » : les noms de connexion ne sont plus lisibles par les
 *   visiteurs (liste des comptes de l'API REST, pages auteur et /?author=N,
 *   adresse d'auteur des intégrations oEmbed, message d'erreur de connexion
 *   qui confirmait qu'un identifiant existe).
 * - « security-headers » : en-têtes HTTP de sécurité sur les pages du site.
 * - « hsts » : le navigateur n'utilise plus que le HTTPS pour ce domaine
 *   (un an). Seulement sur un site dont le HTTPS fonctionne.
 *
 * Uniquement des points d'accroche publics de WordPress.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'nb_base_feature_groups',
	static function ( array $groups ): array {
		$groups['security'] = __( 'Security', 'nb-base' );
		return $groups;
	}
);

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['hide-accounts']    = array(
			'group'       => 'security',
			'label'       => __( 'Hide account names', 'nb-base' ),
			'description' => __( 'Visitors can no longer read login names: no public list of accounts, no author pages, generic message after a failed login. Recommended once the site is online.', 'nb-base' ),
			'default'     => false,
		);
		$features['security-headers'] = array(
			'group'       => 'security',
			'label'       => __( 'Security headers', 'nb-base' ),
			'description' => __( 'The browser refuses to show the site inside another site’s frame, does not guess file types, and only sends the site’s domain to external links. Recommended once the site is online.', 'nb-base' ),
			'default'     => false,
		);
		$features['hsts']             = array(
			'group'       => 'security',
			'label'       => __( 'HTTPS only (HSTS)', 'nb-base' ),
			'description' => __( 'Browsers will use only HTTPS for this domain for one year, even after this option is turned off. Only on a site whose HTTPS works, with a valid certificate.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/*
 * Comptes : liste et fiches de l'API REST réservées aux personnes qui
 * rédigent (l'éditeur s'en sert) ; « /users/me » reste ouvert au compte connecté.
 * Adresse comparée sans tenir compte de la casse.
 */
add_filter(
	'rest_pre_dispatch',
	static function ( $result, $server, $request ) {
		if ( null !== $result || ! nb_base_feature_enabled( 'hide-accounts' ) || current_user_can( 'edit_posts' ) ) {
			return $result;
		}
		$route = strtolower( untrailingslashit( $request->get_route() ) );
		if ( ! preg_match( '#^/wp/v2/users(/|$)#', $route ) || ( is_user_logged_in() && '/wp/v2/users/me' === $route ) ) {
			return $result;
		}
		return new WP_Error( 'rest_user_cannot_view', __( 'Sorry, you are not allowed to list accounts.', 'nb-base' ), array( 'status' => rest_authorization_required_code() ) );
	},
	10,
	3
);

// Pages auteur (et /?author=N, qui y redirigeait) : page introuvable.
add_action(
	'template_redirect',
	static function () {
		global $wp_query;
		if ( is_author() && nb_base_feature_enabled( 'hide-accounts' ) ) {
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	},
	1
);

// Plan du site : pas de liste des comptes.
add_filter(
	'wp_sitemaps_add_provider',
	static fn( $provider, string $name ) => ( 'users' === $name && nb_base_feature_enabled( 'hide-accounts' ) ) ? false : $provider,
	10,
	2
);

// Intégrations oEmbed : ni nom ni adresse d'auteur (l'adresse contient le nom de connexion).
add_filter(
	'oembed_response_data',
	static function ( array $data ): array {
		if ( nb_base_feature_enabled( 'hide-accounts' ) ) {
			$data['author_name'] = get_bloginfo( 'name' );
			$data['author_url']  = home_url( '/' );
		}
		return $data;
	}
);

// Connexion refusée : même message que l'identifiant existe ou non.
add_filter(
	'authenticate',
	static function ( $user ) {
		if ( is_wp_error( $user ) && nb_base_feature_enabled( 'hide-accounts' )
			&& array_intersect( $user->get_error_codes(), array( 'invalid_username', 'invalid_email', 'incorrect_password' ) ) ) {
			return new WP_Error( 'nb_base_login_failed', __( '<strong>Error:</strong> The username, email address or password is incorrect.', 'nb-base' ) );
		}
		return $user;
	},
	99
);

/*
 * En-têtes de sécurité (pages du site ; l'administration et la page de
 * connexion envoient déjà les leurs). Pas de Content-Security-Policy : elle
 * dépend des extensions et services de chaque site.
 */
add_action(
	'send_headers',
	static function () {
		if ( headers_sent() ) {
			return;
		}
		if ( nb_base_feature_enabled( 'security-headers' ) ) {
			header( 'X-Content-Type-Options: nosniff' );
			header( 'X-Frame-Options: SAMEORIGIN' );
			header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		}
		// Sans includeSubDomains : les sous-domaines (sites de test…) restent libres.
		if ( is_ssl() && nb_base_feature_enabled( 'hsts' ) ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}
	}
);
