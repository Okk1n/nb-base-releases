<?php
/**
 * Formulaires : anti-spam du thème (partie neutre, sans extension).
 *
 * Contrôles invisibles pour le visiteur, sans service externe, sans cookie ni
 * script, actifs avec la fonctionnalité « forms » ; branchés par l'adaptateur
 * de l'extension (inc/forms-cf7.php), qui les ajoute au formulaire et
 * demande le verdict avant l'envoi :
 *  - champ piège : champ texte hors écran, ignoré au clavier et par les
 *    lecteurs d'écran, nom propre à chaque site (sans ressemblance avec un
 *    champ connu, pour le remplissage automatique des navigateurs) ; rempli =
 *    spam ;
 *  - délai minimum : heure d'affichage du formulaire (champ caché signé avec
 *    les clés du site) ; envoi moins de 3 s après, heure absente ou
 *    falsifiée = spam. Pas de durée maximale (pages en cache) ;
 *  - limite d'envois : 5 envois acceptés par adresse IP en 10 minutes, puis
 *    spam jusqu'à la fin de la période. Adresse jamais stockée en clair
 *    (empreinte signée), compteur effacé seul (transient) ;
 *  - liens : plus de 3 liens dans l'ensemble des champs = spam.
 * Réglages par filtres : nb_base_form_min_time, nb_base_form_rate_limit,
 * nb_base_form_max_links. Les spams ne sont ni envoyés ni enregistrés.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_FORM_TIME_FIELD = '_nb_base_form_time';

/**
 * Nom du champ piège, propre au site.
 */
function nb_base_form_honeypot_name(): string {
	return 'nb-' . substr( wp_hash( 'nb_base_form_honeypot', 'nonce' ), 0, 8 );
}

/**
 * HTML du champ piège (caché par la classe .nb-form-hp, styles du bloc
 * Formulaire).
 */
function nb_base_form_honeypot_html(): string {
	return sprintf(
		'<span class="nb-form-hp" aria-hidden="true"><input type="text" name="%s" value="" tabindex="-1" autocomplete="off" /></span>',
		esc_attr( nb_base_form_honeypot_name() )
	);
}

/**
 * Signature de l'heure d'affichage d'un formulaire.
 *
 * @param int    $time    Horodatage.
 * @param string $form_id Identifiant du formulaire.
 */
function nb_base_form_time_signature( int $time, string $form_id ): string {
	return substr( wp_hash( $time . '|' . $form_id, 'nonce' ), 0, 20 );
}

/**
 * Champs cachés à ajouter au formulaire : nom => valeur.
 *
 * @param string $form_id Identifiant du formulaire.
 */
function nb_base_form_antispam_fields( string $form_id ): array {
	$time = time();
	return array( NB_BASE_FORM_TIME_FIELD => $time . '.' . nb_base_form_time_signature( $time, $form_id ) );
}

/**
 * Verdict anti-spam d'un envoi déjà validé par l'extension. Un envoi
 * accepté compte dans la limite d'envois.
 *
 * @param array  $raw     Données brutes envoyées (champ piège, heure).
 * @param array  $fields  Champs du formulaire : nom => valeur.
 * @param string $form_id Identifiant du formulaire.
 * @param string $ip      Adresse IP du visiteur (vide : pas de limite).
 * @return string Raison du refus, chaîne vide si l'envoi est accepté.
 */
function nb_base_form_spam_reason( array $raw, array $fields, string $form_id, string $ip ): string {
	$trap = $raw[ nb_base_form_honeypot_name() ] ?? '';
	if ( ! is_string( $trap ) || '' !== $trap ) {
		return __( 'Trap field filled in.', 'nb-base' );
	}

	$stamp = is_string( $raw[ NB_BASE_FORM_TIME_FIELD ] ?? null ) ? $raw[ NB_BASE_FORM_TIME_FIELD ] : '';
	if ( ! preg_match( '/^(\d{1,12})\.([a-f0-9]{20})$/', $stamp, $match ) || ! hash_equals( nb_base_form_time_signature( (int) $match[1], $form_id ), $match[2] ) ) {
		return __( 'Display time missing or invalid.', 'nb-base' );
	}
	$min_time = max( 0, (int) apply_filters( 'nb_base_form_min_time', 3 ) );
	if ( time() - (int) $match[1] < $min_time ) {
		return __( 'Form sent too quickly.', 'nb-base' );
	}

	$max_links = (int) apply_filters( 'nb_base_form_max_links', 3 );
	if ( $max_links >= 0 ) {
		$text = implode( ' ', array_map( static fn( $value ) => is_array( $value ) ? implode( ' ', array_map( 'strval', $value ) ) : (string) $value, $fields ) );
		if ( preg_match_all( '#https?://|www\.#i', $text ) > $max_links ) {
			return __( 'Too many links.', 'nb-base' );
		}
	}

	if ( '' !== $ip ) {
		$limit  = wp_parse_args( (array) apply_filters( 'nb_base_form_rate_limit', array() ), array( 'count' => 5, 'period' => 600 ) );
		$period = max( 60, (int) $limit['period'] );
		$key    = 'nb_base_form_rate_' . substr( wp_hash( $ip, 'nonce' ), 0, 32 );
		$state  = get_transient( $key );
		$now    = time();
		if ( ! is_array( $state ) || (int) ( $state['start'] ?? 0 ) + $period <= $now ) {
			$state = array( 'count' => 0, 'start' => $now );
		}
		if ( (int) $state['count'] >= max( 1, (int) $limit['count'] ) ) {
			return __( 'Too many submissions from this address.', 'nb-base' );
		}
		$state['count'] = (int) $state['count'] + 1;
		set_transient( $key, $state, max( 1, (int) $state['start'] + $period - $now ) );
	}

	return '';
}
