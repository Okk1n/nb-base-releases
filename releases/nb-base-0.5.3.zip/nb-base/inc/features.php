<?php
/**
 * Registre des fonctionnalités activables / désactivables par site.
 *
 * Point d'accès unique : nb_base_feature_enabled(). Tout le thème passe par
 * cette fonction ; un futur système de licence pourra s'y brancher sans
 * modifier les blocs.
 *
 * Règle : désactiver une fonctionnalité masque ses blocs de l'inserteur,
 * mais les blocs déjà placés dans les pages continuent de s'afficher.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_FEATURES_OPTION = 'nb_base_features';

/**
 * Déclaration des fonctionnalités.
 *
 * Format : 'slug' => array(
 *     'group'       => 'blocks',           // Thème (nb_base_feature_groups()) ; inconnu = « other ».
 *     'label'       => 'Nom affiché',
 *     'description' => 'Description courte',
 *     'default'     => false,              // État sur un site où rien n'a été réglé.
 *     'blocks'      => array( 'nb-base/xxx' ), // Blocs liés à la fonctionnalité.
 * )
 *
 * Une nouvelle fonctionnalité ajoutée par une mise à jour doit être
 * désactivée par défaut, pour que les sites existants ne changent pas.
 *
 * @return array<string, array>
 */
function nb_base_features(): array {
	$features = array();

	/**
	 * Permet d'ajouter des fonctionnalités depuis un module du thème.
	 */
	$features = apply_filters( 'nb_base_features', $features );

	foreach ( $features as $slug => $feature ) {
		$features[ $slug ] = wp_parse_args(
			$feature,
			array(
				'group'       => 'other',
				'label'       => $slug,
				'description' => '',
				'default'     => false,
				'blocks'      => array(),
			)
		);
	}

	return $features;
}

/**
 * Thèmes des fonctionnalités (onglet Fonctionnalités de la page NB Base),
 * dans l'ordre d'affichage : clé => libellé. « other » : dernier.
 *
 * @return array<string, string>
 */
function nb_base_feature_groups(): array {
	$groups = array(
		'blocks'  => __( 'Blocks', 'nb-base' ),
		'content' => __( 'Content types', 'nb-base' ),
		'forms'   => __( 'Forms', 'nb-base' ),
		'seo'     => __( 'Search engine optimization', 'nb-base' ),
		'privacy' => __( 'Privacy', 'nb-base' ),
	);
	/**
	 * Ajout de thèmes depuis un module.
	 */
	$groups          = (array) apply_filters( 'nb_base_feature_groups', $groups );
	$groups['other'] = __( 'Other', 'nb-base' );
	return $groups;
}

/**
 * États enregistrés en base (slug => bool).
 */
function nb_base_feature_states(): array {
	$states = get_option( NB_BASE_FEATURES_OPTION, array() );
	return is_array( $states ) ? $states : array();
}

/**
 * La fonctionnalité est-elle active sur ce site ?
 */
function nb_base_feature_enabled( string $slug ): bool {
	$features = nb_base_features();
	if ( ! isset( $features[ $slug ] ) ) {
		return false;
	}

	$states  = nb_base_feature_states();
	$enabled = array_key_exists( $slug, $states ) ? (bool) $states[ $slug ] : (bool) $features[ $slug ]['default'];

	/**
	 * Point de branchement pour un futur contrôle de licence.
	 */
	return (bool) apply_filters( 'nb_base_feature_enabled', $enabled, $slug );
}

/**
 * Enregistre les états (réservé au designer, appelé depuis la page d'admin).
 *
 * @param array<string, bool> $states
 */
function nb_base_save_feature_states( array $states ): void {
	$clean = array();
	foreach ( array_keys( nb_base_features() ) as $slug ) {
		$clean[ $slug ] = ! empty( $states[ $slug ] );
	}
	update_option( NB_BASE_FEATURES_OPTION, $clean, true );
}

/**
 * Bloc -> fonctionnalité qui le contrôle (ou null).
 */
function nb_base_feature_for_block( string $block_name ): ?string {
	foreach ( nb_base_features() as $slug => $feature ) {
		if ( in_array( $block_name, $feature['blocks'], true ) ) {
			return $slug;
		}
	}
	return null;
}

/**
 * Les blocs d'une fonctionnalité désactivée restent enregistrés (donc rendus
 * en front) mais disparaissent de l'inserteur.
 */
add_filter(
	'register_block_type_args',
	static function ( array $args, string $block_name ): array {
		$feature = nb_base_feature_for_block( $block_name );
		if ( null !== $feature && ! nb_base_feature_enabled( $feature ) ) {
			$args['supports']             = $args['supports'] ?? array();
			$args['supports']['inserter'] = false;
		}
		return $args;
	},
	10,
	2
);
