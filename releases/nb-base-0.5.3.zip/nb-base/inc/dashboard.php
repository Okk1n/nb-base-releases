<?php
/**
 * Tableau de bord : mise en forme native de WordPress (blocs déplaçables et
 * repliables), contenu remplacé.
 *
 * - Retirés : tous les blocs existants (D'un coup d'œil, Activité, Brouillon
 *   rapide, Évènements et nouveautés, Santé du site… et ceux des extensions)
 *   et le panneau de bienvenue.
 * - Ajoutés (selon les droits du compte), chacun avec une icône, un chiffre
 *   clé et des boutons : Pages, un bloc par type de contenu structuré actif
 *   (Réalisations, Produits…), Messages reçus, Établissement.
 * - Disposition : grille (CSS) au lieu des colonnes indépendantes de
 *   WordPress : blocs de 340px au moins, autant par ligne que la largeur le
 *   permet, et ceux d'une même ligne à la même hauteur. Chaque compte peut
 *   replier ou masquer les blocs (Options de l'écran).
 *
 * Uniquement par les API publiques : wp_dashboard_setup, remove_meta_box(),
 * wp_add_dashboard_widget().
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_DASHBOARD_PREFIX = 'nb_base_dashboard_';

// Panneau de bienvenue (accroché par WordPress après le chargement du thème).
add_action( 'load-index.php', static fn() => remove_action( 'welcome_panel', 'wp_welcome_panel' ) );

add_action(
	'wp_dashboard_setup',
	static function () {
		global $wp_meta_boxes;

		// Tous les blocs déjà déclarés (WordPress et extensions).
		foreach ( (array) ( $wp_meta_boxes['dashboard'] ?? array() ) as $context => $priorities ) {
			foreach ( (array) $priorities as $boxes ) {
				foreach ( array_keys( (array) $boxes ) as $id ) {
					remove_meta_box( (string) $id, 'dashboard', (string) $context );
				}
			}
		}

		// Blocs dans l'ordre d'affichage : id => [ titre, fonction, arguments ].
		$widgets = array();
		if ( current_user_can( 'edit_pages' ) ) {
			$widgets['pages'] = array( __( 'Pages', 'nb-base' ), 'nb_base_dashboard_pages', null );
		}
		foreach ( nb_base_dashboard_entry_types() as $type ) {
			$widgets[ 'type_' . $type->name ] = array( $type->labels->name, 'nb_base_dashboard_type', array( 'type' => $type->name ) );
		}
		$messages = get_post_type_object( 'nb_form_entry' );
		if ( $messages && $messages->show_ui && current_user_can( $messages->cap->edit_posts ) ) {
			$widgets['messages'] = array( __( 'Received messages', 'nb-base' ), 'nb_base_dashboard_messages', null );
		}
		if ( current_user_can( 'manage_options' ) ) {
			$widgets['business'] = array( __( 'Business', 'nb-base' ), 'nb_base_dashboard_business', null );
		}

		// Tous dans la première colonne : la grille (CSS ci-dessous) les répartit
		// ligne par ligne, dans cet ordre.
		foreach ( $widgets as $id => $widget ) {
			wp_add_dashboard_widget( NB_BASE_DASHBOARD_PREFIX . $id, $widget[0], $widget[1], null, $widget[2], 'normal', 'high' );
		}
	},
	999
);

/**
 * Styles des blocs (tableau de bord seulement). Couleur : celle du jeu de
 * couleurs de l'administration choisi par le compte.
 */
add_action(
	'admin_enqueue_scripts',
	static function ( string $hook ) {
		if ( 'index.php' !== $hook ) {
			return;
		}
		wp_register_style( 'nb-base-dashboard', false, array(), NB_BASE_VERSION );
		wp_enqueue_style( 'nb-base-dashboard' );
		wp_add_inline_style(
			'nb-base-dashboard',
			// Grille : colonnes de WordPress « transparentes » (display: contents),
			// blocs placés ligne par ligne, même hauteur par ligne.
			'#dashboard-widgets{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px;align-items:stretch}'
			. '#dashboard-widgets .postbox-container,#dashboard-widgets .meta-box-sortables{display:contents}'
			. '#dashboard-widgets .postbox{margin:0;min-width:0}'
			. '#dashboard-widgets .postbox{display:flex;flex-direction:column}'
			. '#dashboard-widgets .postbox .inside{flex:1;display:flex;flex-direction:column;margin:0;padding:16px}'
			. '#dashboard-widgets .postbox .inside > :last-child{margin-bottom:0}'
			. '#dashboard-widgets .nb-dash__actions{margin-top:auto;padding-top:16px}'
			. '.nb-dash{display:flex;gap:16px;align-items:flex-start}'
			. '.nb-dash__icon{flex:none;display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:color-mix(in srgb,var(--wp-admin-theme-color,#3858e9) 12%,#fff);color:var(--wp-admin-theme-color,#3858e9)}'
			. '.nb-dash__icon.dashicons-before:before{font-size:28px;width:28px;height:28px}'
			. '.nb-dash__body{flex:1;min-width:0}'
			. '.nb-dash__stat{margin:0;font-size:14px;color:#50575e}'
			. '.nb-dash__stat strong{display:block;font-size:28px;line-height:1.2;color:#1e1e1e}'
			. '.nb-dash__text{margin:6px 0 0;color:#50575e}'
			. '.nb-dash__actions{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0 0}'
			// Icône des boutons centrée sur le texte (le glyphe dashicons est
			// décalé vers le bas par défaut).
			// Boutons étirés : côte à côte s'il y a la place, sinon empilés en
			// pleine largeur (jamais deux largeurs différentes l'une sous l'autre).
			. '.nb-dash__actions .button{flex:1 1 auto;display:inline-flex;align-items:center;justify-content:center;gap:6px}'
			. '.nb-dash__actions .button .dashicons{font-size:16px;width:16px;height:16px;line-height:1;margin:0;vertical-align:0}'
			. '.nb-dash__actions .button .dashicons:before{display:block;line-height:1}'
			. '.nb-dash--name .nb-dash__stat strong{font-size:20px}'
			. '.nb-dash__list{margin:12px 0 0}.nb-dash__list li{display:flex;justify-content:space-between;gap:12px;margin:0;padding:6px 0;border-top:1px solid #f0f0f1}'
			. '.nb-dash__list li span{color:#646970;white-space:nowrap}'
		);
	}
);

/**
 * Types de contenu structurés actifs et modifiables par le compte.
 *
 * @return WP_Post_Type[]
 */
function nb_base_dashboard_entry_types(): array {
	$types = array();
	foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $type ) {
		if ( $type->show_in_menu && nb_base_entry_settings( $type->name ) && current_user_can( $type->cap->edit_posts ) ) {
			$types[] = $type;
		}
	}
	return $types;
}

/**
 * Bloc type : icône (dashicons), chiffre clé et libellé, texte, contenu
 * libre, boutons.
 *
 * @param array $card {
 *     @type string $icon    Classe dashicons.
 *     @type string $stat    Chiffre clé (ou nom).
 *     @type bool   $name    $stat est un nom (plus petit qu'un chiffre).
 *     @type string $label   Libellé sous le chiffre.
 *     @type string $text    Texte.
 *     @type string $html    Contenu déjà échappé.
 *     @type array  $buttons Boutons : [ texte, adresse, principal, icône dashicons ].
 * }
 */
function nb_base_dashboard_card( array $card ): void {
	$icon = preg_match( '/^dashicons-[a-z0-9-]+$/', (string) $card['icon'] ) ? $card['icon'] : 'dashicons-admin-post';
	echo '<div class="nb-dash' . ( ! empty( $card['name'] ) ? ' nb-dash--name' : '' ) . '">';
	echo '<span class="nb-dash__icon dashicons-before ' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
	echo '<div class="nb-dash__body">';
	if ( isset( $card['stat'] ) ) {
		echo '<p class="nb-dash__stat"><strong>' . esc_html( $card['stat'] ) . '</strong>' . esc_html( $card['label'] ?? '' ) . '</p>';
	}
	if ( ! empty( $card['text'] ) ) {
		echo '<p class="nb-dash__text">' . esc_html( $card['text'] ) . '</p>';
	}
	echo $card['html'] ?? ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- échappé par l'appelant.
	echo '</div></div>';
	if ( ! empty( $card['buttons'] ) ) {
		echo '<p class="nb-dash__actions">';
		foreach ( $card['buttons'] as $button ) {
			$icon = ! empty( $button[3] ) ? '<span class="dashicons ' . esc_attr( $button[3] ) . '" aria-hidden="true"></span>' : '';
			echo '<a class="button' . ( ! empty( $button[2] ) ? ' button-primary' : '' ) . '" href="' . esc_url( $button[1] ) . '">' . $icon . esc_html( $button[0] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $icon échappé ci-dessus.
		}
		echo '</p>';
	}
}

/**
 * Texte « n brouillons en cours » (vide sans brouillon).
 */
function nb_base_dashboard_drafts( int $drafts ): string {
	/* translators: %d: number of drafts. */
	return $drafts ? sprintf( _n( '%d draft in progress', '%d drafts in progress', $drafts, 'nb-base' ), $drafts ) : '';
}

/**
 * Bloc « Pages » : nombre de pages publiées (et de brouillons), boutons.
 */
function nb_base_dashboard_pages(): void {
	$count   = wp_count_posts( 'page' );
	$publish = (int) ( $count->publish ?? 0 );
	$buttons = array();
	if ( current_user_can( 'publish_pages' ) ) {
		$buttons[] = array( __( 'Add a page', 'nb-base' ), admin_url( 'post-new.php?post_type=page' ), true, 'dashicons-plus-alt2' );
	}
	$buttons[] = array( __( 'Manage pages', 'nb-base' ), admin_url( 'edit.php?post_type=page' ) );
	nb_base_dashboard_card(
		array(
			'icon'    => 'dashicons-admin-page',
			'stat'    => (string) $publish,
			'label'   => _n( 'published page', 'published pages', $publish, 'nb-base' ),
			'text'    => nb_base_dashboard_drafts( (int) ( $count->draft ?? 0 ) ),
			'buttons' => $buttons,
		)
	);
}

/**
 * Bloc d'un type de contenu (réalisations, produits…) : icône du menu,
 * nombre de contenus publiés, boutons « Ajouter » et « Voir tout ».
 *
 * @param mixed $unused Objet passé par WordPress (inutilisé).
 * @param array $box    Bloc ($box['args']['type'] : type de contenu).
 */
function nb_base_dashboard_type( $unused, array $box ): void {
	$type = get_post_type_object( (string) ( $box['args']['type'] ?? '' ) );
	if ( ! $type ) {
		return;
	}
	$count   = wp_count_posts( $type->name );
	$publish = (int) ( $count->publish ?? 0 );
	$buttons = array();
	if ( current_user_can( $type->cap->create_posts ) ) {
		$buttons[] = array( $type->labels->add_new_item, admin_url( 'post-new.php?post_type=' . $type->name ), true, 'dashicons-plus-alt2' );
	}
	$buttons[] = array( __( 'View all', 'nb-base' ), admin_url( 'edit.php?post_type=' . $type->name ) );
	nb_base_dashboard_card(
		array(
			'icon'    => is_string( $type->menu_icon ) ? $type->menu_icon : '',
			'stat'    => (string) $publish,
			'label'   => _n( 'online', 'online', $publish, 'nb-base' ),
			'text'    => nb_base_dashboard_drafts( (int) ( $count->draft ?? 0 ) ),
			'buttons' => $buttons,
		)
	);
}

/**
 * Bloc « Messages reçus » : nombre de messages, 3 derniers (titre, il y a…),
 * bouton vers la liste.
 */
function nb_base_dashboard_messages(): void {
	$messages = get_posts(
		array(
			'post_type'      => 'nb_form_entry',
			'post_status'    => 'any',
			'posts_per_page' => 3,
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);
	$counts = (array) wp_count_posts( 'nb_form_entry' );
	unset( $counts['trash'], $counts['auto-draft'] );
	$total = array_sum( array_map( 'intval', $counts ) );
	$list  = '';
	foreach ( $messages as $message ) {
		$title = '' !== trim( get_the_title( $message ) ) ? get_the_title( $message ) : __( '(no title)', 'nb-base' );
		$link  = get_edit_post_link( $message );
		$ago   = sprintf(
			/* translators: %s: time elapsed (e.g. 2 hours). */
			__( '%s ago', 'nb-base' ),
			human_time_diff( (int) get_post_time( 'U', true, $message ), time() )
		);
		$list .= '<li>' . ( $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a>' : esc_html( $title ) ) . '<span>' . esc_html( $ago ) . '</span></li>';
	}
	nb_base_dashboard_card(
		array(
			'icon'    => 'dashicons-email-alt',
			'stat'    => (string) $total,
			'label'   => _n( 'message received', 'messages received', $total, 'nb-base' ),
			'text'    => $messages ? '' : __( 'Messages sent by the forms of the site will appear here.', 'nb-base' ),
			'html'    => $list ? '<ul class="nb-dash__list">' . $list . '</ul>' : '',
			'buttons' => array( array( __( 'See the messages', 'nb-base' ), admin_url( 'edit.php?post_type=nb_form_entry' ), true ) ),
		)
	);
}

/**
 * Bloc « Établissement » : nom, adresse, bouton vers la fiche.
 */
function nb_base_dashboard_business(): void {
	$address = function_exists( 'nb_base_business_address_text' ) ? nb_base_business_address_text() : '';
	nb_base_dashboard_card(
		array(
			'icon'    => 'dashicons-store',
			'name'    => true,
			'stat'    => wp_strip_all_tags( get_bloginfo( 'name' ) ),
			'text'    => '' !== $address ? (string) preg_replace( '/\s*\n\s*/', ', ', $address ) : __( 'Address, activity, service area: complete the business information so that search engines present it well.', 'nb-base' ),
			'buttons' => array( array( __( 'Edit the business information', 'nb-base' ), admin_url( 'admin.php?page=' . NB_BASE_BUSINESS_ADMIN_SLUG ), true, 'dashicons-edit' ) ),
		)
	);
}
