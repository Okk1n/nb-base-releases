<?php
/**
 * Import / export des styles du site (couche « utilisateur » des styles
 * globaux natifs, stockée en base dans le type de contenu wp_global_styles).
 *
 * Ces styles survivent aux mises à jour du thème tant que l'identifiant
 * du thème (nom du dossier) et les slugs des variables ne changent pas.
 *
 * Format du fichier JSON : identique à un theme.json (clés « settings » et
 * « styles »), ne contenant que les valeurs propres au client.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Toutes les opérations passent par l'API REST publique de WordPress
 * (celle qu'utilise l'éditeur de site), et non par les classes internes
 * WP_Theme_JSON / WP_Theme_JSON_Resolver, marquées « @access private ».
 */

/**
 * ID de l'enregistrement de styles du thème actif, tel qu'exposé par
 * l'API REST (lien « user-global-styles » du thème actif).
 *
 * @return int|WP_Error
 */
function nb_base_global_styles_post_id() {
	$response = rest_do_request( new WP_REST_Request( 'GET', '/wp/v2/themes/' . get_stylesheet() ) );
	if ( $response->is_error() ) {
		return $response->as_error();
	}
	$links = $response->get_links();
	$href  = $links['https://api.w.org/user-global-styles'][0]['href'] ?? '';
	if ( ! preg_match( '#/global-styles/(\d+)#', $href, $m ) ) {
		return new WP_Error( 'nb_base_no_global_styles', __( 'Unable to find the theme global styles.', 'nb-base' ) );
	}
	return (int) $m[1];
}

/**
 * Styles du site actuellement en base.
 *
 * @return array|WP_Error
 */
function nb_base_export_styles() {
	$post_id = nb_base_global_styles_post_id();
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	$request = new WP_REST_Request( 'GET', '/wp/v2/global-styles/' . $post_id );
	$request->set_param( 'context', 'edit' );
	$response = rest_do_request( $request );
	if ( $response->is_error() ) {
		return $response->as_error();
	}
	$data = $response->get_data();

	return array(
		'$schema'  => 'https://schemas.wp.org/trunk/theme.json',
		'version'  => 3,
		'settings' => ! empty( $data['settings'] ) ? $data['settings'] : new stdClass(),
		'styles'   => ! empty( $data['styles'] ) ? $data['styles'] : new stdClass(),
	);
}

/**
 * Remplace les styles du site par ceux fournis. La validation et le
 * nettoyage sont assurés par l'API REST native.
 *
 * @param array $data Contenu décodé du fichier JSON.
 * @return true|WP_Error
 */
function nb_base_import_styles( array $data ) {
	if ( ! isset( $data['settings'] ) && ! isset( $data['styles'] ) ) {
		return new WP_Error( 'nb_base_invalid_styles', __( 'Invalid file: “settings” or “styles” keys expected.', 'nb-base' ) );
	}

	$post_id = nb_base_global_styles_post_id();
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}

	$request = new WP_REST_Request( 'POST', '/wp/v2/global-styles/' . $post_id );
	$request->set_body_params(
		array(
			'settings' => (array) ( $data['settings'] ?? array() ),
			'styles'   => (array) ( $data['styles'] ?? array() ),
		)
	);
	$response = rest_do_request( $request );

	return $response->is_error() ? $response->as_error() : true;
}

/**
 * Commandes WP-CLI :
 *   wp nb-base styles export [<fichier>]
 *   wp nb-base styles import <fichier>
 */
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * WordPress ne rattache les styles au thème que si un utilisateur autorisé
	 * est connecté : sans --user, on agit au nom du premier designer trouvé.
	 */
	$nb_base_cli_as_designer = static function () {
		if ( get_current_user_id() ) {
			return;
		}
		foreach ( get_users( array( 'fields' => 'ID' ) ) as $user_id ) {
			if ( nb_base_is_designer( (int) $user_id ) ) {
				wp_set_current_user( (int) $user_id );
				return;
			}
		}
		WP_CLI::error( 'No designer account: use --user=<login>.' );
	};

	WP_CLI::add_command(
		'nb-base styles export',
		static function ( array $args ) use ( $nb_base_cli_as_designer ) {
			$nb_base_cli_as_designer();
			$data = nb_base_export_styles();
			if ( is_wp_error( $data ) ) {
				WP_CLI::error( $data->get_error_message() );
			}
			$json = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			if ( empty( $args[0] ) ) {
				WP_CLI::line( $json );
				return;
			}
			file_put_contents( $args[0], $json . "\n" );
			WP_CLI::success( "Styles exported to {$args[0]}" );
		}
	);

	WP_CLI::add_command(
		'nb-base styles import',
		static function ( array $args ) use ( $nb_base_cli_as_designer ) {
			$nb_base_cli_as_designer();
			$data = json_decode( (string) file_get_contents( $args[0] ), true );
			if ( ! is_array( $data ) ) {
				WP_CLI::error( 'Unreadable JSON.' );
			}
			$result = nb_base_import_styles( $data );
			if ( is_wp_error( $result ) ) {
				WP_CLI::error( $result->get_error_message() );
			}
			WP_CLI::success( 'Styles imported.' );
		}
	);
}
