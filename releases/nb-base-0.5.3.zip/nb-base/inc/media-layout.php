<?php
/**
 * Sections texte + image (about, text-image…) : rendu commun de l'image et
 * des classes de disposition. Éditeur : src/shared/media-layout.js ;
 * styles : src/shared/_media-layout.scss.
 *
 * Attributs attendus : imageId, imageRadius, imageHeight,
 * reverseColumns, stackedImagePosition. Pas de point focal : image recadrée
 * au centre (attribut focalPoint des blocs conservé, obsolète, ignoré).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/** Blocs utilisant cette disposition (nom court => réglages custom). */
function nb_base_media_layout_blocks(): array {
	return array(
		'about'      => 'about',
		'text-image' => 'textImage',
	);
}

/**
 * Image du bloc (balise <img>), ou chaîne vide.
 */
function nb_base_media_layout_image( array $attributes ): string {
	$image_id = (int) ( $attributes['imageId'] ?? 0 );
	if ( ! $image_id ) {
		return '';
	}
	return wp_get_attachment_image(
		$image_id,
		'large',
		false,
		array( 'sizes' => '(min-width: 992px) 50vw, 100vw' )
	);
}

/**
 * Classes de disposition du bloc (identiques à mediaLayoutClasses() en JS).
 */
function nb_base_media_layout_classes( string $name, array $attributes, bool $has_image ): array {
	$classes = array( 'nb-' . $name . '--image-' . ( 'natural' !== ( $attributes['imageHeight'] ?? '' ) ? 'column' : 'natural' ) );
	if ( ! $has_image ) {
		$classes[] = 'nb-' . $name . '--no-image';
		return $classes;
	}
	if ( ! empty( $attributes['reverseColumns'] ) ) {
		$classes[] = 'nb-' . $name . '--reversed';
	}
	if ( 'above' === ( $attributes['stackedImagePosition'] ?? '' ) ) {
		$classes[] = 'nb-' . $name . '--stacked-image-above';
	}
	return $classes;
}

/**
 * Balise <figure> de l'image (arrondi choisi dans le bloc), ou chaîne vide.
 */
function nb_base_media_layout_figure( string $name, array $attributes, string $image ): string {
	if ( '' === $image ) {
		return '';
	}
	$radius = (string) ( $attributes['imageRadius'] ?? '' );
	$style  = preg_match( '/^[a-z0-9-]+$/', $radius ) ? '--nb-' . $name . '-image-radius:var(--wp--preset--border-radius--' . $radius . ')' : '';
	return '<figure class="nb-' . esc_attr( $name ) . '__media"' . ( $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>' . $image . '</figure>';
}

/**
 * Arrondis enregistrés (thème + styles du site), proposés pour l'image,
 * affichés en pixels, et arrondi par défaut de chaque bloc. Les réglages
 * visuels natifs étant coupés dans l'éditeur (editor-restrictions.js), la
 * liste est transmise directement aux scripts. « radius-full » (pilule)
 * n'est pas proposé.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$sizes = wp_get_global_settings( array( 'border', 'radiusSizes' ) );
		$radii = array();
		foreach ( array( 'default', 'theme', 'custom' ) as $origin ) {
			foreach ( (array) ( $sizes[ $origin ] ?? array() ) as $size ) {
				if ( isset( $size['slug'], $size['size'] ) && 'full' !== $size['slug'] ) {
					$radii[ $size['slug'] ] = array(
						'slug' => (string) $size['slug'],
						'px'   => nb_base_css_to_px( (string) $size['size'] ),
					);
				}
			}
		}

		// Arrondi par défaut de l'image (settings.custom.<bloc>.imageRadius).
		$defaults = array();
		foreach ( nb_base_media_layout_blocks() as $name => $custom ) {
			$default = (string) wp_get_global_settings( array( 'custom', $custom, 'imageRadius' ) );
			if ( preg_match( '/^var\(--wp--preset--border-radius--([a-z0-9-]+)\)$/', $default, $m ) ) {
				$default = $radii[ $m[1] ]['px'] ?? $default;
			} else {
				$default = nb_base_css_to_px( $default );
			}
			$defaults[ $name ] = $default;
		}

		$data = 'window.nbBaseRadii = ' . wp_json_encode(
			array(
				'defaults' => $defaults,
				'sizes'    => array_values( $radii ),
			)
		) . ';';
		foreach ( array_keys( nb_base_media_layout_blocks() ) as $name ) {
			wp_add_inline_script( generate_block_asset_handle( 'nb-base/' . $name, 'editorScript' ), $data, 'before' );
		}
	}
);
