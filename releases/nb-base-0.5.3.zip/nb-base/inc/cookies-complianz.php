<?php
/**
 * Consentement aux cookies : adaptateur Complianz.
 *
 * Seul fichier du thème qui connaît Complianz (voir inc/cookies.php). Le
 * bandeau, le blocage des services tiers et la politique de cookies sont
 * entièrement gérés par l'extension (assistant de configuration) ; le thème
 * ne fait que la rendre indispensable quand la fonctionnalité « cookies »
 * est activée. Uniquement des points d'accroche natifs de WordPress.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'CMPLZ_PLUGIN' ) ) {
	return;
}

add_filter( 'nb_base_cookies_plugin_active', '__return_true' );

/**
 * Extension indispensable : seul le designer peut la désactiver (droit
 * natif « deactivate_plugin »). Les mises à jour restent possibles.
 */
add_filter(
	'map_meta_cap',
	static function ( array $caps, string $cap, int $user_id, array $args ): array {
		if (
			'deactivate_plugin' === $cap &&
			CMPLZ_PLUGIN === ( $args[0] ?? '' ) &&
			nb_base_feature_enabled( 'cookies' ) &&
			! nb_base_is_designer( $user_id )
		) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	10,
	4
);

/**
 * Mises à jour automatiques imposées (filtre natif « auto_update_plugin ») :
 * la conformité dépend d'une extension à jour.
 */
add_filter(
	'auto_update_plugin',
	static function ( $update, $item ) {
		if ( is_object( $item ) && CMPLZ_PLUGIN === ( $item->plugin ?? '' ) && nb_base_feature_enabled( 'cookies' ) ) {
			return true;
		}
		return $update;
	},
	10,
	2
);

// Explication à la place du lien « Désactiver ».
add_filter(
	'plugin_action_links_' . CMPLZ_PLUGIN,
	static function ( array $links ): array {
		if ( nb_base_feature_enabled( 'cookies' ) && ! current_user_can( 'deactivate_plugin', CMPLZ_PLUGIN ) ) {
			$links['nb-base-required'] = '<span>' . esc_html__( 'Required by the theme', 'nb-base' ) . '</span>';
		}
		return $links;
	}
);
