<?php
/**
 * Note Google : réglages du site, communs à tous les blocs « Note Google ».
 *
 * Options natives exposées à l'API REST (/wp/v2/settings) : l'éditeur les
 * modifie via le magasin de données « core » (entité « site »), enregistrées
 * avec la page. Réservé aux comptes ayant le droit manage_options.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		register_setting(
			'nb_base',
			'nb_base_google_rating',
			array(
				'type'              => 'number',
				'description'       => __( 'Google rating (out of 5).', 'nb-base' ),
				'default'           => 0,
				'show_in_rest'      => array(
					'schema' => array(
						'minimum' => 0,
						'maximum' => 5,
					),
				),
				'sanitize_callback' => static fn( $v ) => round( max( 0, min( 5, (float) $v ) ), 1 ),
			)
		);
		register_setting(
			'nb_base',
			'nb_base_google_url',
			array(
				'type'              => 'string',
				'description'       => __( 'Link to the Google reviews.', 'nb-base' ),
				'default'           => '',
				'show_in_rest'      => true,
				'sanitize_callback' => 'esc_url_raw',
			)
		);
	}
);
