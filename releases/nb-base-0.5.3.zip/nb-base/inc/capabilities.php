<?php
/**
 * Capacité « designer » : réservée au compte du concepteur du thème.
 *
 * Seuls les comptes possédant cette capacité peuvent modifier les styles
 * globaux, les templates, les template parts, activer des fonctionnalités et
 * importer/exporter les styles. Les administrateurs (client, partenaire)
 * ne l'ont pas par défaut.
 *
 * Attribution manuelle via WP-CLI :
 *   wp user add-cap <login> nb_base_design
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_DESIGN_CAP = 'nb_base_design';

/**
 * L'utilisateur (courant par défaut) est-il designer ?
 */
function nb_base_is_designer( ?int $user_id = null ): bool {
	$user_id = $user_id ?? get_current_user_id();
	return $user_id > 0 && user_can( $user_id, NB_BASE_DESIGN_CAP );
}

/**
 * Existe-t-il au moins un compte designer sur le site ?
 */
function nb_base_has_designer(): bool {
	foreach ( get_users( array( 'fields' => 'ID' ) ) as $user_id ) {
		if ( nb_base_is_designer( (int) $user_id ) ) {
			return true;
		}
	}
	return false;
}

/**
 * À la première activation du thème, le compte qui l'active devient designer
 * (uniquement si aucun designer n'existe encore).
 */
add_action(
	'after_switch_theme',
	static function () {
		$user = wp_get_current_user();
		if ( $user->exists() && ! nb_base_has_designer() ) {
			$user->add_cap( NB_BASE_DESIGN_CAP );
		}
	}
);

/**
 * Le compte est-il designer ? Lecture directe des droits du compte, sans
 * passer par `map_meta_cap` (utilisable dans ce filtre sans boucle).
 */
function nb_base_user_is_designer( int $user_id ): bool {
	$user = $user_id > 0 ? get_userdata( $user_id ) : false;
	return $user && ! empty( $user->allcaps[ NB_BASE_DESIGN_CAP ] );
}

/**
 * Droits retirés aux comptes non designers (client, partenaire), même
 * administrateurs : code et fichiers du site (éditeurs de fichiers, thèmes,
 * HTML libre). Ils gardent l'installation et la gestion des extensions.
 *
 * @return string[]
 */
function nb_base_designer_only_caps(): array {
	return array(
		'edit_files',
		'edit_themes',
		'edit_plugins',
		'install_themes',
		'upload_themes',
		'switch_themes',
		'delete_themes',
		'unfiltered_html',
		'unfiltered_upload',
	);
}

/**
 * Comptes : seul un designer peut modifier, supprimer ou changer le rôle
 * d'un compte designer (le client ne peut pas prendre sa place).
 *
 * @return string[]
 */
function nb_base_protected_user_caps(): array {
	return array( 'edit_user', 'delete_user', 'remove_user', 'promote_user' );
}

add_filter(
	'map_meta_cap',
	static function ( $caps, $cap, $user_id, $args ) {
		$designer_only = in_array( $cap, nb_base_designer_only_caps(), true );
		$user_cap      = in_array( $cap, nb_base_protected_user_caps(), true );
		$create_user   = in_array( $cap, array( 'create_users', 'add_users' ), true );
		if ( ! $designer_only && ! $user_cap && ! $create_user ) {
			return $caps;
		}
		if ( nb_base_user_is_designer( (int) $user_id ) ) {
			return $caps;
		}
		if ( $create_user ) {
			// Création de comptes : accès client « client_users » (fermé par défaut).
			if ( ! nb_base_feature_enabled( 'client_users' ) ) {
				$caps[] = 'do_not_allow';
			}
		} elseif ( $designer_only ) {
			$caps[] = 'do_not_allow';
		} elseif ( ! empty( $args[0] ) && (int) $args[0] !== (int) $user_id && nb_base_user_is_designer( (int) $args[0] ) ) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	10,
	4
);

/**
 * Création de comptes par un non-designer : seulement si l'accès client
 * « Création de comptes » (client_users) est ouvert (NB Base → Fonctionnalités).
 * Création et modification des comptes par un non-designer : tous les rôles
 * sauf administrateur (un collaborateur oui, un nouvel administrateur non).
 * S'applique aux écrans Comptes et à l'API REST (`get_editable_roles()`).
 */
add_filter(
	'editable_roles',
	static function ( $roles ) {
		if ( ! nb_base_user_is_designer( get_current_user_id() ) ) {
			unset( $roles['administrator'] );
		}
		return $roles;
	}
);
