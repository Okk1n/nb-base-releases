<?php
/**
 * Fond des sections plein écran (photo + vidéo MP4 facultative), commun au
 * bloc Hero et au hero des contenus (réalisations…). Styles : ceux du bloc
 * Hero (classes nb-hero__*).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML du fond : photo (recadrée au centre) et vidéo en boucle, sans le son.
 *
 * @param int   $image_id Image (médiathèque), 0 si aucune.
 * @param int   $video_id Vidéo MP4 (médiathèque), 0 si aucune. La photo sert d'affiche.
 */
function nb_base_hero_media_html( int $image_id, int $video_id ): string {
	$image    = $image_id
		? wp_get_attachment_image(
			$image_id,
			'full',
			false,
			array(
				'class'         => 'nb-hero__image',
				'alt'           => '',
				'sizes'         => '100vw',
				'loading'       => 'eager',
				'fetchpriority' => 'high',
			)
		)
		: '';
	$video_url = $video_id ? wp_get_attachment_url( $video_id ) : '';
	$poster    = $image_id ? wp_get_attachment_image_url( $image_id, 'full' ) : '';

	$html = '<div class="nb-hero__media" aria-hidden="true">' . $image;
	if ( $video_url ) {
		$html .= '<video class="nb-hero__video" autoplay muted loop playsinline preload="metadata"' . ( $poster ? ' poster="' . esc_url( $poster ) . '"' : '' ) . '>'
			. '<source src="' . esc_url( $video_url ) . '" type="video/mp4"></video>';
	}
	return $html . '</div>';
}
