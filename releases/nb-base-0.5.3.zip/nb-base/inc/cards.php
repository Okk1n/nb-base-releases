<?php
/**
 * Cartes : balisage commun aux grilles statiques (bloc nb-base/card) et aux
 * futures grilles de contenus (réalisations, produits…), pour que les deux
 * restent identiques. Styles : src/blocks/card/style.scss.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML d'une carte, ou chaîne vide si elle n'a aucun contenu.
 *
 * @param array  $card {
 *     @type int    $image_id Image (médiathèque).
 *     @type string $title    Titre (texte, retours à la ligne <br> admis).
 *     @type string $text     Texte (idem).
 *     @type array  $items    Éléments de liste (texte brut).
 *     @type string $actions  HTML du bouton (blocs natifs déjà rendus).
 * }
 * @param string $wrapper_attributes Attributs de l'élément racine (get_block_wrapper_attributes()).
 */
function nb_base_card_html( array $card, string $wrapper_attributes = 'class="wp-block-nb-base-card"' ): string {
	$allowed = array( 'br' => array() );
	$title   = trim( (string) ( $card['title'] ?? '' ) );
	$text    = trim( (string) ( $card['text'] ?? '' ) );
	$items   = array_values(
		array_filter(
			array_map( static fn( $item ) => trim( wp_strip_all_tags( (string) $item ) ), (array) ( $card['items'] ?? array() ) ),
			static fn( $item ) => '' !== $item
		)
	);
	$actions = (string) ( $card['actions'] ?? '' );
	$image   = '';

	$image_id = (int) ( $card['image_id'] ?? 0 );
	if ( $image_id ) {
		$image = wp_get_attachment_image(
			$image_id,
			'medium_large',
			false,
			array(
				'sizes' => '(min-width: 992px) 25vw, (min-width: 768px) 50vw, 100vw',
			)
		);
	}

	$has_title   = '' !== trim( wp_strip_all_tags( $title ) );
	$has_text    = '' !== trim( wp_strip_all_tags( $text ) );
	$has_actions = '' !== trim( wp_strip_all_tags( $actions ) );

	if ( '' === $image && ! $has_title && ! $has_text && ! $items && ! $has_actions ) {
		return '';
	}

	$html = '<div ' . $wrapper_attributes . '>';
	if ( '' !== $image ) {
		$html .= '<figure class="nb-card__media">' . $image . '</figure>';
	}
	if ( $has_title ) {
		$html .= '<h3 class="nb-card__title">' . wp_kses( $title, $allowed ) . '</h3>';
	}
	if ( $has_text ) {
		$html .= '<p class="nb-card__text">' . wp_kses( $text, $allowed ) . '</p>';
	}
	if ( $items ) {
		$html .= '<ul class="nb-card__list">';
		foreach ( $items as $item ) {
			$html .= '<li>' . esc_html( $item ) . '</li>';
		}
		$html .= '</ul>';
	}
	if ( $has_actions ) {
		$html .= '<div class="nb-card__actions">' . $actions . '</div>';
	}
	return $html . '</div>';
}
