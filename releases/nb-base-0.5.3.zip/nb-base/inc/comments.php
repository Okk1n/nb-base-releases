<?php
/**
 * Commentaires désactivés sur tous les sites (sites vitrines d'artisans :
 * aucun usage). Uniquement par les points d'accroche publics de WordPress :
 *
 * - aucun type de contenu ne gère les commentaires ni les rétroliens ;
 * - commentaires et rétroliens fermés partout, commentaires existants masqués ;
 * - administration : menu Commentaires, page Réglages → Commentaires, entrée
 *   de la barre d'administration et blocs de commentaires retirés (accès
 *   direct à ces pages : renvoi vers le tableau de bord) ;
 * - pas de flux des commentaires, pas d'en-tête X-Pingback ni de méthode
 *   XML-RPC « pingback ».
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		foreach ( get_post_types() as $type ) {
			if ( post_type_supports( $type, 'comments' ) ) {
				remove_post_type_support( $type, 'comments' );
			}
			if ( post_type_supports( $type, 'trackbacks' ) ) {
				remove_post_type_support( $type, 'trackbacks' );
			}
		}
	},
	100
);

add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
add_filter( 'comments_array', '__return_empty_array', 20 );
add_filter( 'feed_links_show_comments_feed', '__return_false' );

add_filter(
	'wp_headers',
	static function ( array $headers ): array {
		unset( $headers['X-Pingback'] );
		return $headers;
	}
);

add_filter(
	'xmlrpc_methods',
	static function ( array $methods ): array {
		unset( $methods['pingback.ping'], $methods['pingback.extensions.getPingbacks'] );
		return $methods;
	}
);

add_action(
	'admin_menu',
	static function () {
		remove_menu_page( 'edit-comments.php' );
		remove_submenu_page( 'options-general.php', 'options-discussion.php' );
	},
	999
);

add_action(
	'admin_init',
	static function () {
		global $pagenow;
		if ( in_array( $pagenow, array( 'edit-comments.php', 'comment.php', 'options-discussion.php' ), true ) ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
	}
);

add_action(
	'admin_bar_menu',
	static function ( WP_Admin_Bar $bar ) {
		$bar->remove_node( 'comments' );
	},
	999
);

// Blocs de commentaires : absents de l'inserteur.
add_filter(
	'register_block_type_args',
	static function ( array $args, string $name ): array {
		if ( in_array( $name, array( 'core/comments', 'core/comment-template', 'core/comments-title', 'core/comments-pagination', 'core/post-comments-form', 'core/latest-comments', 'core/post-comments-count', 'core/post-comments-link' ), true ) ) {
			$args['supports']             = isset( $args['supports'] ) && is_array( $args['supports'] ) ? $args['supports'] : array();
			$args['supports']['inserter'] = false;
		}
		return $args;
	},
	10,
	2
);
