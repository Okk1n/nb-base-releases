<?php
/**
 * Redirections automatiques (fonctionnalité `redirects`).
 *
 * Quand une adresse du site change, l'ancienne redirige (301) vers la
 * nouvelle :
 * - base d'adresse d'un type de contenu modifiée dans NB Base
 *   (ex. /realisations/… → /nos-chantiers/…), page liste et pages incluses ;
 * - page renommée ou déplacée sous une autre page (et ses sous-pages).
 *   WordPress le fait déjà pour les contenus non hiérarchiques (réalisations,
 *   produits : `wp_old_slug_redirect()`), pas pour les pages.
 *
 * Les anciennes adresses sont toujours mémorisées (données invisibles, sans
 * effet) : activer la fonctionnalité plus tard couvre aussi les changements
 * passés. La redirection n'a lieu que si la fonctionnalité est active et
 * seulement sur une adresse introuvable (404) : une page créée depuis à
 * l'ancienne adresse reste affichée.
 *
 * Adresses de l'ancien site lors d'une refonte : hors champ (extension
 * « Redirection », voir README).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_REDIRECT_BASES_OPTION = 'nb_base_redirect_bases';
const NB_BASE_OLD_PATH_META         = '_nb_base_old_path';
const NB_BASE_REDIRECT_MAX_OLD      = 20;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['redirects'] = array(
			'group'       => 'seo',
			'label'       => __( 'Automatic redirects', 'nb-base' ),
			'description' => __( 'When a page is renamed or moved, or when a content type’s URL slug is changed, the old address permanently redirects (301) to the new one. Addresses of a previous website are not covered: use a redirect plugin for a redesign.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Chemin relatif à l'accueil, sans barres en début et fin (ex. « a/b »).
 */
function nb_base_redirect_path( string $url ): string {
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( '' !== trim( $home, '/' ) && str_starts_with( $path, $home ) ) {
		$path = substr( $path, strlen( $home ) );
	}
	return trim( rawurldecode( $path ), '/' );
}

/**
 * Types de contenu dont la base d'adresse est suivie : publics, non natifs,
 * avec des adresses lisibles.
 */
function nb_base_redirect_post_types(): array {
	$types = array();
	foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $type ) {
		if ( ! empty( $type->rewrite['slug'] ) ) {
			$types[] = $type->name;
		}
	}
	/**
	 * Types de contenu dont le changement de base d'adresse est redirigé.
	 */
	return (array) apply_filters( 'nb_base_redirect_post_types', $types );
}

/**
 * Base d'adresse actuelle d'un type de contenu (ex. « realisations »).
 */
function nb_base_redirect_type_base( WP_Post_Type $type ): string {
	global $wp_rewrite;
	$base = trim( (string) $type->rewrite['slug'], '/' );
	if ( ! empty( $type->rewrite['with_front'] ) && $wp_rewrite instanceof WP_Rewrite ) {
		$base = trim( trim( (string) $wp_rewrite->front, '/' ) . '/' . $base, '/' );
	}
	return $base;
}

/**
 * Mémorise les bases d'adresse des types de contenu :
 * type => array( 'current' => base, 'old' => anciennes bases ).
 * Un type non enregistré (fonctionnalité coupée) garde son historique.
 */
add_action(
	'init',
	static function () {
		if ( ! get_option( 'permalink_structure' ) ) {
			return;
		}
		$saved   = get_option( NB_BASE_REDIRECT_BASES_OPTION, array() );
		$saved   = is_array( $saved ) ? $saved : array();
		$changed = false;
		foreach ( nb_base_redirect_post_types() as $name ) {
			$type = get_post_type_object( $name );
			if ( ! $type || empty( $type->rewrite['slug'] ) ) {
				continue;
			}
			$base  = nb_base_redirect_type_base( $type );
			$entry = isset( $saved[ $name ] ) && is_array( $saved[ $name ] ) ? $saved[ $name ] : array();
			$old   = array_values( array_filter( (array) ( $entry['old'] ?? array() ), 'is_string' ) );
			$prev  = (string) ( $entry['current'] ?? '' );
			if ( $prev === $base ) {
				continue;
			}
			if ( '' !== $prev ) {
				$old[] = $prev;
			}
			// Retour à une ancienne base : elle n'est plus redirigée.
			$old = array_values( array_unique( array_diff( $old, array( $base ) ) ) );

			$saved[ $name ] = array(
				'current' => $base,
				'old'     => array_slice( $old, -NB_BASE_REDIRECT_MAX_OLD ),
			);
			$changed        = true;
		}
		if ( $changed ) {
			update_option( NB_BASE_REDIRECT_BASES_OPTION, $saved, true );
		}
	},
	99
);

/**
 * Types hiérarchiques dont les anciennes adresses sont mémorisées (pages).
 * Les autres sont déjà redirigés par WordPress (`wp_old_slug_redirect()`).
 */
function nb_base_redirect_tracks_post( WP_Post $post ): bool {
	$type = get_post_type_object( $post->post_type );
	return $type && $type->public && $type->hierarchical && 'attachment' !== $post->post_type;
}

/**
 * Chemin d'une page (« parent/enfant »), d'après l'état donné.
 */
function nb_base_redirect_page_path( WP_Post $post ): string {
	return trim( (string) get_page_uri( $post ), '/' );
}

/**
 * Page publiée renommée ou déplacée : l'ancien chemin est mémorisé sur la
 * page. Les sous-pages suivent (redirection par préfixe).
 */
add_action(
	'post_updated',
	static function ( int $post_id, WP_Post $after, WP_Post $before ) {
		if ( 'publish' !== $before->post_status || ! nb_base_redirect_tracks_post( $after ) ) {
			return;
		}
		if ( ! get_option( 'permalink_structure' ) ) {
			return;
		}
		$old_path = nb_base_redirect_page_path( $before );
		$new_path = nb_base_redirect_page_path( $after );
		$stored   = array_map( 'strval', get_post_meta( $post_id, NB_BASE_OLD_PATH_META ) );

		// Retour à un ancien chemin : il n'est plus redirigé.
		if ( in_array( $new_path, $stored, true ) ) {
			delete_post_meta( $post_id, NB_BASE_OLD_PATH_META, $new_path );
		}
		if ( '' === $old_path || $old_path === $new_path || in_array( $old_path, $stored, true ) ) {
			return;
		}
		add_post_meta( $post_id, NB_BASE_OLD_PATH_META, wp_slash( $old_path ) );

		$stored = get_post_meta( $post_id, NB_BASE_OLD_PATH_META );
		while ( count( $stored ) > NB_BASE_REDIRECT_MAX_OLD ) {
			delete_post_meta( $post_id, NB_BASE_OLD_PATH_META, array_shift( $stored ) );
		}
	},
	10,
	3
);

/**
 * Nouvelle adresse pour un chemin introuvable, sinon chaîne vide.
 */
function nb_base_redirect_target( string $path ): string {
	if ( '' === $path ) {
		return '';
	}

	// Base d'un type de contenu modifiée : la fin du chemin est conservée.
	$bases = get_option( NB_BASE_REDIRECT_BASES_OPTION, array() );
	foreach ( is_array( $bases ) ? $bases : array() as $name => $entry ) {
		$current = (string) ( $entry['current'] ?? '' );
		if ( '' === $current || ! post_type_exists( (string) $name ) ) {
			continue;
		}
		foreach ( (array) ( $entry['old'] ?? array() ) as $old ) {
			$old = (string) $old;
			if ( '' !== $old && $old !== $current && ( $path === $old || str_starts_with( $path, $old . '/' ) ) ) {
				return home_url( user_trailingslashit( $current . substr( $path, strlen( $old ) ) ) );
			}
		}
	}

	// Page renommée ou déplacée : le plus long ancien chemin qui commence
	// le chemin demandé (une sous-page suit sa page parente).
	// Profondeur bornée (10 niveaux) : une adresse farfelue ne coûte qu'une requête.
	$segments = array_slice( explode( '/', $path ), 0, 10 );
	$prefixes = array();
	for ( $i = count( $segments ); $i > 0; $i-- ) {
		$prefixes[] = implode( '/', array_slice( $segments, 0, $i ) );
	}
	$types = array_values(
		array_filter(
			get_post_types( array( 'public' => true, 'hierarchical' => true ) ),
			static fn( $type ) => 'attachment' !== $type
		)
	);
	if ( ! $types ) {
		return '';
	}
	// Une seule requête pour tous les préfixes, puis du plus long au plus court.
	$ids = get_posts(
		array(
			'post_type'        => $types,
			'post_status'      => 'publish',
			'posts_per_page'   => 20,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- seulement sur une adresse introuvable.
				array(
					'key'     => NB_BASE_OLD_PATH_META,
					'value'   => $prefixes,
					'compare' => 'IN',
				),
			),
		)
	);
	$owners = array();
	foreach ( $ids as $id ) {
		foreach ( (array) get_post_meta( (int) $id, NB_BASE_OLD_PATH_META ) as $old ) {
			$owners[ (string) $old ] ??= (int) $id;
		}
	}
	foreach ( $prefixes as $prefix ) {
		if ( ! isset( $owners[ $prefix ] ) ) {
			continue;
		}
		$post = get_post( $owners[ $prefix ] );
		if ( ! $post ) {
			continue;
		}
		$rest = substr( $path, strlen( $prefix ) );
		if ( '' === $rest ) {
			return (string) get_permalink( $post );
		}
		// Sous-page : seulement si elle existe à la nouvelle adresse.
		$new_path = nb_base_redirect_page_path( $post ) . $rest;
		$child    = get_page_by_path( $new_path, OBJECT, $post->post_type );
		if ( $child instanceof WP_Post && 'publish' === $child->post_status ) {
			return (string) get_permalink( $child );
		}
	}
	return '';
}

/**
 * Adresse introuvable : redirection vers la nouvelle adresse (avant les
 * suppositions de WordPress, `redirect_canonical()`).
 */
add_action(
	'template_redirect',
	static function () {
		if ( ! is_404() || ! nb_base_feature_enabled( 'redirects' ) || ! get_option( 'permalink_structure' ) ) {
			return;
		}
		$request = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- comparé à des chemins enregistrés.
		$path    = nb_base_redirect_path( $request );
		$target  = nb_base_redirect_target( $path );
		if ( '' === $target || nb_base_redirect_path( $target ) === $path ) {
			return;
		}
		$query = (string) wp_parse_url( $request, PHP_URL_QUERY );
		if ( '' !== $query ) {
			$target .= ( str_contains( $target, '?' ) ? '&' : '?' ) . $query;
		}
		if ( wp_safe_redirect( $target, 301, 'nb-base' ) ) {
			exit;
		}
	},
	9
);
