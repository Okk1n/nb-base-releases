<?php
/**
 * Établissement : informations sur l'entreprise, communes à tout le site,
 * modifiables par le client (menu principal « Établissement ») : type d'activité, description, adresse détaillée,
 * zone d'intervention, SIRET.
 *
 * Horaires d'ouverture structurés (« hours ») : jour => plages (ouverture,
 * fermeture), plusieurs plages par jour (ex. 8h–12h et 14h–19h), aucune =
 * fermé. Repris par les données structurées (openingHoursSpecification), le
 * llms.txt et, si le texte libre des horaires (pied de page) est vide, par
 * les coordonnées affichées (nb_base_business_hours_lines()).
 *
 * La fiche rassemble toutes les informations sur l'entreprise, communes au
 * site (la mise en page reste dans Apparence → En-tête et pied de page) ;
 * certaines gardent leur option d'origine (noms définitifs) : nom du site
 * (réglage natif « title »), téléphone (nb_base_phone), e-mail et texte libre
 * des horaires (nb_base_contact), réseaux sociaux (nb_base_footer.social),
 * note Google (nb_base_google_rating, nb_base_google_url). Logo : site_logo
 * (page En-tête et pied de page).
 *
 * Adresse : celle de la fiche, seule adresse du site (affichée et données
 * structurées). Ancien champ en texte libre du pied de page
 * (nb_base_contact.address) : converti une fois par site
 * (nb_base_business_migrate_address()), repli d'affichage seulement.
 * Servent aussi aux données structurées (inc/structured-data.php).
 *
 * Option nb_base_business (objet, nettoyée à l'écriture et à la lecture).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_BUSINESS_OPTION = 'nb_base_business';

/**
 * Types d'activité proposés (types schema.org) : type => libellé.
 *
 * @return array<string, string>
 */
function nb_base_business_types(): array {
	return array(
		'LocalBusiness'              => __( 'Local business (generic)', 'nb-base' ),
		'HomeAndConstructionBusiness' => __( 'Home and construction', 'nb-base' ),
		'GeneralContractor'          => __( 'General contractor', 'nb-base' ),
		'RoofingContractor'          => __( 'Roofing contractor', 'nb-base' ),
		'Plumber'                    => __( 'Plumber', 'nb-base' ),
		'Electrician'                => __( 'Electrician', 'nb-base' ),
		'HVACBusiness'               => __( 'Heating, ventilation, air conditioning', 'nb-base' ),
		'HousePainter'               => __( 'House painter', 'nb-base' ),
		'Locksmith'                  => __( 'Locksmith', 'nb-base' ),
		'MovingCompany'              => __( 'Moving company', 'nb-base' ),
		'HomeGoodsStore'             => __( 'Home goods store', 'nb-base' ),
		'HardwareStore'              => __( 'Hardware and building materials store', 'nb-base' ),
		'FurnitureStore'             => __( 'Furniture store', 'nb-base' ),
		'Store'                      => __( 'Store (other)', 'nb-base' ),
		'ProfessionalService'        => __( 'Professional service (other)', 'nb-base' ),
	);
}

/**
 * Pays proposés : code ISO 3166-1 => libellé.
 *
 * @return array<string, string>
 */
function nb_base_business_countries(): array {
	return array(
		'FR' => __( 'France', 'nb-base' ),
		'BE' => __( 'Belgium', 'nb-base' ),
		'CH' => __( 'Switzerland', 'nb-base' ),
		'LU' => __( 'Luxembourg', 'nb-base' ),
		'MC' => __( 'Monaco', 'nb-base' ),
		'CA' => __( 'Canada', 'nb-base' ),
		'IT' => __( 'Italy', 'nb-base' ),
		'ES' => __( 'Spain', 'nb-base' ),
		'DE' => __( 'Germany', 'nb-base' ),
		'GB' => __( 'United Kingdom', 'nb-base' ),
	);
}

/** Plages horaires au plus par jour. */
const NB_BASE_BUSINESS_HOURS_MAX_SLOTS = 4;

/**
 * Jours de la semaine (clé => nom schema.org), du lundi au dimanche.
 *
 * @return array<string, string>
 */
function nb_base_business_days(): array {
	return array(
		'mo' => 'Monday',
		'tu' => 'Tuesday',
		'we' => 'Wednesday',
		'th' => 'Thursday',
		'fr' => 'Friday',
		'sa' => 'Saturday',
		'su' => 'Sunday',
	);
}

/**
 * Horaires vides (tous les jours fermés).
 *
 * @return array<string, array>
 */
function nb_base_business_hours_defaults(): array {
	return array_fill_keys( array_keys( nb_base_business_days() ), array() );
}

/**
 * Horaires nettoyés : heures « HH:MM » (fermeture « 24:00 » admise),
 * ouverture avant fermeture, plages triées, 4 au plus par jour.
 *
 * @param mixed $value Valeur enregistrée ou reçue.
 * @return array<string, array<int, array{opens: string, closes: string}>>
 */
function nb_base_sanitize_business_hours( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$clean = nb_base_business_hours_defaults();
	$time  = '/^([01]\d|2[0-3]):[0-5]\d$/';
	foreach ( array_keys( $clean ) as $day ) {
		$slots = array();
		foreach ( (array) ( $value[ $day ] ?? array() ) as $slot ) {
			$opens  = is_array( $slot ) ? trim( (string) ( $slot['opens'] ?? '' ) ) : '';
			$closes = is_array( $slot ) ? trim( (string) ( $slot['closes'] ?? '' ) ) : '';
			if ( preg_match( $time, $opens ) && ( preg_match( $time, $closes ) || '24:00' === $closes ) && $opens < $closes ) {
				$slots[] = array(
					'opens'  => $opens,
					'closes' => $closes,
				);
			}
		}
		usort( $slots, static fn( $a, $b ) => strcmp( $a['opens'], $b['opens'] ) );
		$clean[ $day ] = array_slice( $slots, 0, NB_BASE_BUSINESS_HOURS_MAX_SLOTS );
	}
	return $clean;
}

/**
 * Horaires regroupés : jours consécutifs aux plages identiques (jours
 * fermés exclus), dans l'ordre de la semaine.
 *
 * @return array<int, array{days: string[], slots: array}>
 */
function nb_base_business_hours_groups(): array {
	$groups = array();
	$last   = null;
	foreach ( nb_base_business()['hours'] as $day => $slots ) {
		if ( ! $slots ) {
			$last = null;
			continue;
		}
		if ( null !== $last && $groups[ $last ]['slots'] === $slots ) {
			$groups[ $last ]['days'][] = $day;
			continue;
		}
		$groups[] = array(
			'days'  => array( $day ),
			'slots' => $slots,
		);
		$last     = array_key_last( $groups );
	}
	return $groups;
}

/**
 * Heure affichée (« 8h », « 8h30 » en français ; « 8 am », « 8:30 am » en
 * anglais).
 */
function nb_base_business_format_time( string $time ): string {
	if ( '24:00' === $time ) {
		$time = '00:00';
	}
	$date = DateTimeImmutable::createFromFormat( '!H:i', $time, new DateTimeZone( 'UTC' ) );
	if ( ! $date ) {
		return $time;
	}
	$format = '00' === $date->format( 'i' )
		/* translators: PHP date format of an opening time without minutes (e.g. 8 am). */
		? _x( 'g a', 'opening hours', 'nb-base' )
		/* translators: PHP date format of an opening time with minutes (e.g. 8:30 am). */
		: _x( 'g:i a', 'opening hours', 'nb-base' );
	return wp_date( $format, $date->getTimestamp(), new DateTimeZone( 'UTC' ) );
}

/**
 * Horaires en texte, une ligne par groupe de jours (« Lun – ven : 8h – 12h,
 * 14h – 19h »). Vide si aucun horaire n'est saisi.
 *
 * @return string[]
 */
function nb_base_business_hours_lines(): array {
	global $wp_locale;
	$names = array_keys( nb_base_business_days() );
	$name  = static function ( string $day ) use ( $wp_locale, $names ): string {
		// WP_Locale : 0 = dimanche.
		$index = ( array_search( $day, $names, true ) + 1 ) % 7;
		return $wp_locale ? $wp_locale->get_weekday( $index ) : $day;
	};
	$lines = array();
	foreach ( nb_base_business_hours_groups() as $group ) {
		$first = $name( $group['days'][0] );
		$days  = count( $group['days'] ) > 1
			/* translators: 1: first day, 2: last day (e.g. Monday–Friday). */
			? sprintf( __( '%1$s–%2$s', 'nb-base' ), $first, $name( end( $group['days'] ) ) )
			: $first;
		$slots = array_map(
			/* translators: 1: opening time, 2: closing time (e.g. 8 am–6 pm). */
			static fn( $slot ) => sprintf( __( '%1$s–%2$s', 'nb-base' ), nb_base_business_format_time( $slot['opens'] ), nb_base_business_format_time( $slot['closes'] ) ),
			$group['slots']
		);
		/* translators: 1: days, 2: time slots. */
		$lines[] = sprintf( __( '%1$s: %2$s', 'nb-base' ), mb_strtoupper( mb_substr( $days, 0, 1 ) ) . mb_substr( $days, 1 ), implode( ', ', $slots ) );
	}
	return $lines;
}

/**
 * Horaires affichés (pied de page, coordonnées, llms.txt) : texte libre
 * (« nb_base_contact.hours ») s'il est rempli, sinon résumé des horaires
 * par jour.
 *
 * @return string[]
 */
function nb_base_business_hours_display(): array {
	$text = function_exists( 'nb_base_contact_settings' ) ? trim( nb_base_contact_settings()['hours'] ) : '';
	return '' !== $text ? array( $text ) : nb_base_business_hours_lines();
}

/**
 * @return array{type: string, description: string, street: string, postalCode: string, city: string, country: string, areaServed: string, siret: string, hours: array}
 */
function nb_base_business_defaults(): array {
	return array(
		'type'        => 'LocalBusiness',
		'description' => '',
		'street'      => '',
		'postalCode'  => '',
		'city'        => '',
		'country'     => 'FR',
		'areaServed'  => '', // Une zone par ligne.
		'siret'       => '',
		'hours'       => nb_base_business_hours_defaults(),
	);
}

/**
 * Valeur nettoyée.
 *
 * @param mixed $value Valeur enregistrée ou reçue.
 */
function nb_base_sanitize_business( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = nb_base_business_defaults();
	$type     = (string) ( $value['type'] ?? $defaults['type'] );
	$country  = strtoupper( (string) ( $value['country'] ?? $defaults['country'] ) );
	$areas    = array_filter( array_map( 'sanitize_text_field', explode( "\n", (string) ( $value['areaServed'] ?? '' ) ) ) );

	return array(
		'type'        => array_key_exists( $type, nb_base_business_types() ) ? $type : $defaults['type'],
		'description' => mb_substr( sanitize_textarea_field( (string) ( $value['description'] ?? '' ) ), 0, 500 ),
		'street'      => sanitize_textarea_field( (string) ( $value['street'] ?? '' ) ),
		'postalCode'  => mb_substr( sanitize_text_field( (string) ( $value['postalCode'] ?? '' ) ), 0, 12 ),
		'city'        => sanitize_text_field( (string) ( $value['city'] ?? '' ) ),
		'country'     => array_key_exists( $country, nb_base_business_countries() ) ? $country : $defaults['country'],
		'areaServed'  => implode( "\n", array_slice( $areas, 0, 30 ) ),
		'siret'       => preg_replace( '/[^0-9]/', '', (string) ( $value['siret'] ?? '' ) ),
		'hours'       => nb_base_sanitize_business_hours( $value['hours'] ?? array() ),
	);
}

function nb_base_business(): array {
	return nb_base_sanitize_business( get_option( NB_BASE_BUSINESS_OPTION, array() ) );
}

/**
 * Adresse de l'établissement en texte (lignes : rue, code postal + ville),
 * seule adresse du site (pied de page, coordonnées, données structurées).
 */
function nb_base_business_address_text(): string {
	$business = nb_base_business();
	$lines    = array_filter(
		array(
			trim( $business['street'] ),
			trim( $business['postalCode'] . ' ' . $business['city'] ),
		)
	);
	return implode( "\n", $lines );
}

add_action(
	'init',
	static function () {
		$string     = array( 'type' => 'string' );
		$properties = array_fill_keys( array_keys( nb_base_business_defaults() ), $string );
		$slot       = array(
			'type'                 => 'object',
			'properties'           => array(
				'opens'  => $string,
				'closes' => $string,
			),
			'additionalProperties' => false,
		);
		$properties['hours'] = array(
			'type'                 => 'object',
			'properties'           => array_fill_keys(
				array_keys( nb_base_business_days() ),
				array(
					'type'     => 'array',
					'items'    => $slot,
					'maxItems' => NB_BASE_BUSINESS_HOURS_MAX_SLOTS,
				)
			),
			'additionalProperties' => false,
		);
		register_setting(
			'nb_base',
			NB_BASE_BUSINESS_OPTION,
			array(
				'type'              => 'object',
				'description'       => __( 'Business information shared by the whole site.', 'nb-base' ),
				'default'           => nb_base_business_defaults(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => $properties,
						'additionalProperties' => false,
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_business',
			)
		);
	}
);
add_filter( 'option_' . NB_BASE_BUSINESS_OPTION, 'nb_base_sanitize_business' );

const NB_BASE_BUSINESS_ADMIN_SLUG = 'nb-base-business';

/**
 * Page « Établissement » : menu principal de l'administration (administrateurs,
 * client compris).
 */
add_action(
	'admin_menu',
	static function () {
		$hook = add_menu_page(
			__( 'Business', 'nb-base' ),
			__( 'Business', 'nb-base' ),
			'manage_options',
			NB_BASE_BUSINESS_ADMIN_SLUG,
			static function () {
				echo '<div class="wrap"><h1>' . esc_html__( 'Business', 'nb-base' ) . '</h1><div id="nb-base-business"></div></div>';
			},
			'dashicons-store',
			3
		);
		add_action(
			'admin_enqueue_scripts',
			static function ( string $current ) use ( $hook ) {
				$asset_file = NB_BASE_DIR . '/build-admin/business.asset.php';
				if ( $current !== $hook || ! is_readable( $asset_file ) ) {
					return;
				}
				$asset = require $asset_file;
				wp_enqueue_script( 'nb-base-business', NB_BASE_URI . '/build-admin/business.js', $asset['dependencies'], $asset['version'], true );
				wp_enqueue_style( 'nb-base-business', NB_BASE_URI . '/build-admin/business.css', array( 'wp-components' ), $asset['version'] );
				wp_set_script_translations( 'nb-base-business', 'nb-base', NB_BASE_DIR . '/languages' );

				$options = static fn( array $list ) => array_map(
					static fn( $value, $label ) => array(
						'value' => $value,
						'label' => $label,
					),
					array_keys( $list ),
					array_values( $list )
				);
				wp_add_inline_script(
					'nb-base-business',
					'window.nbBaseBusiness = ' . wp_json_encode(
						array(
							'types'     => $options( nb_base_business_types() ),
							'countries' => $options( nb_base_business_countries() ),
							'headerUrl' => admin_url( 'themes.php?page=' . NB_BASE_HEADER_ADMIN_SLUG ),
							'social'    => array_map(
								static fn( $key, $network ) => array(
									'key'   => $key,
									'label' => $network['label'],
								),
								array_keys( nb_base_social_networks() ),
								nb_base_social_networks()
							),
						)
					) . ';',
					'before'
				);
			}
		);
	}
);

/** Option : ancienne adresse en texte libre convertie (1 = fait). */
const NB_BASE_BUSINESS_ADDRESS_MIGRATED_OPTION = 'nb_base_business_address_migrated';

/**
 * Découpe une adresse en texte libre (ancien champ du pied de page) :
 * dernière ligne « 83600 Fréjus » → code postal + ville, le reste → rue ;
 * sur une ligne, « 1 rue X, 83600 Fréjus ». Sinon tout dans la rue (même
 * affichage qu'avant).
 *
 * @return array{street: string, postalCode: string, city: string}
 */
function nb_base_business_parse_address( string $text ): array {
	$lines  = array_values( array_filter( array_map( 'trim', preg_split( '/\R/', $text ) ) ) );
	$result = array(
		'street'     => implode( "\n", $lines ),
		'postalCode' => '',
		'city'       => '',
	);
	if ( ! $lines ) {
		return $result;
	}
	$last = array_pop( $lines );
	if ( preg_match( '/^(\d{4,5})\s+(\D.*)$/u', $last, $m ) ) {
		return array(
			'street'     => implode( "\n", $lines ),
			'postalCode' => $m[1],
			'city'       => trim( $m[2] ),
		);
	}
	if ( ! $lines && preg_match( '/^(.+?),?\s+(\d{4,5})\s+(\D[^,]*)$/u', $last, $m ) ) {
		return array(
			'street'     => trim( $m[1], " ,\t" ),
			'postalCode' => $m[2],
			'city'       => trim( $m[3] ),
		);
	}
	return $result;
}

/**
 * Sites existants : l'adresse saisie dans l'ancien champ du pied de page
 * (nb_base_contact.address) est reprise dans la fiche Établissement si
 * celle-ci n'a pas d'adresse. Une fois par site ; l'ancien texte reste en
 * base (repli d'affichage tant que la fiche n'a pas d'adresse).
 */
function nb_base_business_migrate_address(): void {
	if ( get_option( NB_BASE_BUSINESS_ADDRESS_MIGRATED_OPTION ) ) {
		return;
	}
	update_option( NB_BASE_BUSINESS_ADDRESS_MIGRATED_OPTION, 1, true );
	$business = nb_base_business();
	$legacy   = function_exists( 'nb_base_contact_settings' ) ? trim( nb_base_contact_settings()['address'] ) : '';
	if ( '' === $legacy || '' !== trim( $business['street'] . $business['postalCode'] . $business['city'] ) ) {
		return;
	}
	update_option( NB_BASE_BUSINESS_OPTION, array_merge( $business, nb_base_business_parse_address( $legacy ) ) );
}
add_action( 'admin_init', 'nb_base_business_migrate_address' );
