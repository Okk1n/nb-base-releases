/**
 * Liste des catégories d'un contenu structuré (Réalisations → Catégories) :
 * ordre des catégories principales par glisser-déposer (jQuery UI Sortable,
 * fourni par WordPress). Les sous-catégories suivent leur parent.
 * Dépend du tableau de la liste (#the-list, lignes tr.level-0) : voir README,
 * « Points dépendant de l'interface ». Enregistrement : inc/entry-terms.php.
 */
( function ( $ ) {
	const l10n = window.nbBaseTermOrder || {};
	const $list = $( '#the-list' );
	if ( ! $list.length || ! $.fn.sortable ) {
		return;
	}

	const $hint = $( '<p class="nb-term-order-hint description" role="status"></p>' ).text( l10n.hint );
	$list.closest( 'table' ).before( $hint );

	const idOf = ( row ) => parseInt( String( row.id ).replace( 'tag-', '' ), 10 );

	$list.addClass( 'nb-term-order' ).sortable( {
		items: '> tr.level-0',
		axis: 'y',
		cursor: 'move',
		placeholder: 'nb-term-order__placeholder',
		// Lignes du tableau : largeur des cellules conservée pendant le déplacement.
		helper: ( event, $row ) => {
			$row.children().each( function () {
				$( this ).width( $( this ).width() );
			} );
			return $row;
		},
		start: ( event, ui ) => {
			ui.placeholder.html( `<td colspan="${ ui.item.children().length }">&nbsp;</td>` ).height( ui.item.outerHeight() );
			// Sous-catégories : masquées pendant le déplacement, replacées après.
			const $children = ui.item.nextUntil( 'tr.level-0' ).not( '.ui-sortable-placeholder' );
			ui.item.data( 'nbChildren', $children.hide() );
		},
		stop: ( event, ui ) => {
			ui.item.children().css( 'width', '' );
			const $children = ui.item.data( 'nbChildren' );
			if ( $children && $children.length ) {
				$children.insertAfter( ui.item ).show();
			}
		},
		update: () => {
			const ids = $list.children( 'tr.level-0' ).toArray().map( idOf ).filter( Boolean );
			$.post( l10n.ajaxUrl, { action: 'nb_base_term_order', nonce: l10n.nonce, taxonomy: l10n.taxonomy, ids } )
				.done( ( response ) => {
					const ok = response && response.success;
					$hint.toggleClass( 'is-error', ! ok ).text( ok ? l10n.saved : l10n.error );
					window.wp?.a11y?.speak( ok ? l10n.saved : l10n.error );
				} )
				.fail( () => {
					$hint.addClass( 'is-error' ).text( l10n.error );
					window.wp?.a11y?.speak( l10n.error );
				} );
		},
	} );
} )( window.jQuery );
