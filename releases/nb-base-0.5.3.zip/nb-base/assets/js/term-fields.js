/**
 * Écran d'une catégorie de contenu structuré : champ « Image » (sélecteur
 * de la médiathèque, API publique wp.media). Voir inc/entry-terms.php.
 */
( function ( $ ) {
	const l10n = window.nbBaseTermFields || {};

	function setImage( field, attachment ) {
		const input = field.querySelector( '[data-nb-term-image-input]' );
		const preview = field.querySelector( '[data-nb-term-image-preview]' );
		const choose = field.querySelector( '[data-nb-term-image-choose]' );
		const remove = field.querySelector( '[data-nb-term-image-remove]' );
		input.value = attachment ? String( attachment.id ) : '';
		preview.replaceChildren();
		if ( attachment ) {
			const img = document.createElement( 'img' );
			img.src = attachment.sizes?.thumbnail?.url || attachment.url;
			img.alt = '';
			preview.append( img );
		}
		preview.hidden = ! attachment;
		remove.hidden = ! attachment;
		choose.textContent = attachment ? l10n.replace : l10n.choose;
	}

	document.querySelectorAll( '[data-nb-term-image]' ).forEach( ( field ) => {
		let frame;
		field.querySelector( '[data-nb-term-image-choose]' ).addEventListener( 'click', () => {
			if ( ! frame ) {
				frame = window.wp.media( {
					title: l10n.title,
					button: { text: l10n.button },
					library: { type: 'image' },
					multiple: false,
				} );
				frame.on( 'select', () => setImage( field, frame.state().get( 'selection' ).first().toJSON() ) );
			}
			frame.open();
		} );
		field.querySelector( '[data-nb-term-image-remove]' ).addEventListener( 'click', () => setImage( field, null ) );
	} );

	// Écran d'ajout : le formulaire est vidé après l'ajout (Ajax) ; l'image aussi.
	$( document ).on( 'ajaxSuccess', ( event, xhr, settings ) => {
		if ( typeof settings.data === 'string' && settings.data.includes( 'action=add-tag' ) && ! xhr.responseXML?.querySelector( 'wp_error' ) ) {
			document.querySelectorAll( '#addtag [data-nb-term-image]' ).forEach( ( field ) => setImage( field, null ) );
		}
	} );
} )( window.jQuery );
