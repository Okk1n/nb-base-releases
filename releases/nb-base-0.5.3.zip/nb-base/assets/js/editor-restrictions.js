/**
 * NB Base — coupe les réglages visuels des blocs dans l'éditeur.
 *
 * Chargé pour tout le monde, sauf pour le designer dans l'éditeur de site.
 * Agit uniquement sur l'interface (panneau de droite) : le contenu existant
 * et son rendu ne sont pas modifiés.
 *
 * Pour rouvrir un réglage plus tard : le retirer de RESTRICTED ou l'ajouter
 * à ALLOWED.
 */
( function ( hooks ) {
	'use strict';

	// Familles de réglages coupées (préfixes des chemins theme.json).
	var RESTRICTED = [
		'color.',
		'typography.',
		'spacing.',
		'border.',
		'shadow.',
		'dimensions.',
		'background.',
		'position.',
		'lightbox.',
		'filter.',
	];

	// Clés désignant une liste de valeurs prédéfinies.
	var PRESET_KEYS = [
		'palette',
		'gradients',
		'duotone',
		'fontSizes',
		'fontFamilies',
		'spacingSizes',
		'aspectRatios',
		'dimensionSizes',
		'presets',
	];

	// Exceptions : nécessaires au rendu correct dans l'éditeur.
	var ALLOWED = [ 'typography.fluid', 'spacing.units' ];

	function matches( path, list ) {
		for ( var i = 0; i < list.length; i++ ) {
			if ( path === list[ i ] || path.indexOf( list[ i ] ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	hooks.addFilter(
		'blockEditor.useSetting.before',
		'nb-base/restrict-settings',
		function ( value, path ) {
			if ( ! path || matches( path, ALLOWED ) || ! matches( path, RESTRICTED ) ) {
				return value;
			}
			// Listes de valeurs prédéfinies (palette, tailles…) : liste vide.
			var segments = path.split( '.' );
			for ( var i = 0; i < segments.length; i++ ) {
				if ( PRESET_KEYS.indexOf( segments[ i ] ) !== -1 ) {
					return [];
				}
			}
			// Interrupteurs (couleur du texte, marges…) : désactivés.
			return false;
		}
	);

	// Capacités déclarées par les blocs natifs (indépendantes des réglages) :
	// - « Ajuster le texte » retiré ;
	// - variantes de style natives (image arrondie, séparateur en
	//   pointillés…) retirées, sauf « Fill » / « Outline » du bouton.
	hooks.addFilter(
		'blocks.registerBlockType',
		'nb-base/restrict-core-blocks',
		function ( settings, name ) {
			if ( name.indexOf( 'core/' ) !== 0 ) {
				return settings;
			}
			// Exception : le bouton garde ses styles « Fill » / « Outline » / « Link ».
			var changes = name === 'core/button' ? {} : { styles: [] };
			if ( settings.supports && settings.supports.typography && settings.supports.typography.fitText ) {
				changes.supports = Object.assign( {}, settings.supports, {
					typography: Object.assign( {}, settings.supports.typography, { fitText: false } ),
				} );
			}
			return Object.assign( {}, settings, changes );
		}
	);
} )( window.wp.hooks );
