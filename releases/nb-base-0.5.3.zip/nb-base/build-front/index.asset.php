<?php return array(
	'dependencies' => array(
		
	),
	'version' => '006252260bfe92d79353'
);
