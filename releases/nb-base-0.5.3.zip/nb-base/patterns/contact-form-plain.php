<?php
/**
 * Title: Contact form section (no background)
 * Slug: nb-base/contact-form-plain
 * Inserter: no
 *
 * Variante sans fond de la section « Formulaire de contact »
 * (patterns/contact-form.php), pour les templates dont la section précédente
 * a déjà le fond « alt » (fiche produit : « Autres produits » sur fond alt).
 * Même formulaire, même ancre « devis », mêmes textes communs.
 *
 * @package nb-base
 */

if ( ! function_exists( 'nb_base_feature_enabled' ) || ! nb_base_feature_enabled( 'forms' ) || ! nb_base_forms_plugin_active() ) {
	return;
}
?>
<!-- wp:nb-base/contact-form {"anchor":"devis"} -->
<!-- wp:nb-base/section-header /-->
<!-- wp:nb-base/contact-details /-->
<!-- wp:nb-base/google-rating /-->
<!-- /wp:nb-base/contact-form -->
