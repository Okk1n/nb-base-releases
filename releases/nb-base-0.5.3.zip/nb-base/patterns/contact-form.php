<?php
/**
 * Title: Contact form section
 * Slug: nb-base/contact-form
 * Inserter: no
 *
 * Section « Formulaire de contact » des templates (réalisation, liste des
 * réalisations), juste avant le pied de page : formulaire par défaut (le
 * premier), ancre « devis », textes communs du site (nb_base_contact_section(),
 * modifiables par le client depuis un bloc Formulaire de contact). Fond : bg-alt (fond « alt »).
 * Rien si la fonctionnalité Formulaires est désactivée ou sans extension.
 *
 * @package nb-base
 */

if ( ! function_exists( 'nb_base_feature_enabled' ) || ! nb_base_feature_enabled( 'forms' ) || ! nb_base_forms_plugin_active() ) {
	return;
}

$nb_section = array(
	'anchor'     => 'devis',
	'background' => 'alt',
);
?>
<!-- wp:nb-base/contact-form <?php echo wp_json_encode( $nb_section ); ?> -->
<!-- wp:nb-base/section-header /-->
<!-- wp:nb-base/contact-details /-->
<!-- wp:nb-base/google-rating /-->
<!-- /wp:nb-base/contact-form -->
