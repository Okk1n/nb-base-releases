<?php
/**
 * Title: 404 content
 * Slug: nb-base/404-content
 * Inserter: no
 *
 * @package nb-base
 */

?>
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading"><?php esc_html_e( 'Page not found', 'nb-base' ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php esc_html_e( 'The page you are looking for does not exist or has been moved.', 'nb-base' ); ?></p>
<!-- /wp:paragraph -->
