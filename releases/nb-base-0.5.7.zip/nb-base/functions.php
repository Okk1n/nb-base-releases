<?php
/**
 * NB Base — point d'entrée du thème.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

define( 'NB_BASE_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );
define( 'NB_BASE_DIR', get_template_directory() );
define( 'NB_BASE_URI', get_template_directory_uri() );

require_once NB_BASE_DIR . '/inc/capabilities.php';
require_once NB_BASE_DIR . '/inc/comments.php';
require_once NB_BASE_DIR . '/inc/features.php';
require_once NB_BASE_DIR . '/inc/license.php';
require_once NB_BASE_DIR . '/inc/icons.php';
require_once NB_BASE_DIR . '/inc/blocks.php';
require_once NB_BASE_DIR . '/inc/media-layout.php';
require_once NB_BASE_DIR . '/inc/images.php';
require_once NB_BASE_DIR . '/inc/core-button.php';
require_once NB_BASE_DIR . '/inc/cards.php';
require_once NB_BASE_DIR . '/inc/animations.php';
require_once NB_BASE_DIR . '/inc/hero.php';
require_once NB_BASE_DIR . '/inc/entries.php';
require_once NB_BASE_DIR . '/inc/entry-terms.php';
require_once NB_BASE_DIR . '/inc/faq.php';
require_once NB_BASE_DIR . '/inc/realisations.php';
require_once NB_BASE_DIR . '/inc/products.php';
require_once NB_BASE_DIR . '/inc/structured-data.php';
require_once NB_BASE_DIR . '/inc/google-rating.php';
require_once NB_BASE_DIR . '/inc/backgrounds.php';
require_once NB_BASE_DIR . '/inc/header.php';
require_once NB_BASE_DIR . '/inc/footer.php';
require_once NB_BASE_DIR . '/inc/languages.php';
require_once NB_BASE_DIR . '/inc/business.php';
require_once NB_BASE_DIR . '/inc/seo.php';
require_once NB_BASE_DIR . '/inc/llms.php';
require_once NB_BASE_DIR . '/inc/redirects.php';
require_once NB_BASE_DIR . '/inc/hardening.php';
require_once NB_BASE_DIR . '/inc/dashboard.php';
require_once NB_BASE_DIR . '/inc/admin-menu.php';
require_once NB_BASE_DIR . '/inc/forms.php';
require_once NB_BASE_DIR . '/inc/forms-antispam.php';
require_once NB_BASE_DIR . '/inc/forms-cf7.php';
require_once NB_BASE_DIR . '/inc/newsletter.php';
require_once NB_BASE_DIR . '/inc/cookies.php';
require_once NB_BASE_DIR . '/inc/cookies-complianz.php';
require_once NB_BASE_DIR . '/inc/editor-restrictions.php';
require_once NB_BASE_DIR . '/inc/global-styles.php';
require_once NB_BASE_DIR . '/inc/admin-page.php';
require_once NB_BASE_DIR . '/inc/site-fonts.php';
require_once NB_BASE_DIR . '/inc/updates.php';

add_action(
	'after_setup_theme',
	static function () {
		// Traductions (languages/fr_FR.mo / .l10n.php), générées par `npm run i18n`.
		load_theme_textdomain( 'nb-base', NB_BASE_DIR . '/languages' );
		add_theme_support( 'editor-styles' );
		remove_theme_support( 'core-block-patterns' );
	}
);
