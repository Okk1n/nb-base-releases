<?php
/**
 * Sélecteur de langue (fonctionnalité « languages », désactivée par défaut).
 *
 * Le thème ne fait que réserver un emplacement dans l'en-tête (après le
 * bouton, filtre `nb_base_header_extra`) : le sélecteur lui-même est celui de
 * l'extension de traduction (TranslatePress, WPML…), affiché par son
 * shortcode, réglé par le designer (NB Base → Langues). Aucune dépendance à
 * une extension : rien n'est affiché si le shortcode n'existe pas (extension
 * absente ou désactivée). Styles propres à l'extension : champ CSS de
 * l'onglet (option `nb_base_language_switcher_css`, chargé sur le site quand
 * la fonctionnalité est activée).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_LANGUAGES_OPTION     = 'nb_base_language_switcher';
const NB_BASE_LANGUAGES_CSS_OPTION = 'nb_base_language_switcher_css';
const NB_BASE_LANGUAGES_CSS_MAX    = 20000;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['languages'] = array(
			'group'       => 'other',
			'label'       => __( 'Language switcher', 'nb-base' ),
			'description' => __( 'Space in the header (after the button) for the language switcher of a translation plugin (TranslatePress, WPML…), set in NB Base → Languages.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * Shortcode du sélecteur enregistré (nettoyé), '' si aucun.
 */
function nb_base_language_switcher_shortcode(): string {
	return nb_base_sanitize_language_switcher( get_option( NB_BASE_LANGUAGES_OPTION, '' ) );
}

/**
 * Nettoyage : une ligne de texte, au plus 200 caractères, forcément un
 * shortcode (entre crochets).
 *
 * @param mixed $value Valeur saisie ou enregistrée.
 */
function nb_base_sanitize_language_switcher( $value ): string {
	$value = trim( sanitize_text_field( is_string( $value ) ? $value : '' ) );
	if ( strlen( $value ) > 200 || ! preg_match( '/^\[[^\[\]]+\]$/', $value ) ) {
		return '';
	}
	return $value;
}

/**
 * CSS du sélecteur enregistré (nettoyé), '' si aucun.
 */
function nb_base_language_switcher_css(): string {
	return nb_base_sanitize_language_css( get_option( NB_BASE_LANGUAGES_CSS_OPTION, '' ) );
}

/**
 * Nettoyage du CSS : texte brut, sans « < » (aucune balise possible, la
 * balise <style> ne peut pas être refermée), coupé à 20 000 caractères.
 *
 * @param mixed $value Valeur saisie ou enregistrée.
 */
function nb_base_sanitize_language_css( $value ): string {
	$value = is_string( $value ) ? $value : '';
	$value = str_replace( array( '<', "\0" ), '', $value );
	$value = trim( wp_check_invalid_utf8( $value ) );
	return mb_substr( $value, 0, NB_BASE_LANGUAGES_CSS_MAX );
}

/*
 * CSS chargé sur le site (fonctionnalité activée, CSS non vide), après les
 * styles du thème.
 */
add_action(
	'wp_enqueue_scripts',
	static function () {
		$css = nb_base_feature_enabled( 'languages' ) ? nb_base_language_switcher_css() : '';
		if ( '' === $css ) {
			return;
		}
		wp_register_style( 'nb-base-languages', false, array(), NB_BASE_VERSION );
		wp_enqueue_style( 'nb-base-languages' );
		wp_add_inline_style( 'nb-base-languages', $css );
	},
	20
);

/**
 * HTML du sélecteur ('' si fonctionnalité coupée, aucun shortcode, ou
 * shortcode inconnu ou vide).
 */
function nb_base_language_switcher_html(): string {
	if ( ! nb_base_feature_enabled( 'languages' ) ) {
		return '';
	}
	$shortcode = nb_base_language_switcher_shortcode();
	if ( '' === $shortcode || ! preg_match( '/^\[([\w-]+)/', $shortcode, $m ) || ! shortcode_exists( $m[1] ) ) {
		return '';
	}
	$html = trim( do_shortcode( $shortcode ) );
	if ( '' === $html ) {
		return '';
	}
	return '<div class="nb-header__languages">' . $html . '</div>';
}

add_filter(
	'nb_base_header_extra',
	static fn( $html ) => (string) $html . nb_base_language_switcher_html()
);

/**
 * Page NB Base : onglet « Langues » (fonctionnalité activée).
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		if ( nb_base_feature_enabled( 'languages' ) ) {
			$tabs['languages'] = array(
				'label'  => __( 'Languages', 'nb-base' ),
				'render' => 'nb_base_languages_admin_tab',
			);
		}
		return $tabs;
	}
);

/**
 * Contenu de l'onglet.
 */
function nb_base_languages_admin_tab(): void {
	$shortcode = nb_base_language_switcher_shortcode();
	$css       = nb_base_language_switcher_css();
	$known     = '' !== $shortcode && preg_match( '/^\[([\w-]+)/', $shortcode, $m ) && shortcode_exists( $m[1] );
	?>
	<?php if ( '' !== $shortcode && ! $known ) : ?>
		<div class="notice notice-warning inline"><p><?php esc_html_e( 'This shortcode does not exist on the site (translation plugin missing or inactive): nothing is displayed in the header.', 'nb-base' ); ?></p></div>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_languages">
		<?php wp_nonce_field( 'nb_base_save_languages' ); ?>
		<table class="form-table" role="presentation"><tbody>
			<tr>
				<th scope="row"><label for="nb-language-switcher"><?php esc_html_e( 'Switcher shortcode', 'nb-base' ); ?></label></th>
				<td>
					<input id="nb-language-switcher" class="regular-text code" type="text" name="languages[shortcode]" value="<?php echo esc_attr( $shortcode ); ?>" placeholder="[language-switcher]">
					<p class="description"><?php esc_html_e( 'Shortcode provided by the translation plugin, displayed in the header after the button (on tablet and mobile: left of the menu button). Examples: TranslatePress [language-switcher], WPML [wpml_language_selector_widget]. Empty = nothing displayed.', 'nb-base' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nb-language-switcher-css"><?php esc_html_e( 'Switcher CSS', 'nb-base' ); ?></label></th>
				<td>
					<textarea id="nb-language-switcher-css" class="large-text code" rows="14" name="languages[css]" spellcheck="false"><?php echo esc_textarea( $css ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Styles for the plugin’s switcher (its markup differs for each plugin), loaded on the site when the feature is enabled. The slot is .nb-header__languages; use the theme variables (var(--wp--preset--color--accent)…) so that the switcher follows the site’s styles.', 'nb-base' ); ?></p>
				</td>
			</tr>
		</tbody></table>
		<?php submit_button( __( 'Save language settings', 'nb-base' ) ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_languages',
	static function () {
		nb_base_admin_guard( 'nb_base_save_languages' );
		$input = isset( $_POST['languages'] ) && is_array( $_POST['languages'] ) ? wp_unslash( $_POST['languages'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		update_option( NB_BASE_LANGUAGES_OPTION, nb_base_sanitize_language_switcher( $input['shortcode'] ?? '' ), false );
		update_option( NB_BASE_LANGUAGES_CSS_OPTION, nb_base_sanitize_language_css( $input['css'] ?? '' ), false );
		nb_base_admin_redirect( 'languages-saved', 'languages' );
	}
);
