<?php
/**
 * Fonds de section préenregistrés, propres à chaque client.
 *
 * Liste : settings.custom.backgrounds des styles du site (theme.json pour les
 * valeurs par défaut, styles.json du client pour le reste), par identifiant :
 *
 *   "backgrounds": {
 *     "dark-texture": {
 *       "label": "Fond sombre texturé",          // Nom affiché (facultatif).
 *       "color": "var(--wp--preset--color--contrast-strong)",
 *       "image": "/wp-content/uploads/2026/11/texture.png",  // Facultatif.
 *       "size": "auto", "repeat": "repeat", "position": "center",
 *       "tone": "dark",                          // « light » ou « dark ».
 *       "hidden": true                           // Masquer un fond par défaut.
 *     }
 *   }
 *
 * Le bloc enregistre seulement l'identifiant (attribut « background ») :
 * l'apparence suit les styles du site. Un fond retiré ou masqué n'est plus
 * proposé et n'est plus affiché, sans casser la page.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Fonds disponibles sur le site.
 *
 * @return array<string, array{slug: string, label: string, tone: string, css: string}>
 */
function nb_base_backgrounds(): array {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$defaults = array(
		'alt'  => __( 'Alternate', 'nb-base' ),
		'dark' => __( 'Dark', 'nb-base' ),
	);
	$cache = array();
	foreach ( (array) wp_get_global_settings( array( 'custom', 'backgrounds' ) ) as $slug => $bg ) {
		$slug = (string) $slug;
		if ( ! is_array( $bg ) || ! empty( $bg['hidden'] ) || ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) {
			continue;
		}
		$decl = array();
		if ( ! empty( $bg['color'] ) ) {
			$decl[] = 'background-color:' . $bg['color'];
			// Couleur du fond lisible par les éléments qui doivent la reprendre
			// (ex. sous-menus de l'en-tête).
			$decl[] = '--nb-bg-color:' . $bg['color'];
		}
		if ( ! empty( $bg['image'] ) ) {
			$decl[] = 'background-image:url(' . esc_url_raw( (string) $bg['image'] ) . ')';
			$decl[] = 'background-size:' . ( $bg['size'] ?? 'auto' );
			$decl[] = 'background-repeat:' . ( $bg['repeat'] ?? 'repeat' );
			$decl[] = 'background-position:' . ( $bg['position'] ?? 'center' );
		}
		$cache[ $slug ] = array(
			'slug'  => $slug,
			'label' => (string) ( $bg['label'] ?? $defaults[ $slug ] ?? $slug ),
			'tone'  => 'dark' === ( $bg['tone'] ?? '' ) ? 'dark' : 'light',
			'css'   => safecss_filter_attr( implode( ';', array_map( 'strval', $decl ) ) ),
		);
	}
	return $cache;
}

/**
 * Classes CSS du fond choisi (vide si aucun ou inconnu).
 */
function nb_base_background_classes( string $slug ): string {
	$bg = nb_base_backgrounds()[ $slug ] ?? null;
	return $bg ? 'nb-bg-' . $bg['slug'] . ' nb-tone-' . $bg['tone'] : '';
}

/**
 * CSS des fonds (site et éditeur).
 */
add_action(
	'enqueue_block_assets',
	static function () {
		$css = '';
		foreach ( nb_base_backgrounds() as $bg ) {
			if ( '' !== $bg['css'] ) {
				$css .= '.nb-bg-' . $bg['slug'] . '{' . $bg['css'] . '}';
			}
		}
		wp_enqueue_style( 'nb-base-backgrounds', NB_BASE_URI . '/assets/css/backgrounds.css', array(), NB_BASE_VERSION );
		wp_add_inline_style( 'nb-base-backgrounds', $css );
	}
);

/**
 * Liste des fonds pour le réglage « Fond » de l'éditeur.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$list = array_map(
			static fn( $bg ) => array(
				'slug'  => $bg['slug'],
				'label' => $bg['label'],
				'tone'  => $bg['tone'],
			),
			array_values( nb_base_backgrounds() )
		);
		wp_add_inline_script( 'nb-base-editor', 'window.nbBaseBackgrounds = ' . wp_json_encode( $list ) . ';', 'before' );
	}
);

/* -------------------------------------------------------------------------
 * Fonds alternés automatiquement (contenus structurés : réalisations,
 * produits).
 *
 * Deux sections qui se suivent n'ont jamais le même fond : les sections
 * affichées (après le hero) prennent tour à tour aucun fond, puis « alt »,
 * etc. Une section masquée (vide : FAQ sans question, galerie sans photo…)
 * ne compte pas, la suivante prend sa place dans l'alternance. Le réglage
 * « Fond » des sections est alors ignoré (et masqué dans l'éditeur).
 * Les sections du template autour du contenu (formulaire de contact) suivent
 * la même alternance.
 *
 * Sections jointes : certaines sections prolongent la précédente et prennent
 * son fond sans avancer l'alternance (réalisation : l'introduction et le
 * contenu forment une seule section ; l'alternance commence à la galerie).
 * Si la section prolongée est masquée, la section jointe compte normalement.
 *
 * Sections = blocs nb-base/* ayant l'attribut « background ». Le choix est
 * fait avant le rendu de chaque section (render_block_data) ; le compteur
 * n'avance que si la section a produit du HTML (render_block).
 * ---------------------------------------------------------------------- */

/**
 * Types de contenu aux fonds alternés automatiquement.
 *
 * @return string[]
 */
function nb_base_auto_background_post_types(): array {
	$types = array();
	if ( defined( 'NB_BASE_REALISATION_TYPE' ) ) {
		$types[] = NB_BASE_REALISATION_TYPE;
	}
	if ( defined( 'NB_BASE_PRODUCT_TYPE' ) ) {
		$types[] = NB_BASE_PRODUCT_TYPE;
	}
	return (array) apply_filters( 'nb_base_auto_background_post_types', $types );
}

/**
 * Fonds de l'alternance, dans l'ordre ('' = aucun fond).
 *
 * @return string[]
 */
function nb_base_auto_backgrounds(): array {
	$list = array_values( array_map( 'strval', (array) apply_filters( 'nb_base_auto_backgrounds', array( '', 'alt' ) ) ) );
	return $list ? $list : array( '' );
}

/**
 * Sections jointes : bloc => bloc qu'il prolonge (même fond, l'alternance
 * n'avance pas si ce bloc est affiché juste avant).
 *
 * @return array<string, string>
 */
function nb_base_auto_background_joined(): array {
	return (array) apply_filters( 'nb_base_auto_background_joined', array( 'nb-base/entry-details' => 'nb-base/entry-intro' ) );
}

/**
 * Le bloc est-il une section à fond (attribut « background ») ?
 */
function nb_base_is_background_section( string $name ): bool {
	if ( ! str_starts_with( $name, 'nb-base/' ) ) {
		return false;
	}
	$type = WP_Block_Type_Registry::get_instance()->get_registered( $name );
	return $type && isset( $type->attributes['background'] );
}

/**
 * Page affichée concernée par l'alternance automatique ?
 */
function nb_base_auto_background_active(): bool {
	return ! is_admin() && ! wp_is_serving_rest_request() && is_singular( nb_base_auto_background_post_types() );
}

/**
 * État de l'alternance dans la page : nombre de sections comptées et
 * dernière section affichée. Avec $displayed (nom du bloc) : section
 * affichée, comptée sauf si elle prolonge la précédente.
 *
 * @return array{count: int, last: string}
 */
function nb_base_auto_background_state( string $displayed = '' ): array {
	static $state = array(
		'count' => 0,
		'last'  => '',
	);
	if ( '' !== $displayed ) {
		if ( ! nb_base_auto_background_continues( $displayed, $state['last'] ) ) {
			++$state['count'];
		}
		$state['last'] = $displayed;
	}
	return $state;
}

/**
 * La section $name prolonge-t-elle la section affichée juste avant ($last) ?
 */
function nb_base_auto_background_continues( string $name, string $last ): bool {
	$joined = nb_base_auto_background_joined();
	return '' !== $last && isset( $joined[ $name ] ) && $joined[ $name ] === $last;
}

add_filter(
	'render_block_data',
	static function ( array $parsed_block ): array {
		$name = (string) ( $parsed_block['blockName'] ?? '' );
		if ( ! nb_base_is_background_section( $name ) || ! nb_base_auto_background_active() ) {
			return $parsed_block;
		}
		$list  = nb_base_auto_backgrounds();
		$state = nb_base_auto_background_state();
		// Section qui prolonge la précédente : même fond (rang précédent).
		$index = nb_base_auto_background_continues( $name, $state['last'] ) ? $state['count'] - 1 : $state['count'];

		$parsed_block['attrs']['background'] = $list[ max( 0, $index ) % count( $list ) ];
		return $parsed_block;
	}
);

add_filter(
	'render_block',
	static function ( string $html, array $block ): string {
		$name = (string) ( $block['blockName'] ?? '' );
		if ( '' !== trim( $html ) && nb_base_is_background_section( $name ) && nb_base_auto_background_active() ) {
			nb_base_auto_background_state( $name );
		}
		return $html;
	},
	10,
	2
);

/**
 * Éditeur d'un contenu à fonds automatiques : alternance reproduite dans
 * l'aperçu (src/editor/auto-backgrounds.js), réglage « Fond » masqué.
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->post_type, nb_base_auto_background_post_types(), true ) ) {
			return;
		}
		wp_add_inline_script(
			'nb-base-editor',
			'window.nbBaseAutoBackgrounds = ' . wp_json_encode(
				array(
					'list'   => nb_base_auto_backgrounds(),
					'joined' => (object) nb_base_auto_background_joined(),
				)
			) . ';',
			'before'
		);
	}
);
