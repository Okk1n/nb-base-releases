<?php
/**
 * Images en WebP (fonctionnalité « webp-images », activée par défaut, à la
 * demande de l'utilisateur) : les tailles que WordPress génère à l'envoi
 * d'une image JPG ou PNG (vignettes, medium, large, version « -scaled »)
 * sont enregistrées en WebP. L'original envoyé reste dans son format.
 *
 * API native : filtre image_editor_output_format (WordPress 6.1). Ne
 * s'applique qu'aux nouveaux envois (images existantes : régénérer les
 * tailles, ex. `wp media regenerate`). Serveur incapable d'écrire du WebP :
 * rien n'est converti. Qualité : valeur par défaut de WordPress.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['webp-images'] = array(
			'label'       => __( 'WebP images', 'nb-base' ),
			'description' => __( 'Images sent to the media library (JPG, PNG) are displayed on the site in WebP, a lighter format. Applies to new uploads; the original file is kept.', 'nb-base' ),
			'default'     => true,
		);
		return $features;
	}
);

/**
 * Le serveur sait-il écrire du WebP ? (GD ou Imagick compilé avec WebP.)
 */
function nb_base_webp_supported(): bool {
	static $supported = null;
	if ( null === $supported ) {
		$supported = wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
	}
	return $supported;
}

add_filter(
	'image_editor_output_format',
	static function ( $formats ) {
		if ( ! is_array( $formats ) || ! nb_base_feature_enabled( 'webp-images' ) || ! nb_base_webp_supported() ) {
			return $formats;
		}
		$formats['image/jpeg'] = 'image/webp';
		$formats['image/png']  = 'image/webp';
		return $formats;
	}
);
