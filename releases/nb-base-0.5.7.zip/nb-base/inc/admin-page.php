<?php
/**
 * Page d'administration « NB Base », visible uniquement par le designer.
 *
 * Onglets : Fonctionnalités (activation / désactivation par site), onglets des
 * modules (filtre `nb_base_admin_tabs`), Styles (export et import du fichier
 * JSON de styles du client).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_ADMIN_SLUG = 'nb-base';

add_action(
	'admin_menu',
	static function () {
		add_menu_page(
			__( 'NB Base', 'nb-base' ),
			__( 'NB Base', 'nb-base' ),
			NB_BASE_DESIGN_CAP,
			NB_BASE_ADMIN_SLUG,
			'nb_base_render_admin_page',
			'dashicons-admin-customizer',
			59
		);
	}
);

/**
 * Onglets de la page : Fonctionnalités, onglets des modules (filtre
 * `nb_base_admin_tabs`), Styles. Chaque onglet : `label`, `render` (appelable).
 *
 * @return array<string, array{label: string, render: callable}>
 */
function nb_base_admin_tabs(): array {
	$tabs = array(
		'features' => array(
			'label'  => __( 'Features', 'nb-base' ),
			'render' => 'nb_base_features_admin_tab',
		),
	);
	$tabs = (array) apply_filters( 'nb_base_admin_tabs', $tabs );

	$tabs['styles'] = array(
		'label'  => __( 'Styles', 'nb-base' ),
		'render' => 'nb_base_styles_admin_tab',
	);
	return array_filter( $tabs, static fn( $tab ) => is_array( $tab ) && isset( $tab['label'], $tab['render'] ) && is_callable( $tab['render'] ) );
}

/**
 * Adresse d'un onglet de la page.
 */
function nb_base_admin_tab_url( string $tab ): string {
	return add_query_arg( array( 'page' => NB_BASE_ADMIN_SLUG, 'tab' => $tab ), admin_url( 'admin.php' ) );
}

/**
 * Affichage de la page.
 */
function nb_base_render_admin_page(): void {
	if ( ! nb_base_is_designer() ) {
		wp_die( esc_html__( 'Restricted access.', 'nb-base' ) );
	}

	$tabs    = nb_base_admin_tabs();
	$current = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $tabs[ $current ] ) ) {
		$current = (string) array_key_first( $tabs );
	}

	$notice   = isset( $_GET['nb-notice'] ) ? sanitize_key( wp_unslash( $_GET['nb-notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$messages = array(
		'features-saved' => array( 'success', __( 'Features saved.', 'nb-base' ) ),
		'styles-saved'   => array( 'success', __( 'Styles imported.', 'nb-base' ) ),
		'styles-error'   => array( 'error', __( 'Import failed: the file is not a valid styles JSON.', 'nb-base' ) ),
		'realisations-saved' => array( 'success', __( 'Projects settings saved.', 'nb-base' ) ),
		'products-saved'     => array( 'success', __( 'Products settings saved.', 'nb-base' ) ),
		'forms-saved'        => array( 'success', __( 'Forms settings saved.', 'nb-base' ) ),
		'newsletter-saved'   => array( 'success', __( 'Newsletter settings saved.', 'nb-base' ) ),
		'seo-saved'          => array( 'success', __( 'Search engine settings saved.', 'nb-base' ) ),
		'languages-saved'    => array( 'success', __( 'Language settings saved.', 'nb-base' ) ),
		'license-saved'      => array( 'success', __( 'License saved.', 'nb-base' ) ),
		'newsletter-form-created' => array( 'success', __( 'Newsletter form created and selected.', 'nb-base' ) ),
		'newsletter-form-error'   => array( 'error', __( 'The newsletter form could not be created.', 'nb-base' ) ),
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'NB Base', 'nb-base' ); ?> <small>v<?php echo esc_html( NB_BASE_VERSION ); ?></small></h1>

		<?php if ( isset( $messages[ $notice ] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ][1] ); ?></p></div>
		<?php endif; ?>

		<nav class="nav-tab-wrapper wp-clearfix" aria-label="<?php esc_attr_e( 'NB Base sections', 'nb-base' ); ?>">
			<?php foreach ( $tabs as $slug => $tab ) : ?>
				<a href="<?php echo esc_url( nb_base_admin_tab_url( $slug ) ); ?>" class="nav-tab<?php echo $slug === $current ? ' nav-tab-active' : ''; ?>"<?php echo $slug === $current ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $tab['label'] ); ?></a>
			<?php endforeach; ?>
		</nav>

		<h2 class="screen-reader-text"><?php echo esc_html( $tabs[ $current ]['label'] ); ?></h2>
		<?php call_user_func( $tabs[ $current ]['render'] ); ?>
	</div>
	<?php
}

/**
 * Onglet « Fonctionnalités ».
 */
function nb_base_features_admin_tab(): void {
	$features = nb_base_features();
	if ( empty( $features ) ) {
		echo '<p>' . esc_html__( 'No toggleable feature yet.', 'nb-base' ) . '</p>';
		return;
	}
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_features">
		<?php wp_nonce_field( 'nb_base_save_features' ); ?>
		<?php
		// Regroupées par thème, dans l'ordre des thèmes puis de déclaration.
		$groups = nb_base_feature_groups();
		$sorted = array_fill_keys( array_keys( $groups ), array() );
		foreach ( $features as $slug => $feature ) {
			$sorted[ isset( $groups[ $feature['group'] ] ) ? $feature['group'] : 'other' ][ $slug ] = $feature;
		}
		?>
		<?php // Boîtes natives de l'administration (postbox), une par thème, dans leur conteneur standard (#poststuff : marges des titres). ?>
		<div id="poststuff">
		<?php foreach ( array_filter( $sorted ) as $group => $items ) : ?>
			<div class="postbox nb-base-feature-group" id="<?php echo esc_attr( 'nb-features-' . $group ); ?>">
				<div class="postbox-header">
					<h2 class="hndle"><?php echo esc_html( $groups[ $group ] ); ?></h2>
				</div>
				<div class="inside">
					<table class="form-table" role="presentation"><tbody>
					<?php foreach ( $items as $slug => $feature ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $feature['label'] ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="features[<?php echo esc_attr( $slug ); ?>]" value="1" <?php checked( nb_base_feature_enabled( $slug ) ); ?>>
									<?php esc_html_e( 'Enabled', 'nb-base' ); ?>
								</label>
								<?php if ( $feature['description'] ) : ?>
									<p class="description"><?php echo esc_html( $feature['description'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody></table>
				</div>
			</div>
		<?php endforeach; ?>
		</div>
		<?php submit_button( __( 'Save features', 'nb-base' ) ); ?>
	</form>
	<?php
}

/**
 * Onglet « Styles » : export et import du fichier JSON de styles du client.
 */
function nb_base_styles_admin_tab(): void {
	?>
	<p><?php esc_html_e( 'Styles (colors, typography, spacing) are stored in the database and are not affected by theme updates. Quick adjustments: Appearance → Editor → Styles.', 'nb-base' ); ?></p>

	<h3><?php esc_html_e( 'Export', 'nb-base' ); ?></h3>
	<p>
		<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nb_base_export_styles' ), 'nb_base_export_styles' ) ); ?>">
			<?php esc_html_e( 'Download the styles file (JSON)', 'nb-base' ); ?>
		</a>
	</p>

	<h3><?php esc_html_e( 'Import', 'nb-base' ); ?></h3>
	<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_import_styles">
		<?php wp_nonce_field( 'nb_base_import_styles' ); ?>
		<p><input type="file" name="styles_file" accept=".json,application/json" required></p>
		<p class="description"><?php esc_html_e( 'Replaces the current site styles. Export first to keep a backup.', 'nb-base' ); ?></p>
		<?php submit_button( __( 'Import styles', 'nb-base' ), 'secondary' ); ?>
	</form>
	<?php
}

/**
 * Redirection vers un onglet de la page avec un message.
 */
function nb_base_admin_redirect( string $notice, string $tab = 'features' ): void {
	wp_safe_redirect( add_query_arg( 'nb-notice', $notice, nb_base_admin_tab_url( $tab ) ) );
	exit;
}

/**
 * Vérifie droits + nonce pour une action. Sans licence valable pour le
 * domaine (inc/license.php), seule la licence peut être enregistrée.
 */
function nb_base_admin_guard( string $action ): void {
	if ( ! nb_base_is_designer() ) {
		wp_die( esc_html__( 'Restricted access.', 'nb-base' ), 403 );
	}
	check_admin_referer( $action );
	if ( 'nb_base_save_license' !== $action && ! nb_base_license_active() ) {
		wp_die( esc_html__( 'No valid license for this domain: NB Base settings cannot be saved.', 'nb-base' ), 403 );
	}
}

add_action(
	'admin_post_nb_base_save_features',
	static function () {
		nb_base_admin_guard( 'nb_base_save_features' );
		$states = isset( $_POST['features'] ) && is_array( $_POST['features'] ) ? wp_unslash( $_POST['features'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		nb_base_save_feature_states( array_map( 'boolval', $states ) );
		nb_base_admin_redirect( 'features-saved' );
	}
);

add_action(
	'admin_post_nb_base_export_styles',
	static function () {
		nb_base_admin_guard( 'nb_base_export_styles' );
		$data = nb_base_export_styles();
		if ( is_wp_error( $data ) ) {
			wp_die( esc_html( $data->get_error_message() ) );
		}
		$filename = sanitize_file_name( wp_parse_url( home_url(), PHP_URL_HOST ) . '-styles-' . gmdate( 'Y-m-d' ) . '.json' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}
);

add_action(
	'admin_post_nb_base_import_styles',
	static function () {
		nb_base_admin_guard( 'nb_base_import_styles' );
		$tmp  = $_FILES['styles_file']['tmp_name'] ?? ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$data = ( $tmp && is_uploaded_file( $tmp ) ) ? json_decode( (string) file_get_contents( $tmp ), true ) : null;
		if ( ! is_array( $data ) || is_wp_error( nb_base_import_styles( $data ) ) ) {
			nb_base_admin_redirect( 'styles-error', 'styles' );
		}
		nb_base_admin_redirect( 'styles-saved', 'styles' );
	}
);
