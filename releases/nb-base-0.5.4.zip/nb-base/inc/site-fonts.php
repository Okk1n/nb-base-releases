<?php
/**
 * Polices du site : chaque site a les siennes, installées par le designer dans
 * la bibliothèque de polices native (Apparence → Polices), jamais dans le thème.
 *
 * Le thème définit deux variables, « title » et « text »
 * (--wp--preset--font-family--title / --text, Inter par défaut), utilisées par
 * tous ses blocs. NB Base → Styles → Polices les relie à une police installée :
 * les styles du site (couche « custom » des styles globaux) redéfinissent ces
 * deux variables, qui l'emportent alors sur celles du thème. La police choisie
 * est aussi activée (même entrée que celle qu'écrit la bibliothèque de polices),
 * pour que WordPress imprime ses @font-face.
 *
 * Uniquement l'API REST publique (font-families, global-styles).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Variables de police du thème : slug => libellé.
 *
 * @return array<string, string>
 */
function nb_base_font_roles(): array {
	return array(
		'title' => __( 'Title font', 'nb-base' ),
		'text'  => __( 'Text font', 'nb-base' ),
	);
}

/**
 * Polices installées dans la bibliothèque, par identifiant.
 *
 * @return array<int, array{name: string, slug: string, fontFamily: string, fontFace: array}>
 */
function nb_base_installed_fonts(): array {
	$request = new WP_REST_Request( 'GET', '/wp/v2/font-families' );
	$request->set_param( 'per_page', 100 );
	$response = rest_do_request( $request );
	if ( $response->is_error() ) {
		return array();
	}
	$fonts = array();
	foreach ( (array) $response->get_data() as $family ) {
		$settings = (array) ( $family['font_family_settings'] ?? array() );
		$id       = (int) ( $family['id'] ?? 0 );
		$slug     = sanitize_title( (string) ( $settings['slug'] ?? '' ) );
		if ( ! $id || '' === $slug || isset( nb_base_font_roles()[ $slug ] ) || empty( $settings['fontFamily'] ) ) {
			continue;
		}
		$faces    = array();
		$response = rest_do_request( new WP_REST_Request( 'GET', '/wp/v2/font-families/' . $id . '/font-faces' ) );
		if ( ! $response->is_error() ) {
			foreach ( (array) $response->get_data() as $face ) {
				if ( ! empty( $face['font_face_settings'] ) ) {
					$faces[] = (array) $face['font_face_settings'];
				}
			}
		}
		$fonts[ $id ] = array(
			'name'       => (string) ( $settings['name'] ?? $slug ),
			'slug'       => $slug,
			'fontFamily' => (string) $settings['fontFamily'],
			'fontFace'   => $faces,
		);
	}
	uasort( $fonts, static fn( $a, $b ) => strcasecmp( $a['name'], $b['name'] ) );
	return $fonts;
}

/**
 * Styles du site en tableaux (l'export renvoie des objets vides).
 *
 * @return array|WP_Error
 */
function nb_base_site_styles() {
	$styles = nb_base_export_styles();
	return is_wp_error( $styles ) ? $styles : (array) json_decode( (string) wp_json_encode( $styles ), true );
}

/**
 * Polices personnalisées des styles du site (liste « custom »).
 */
function nb_base_custom_font_families( array $styles ): array {
	$custom = $styles['settings']['typography']['fontFamilies']['custom'] ?? array();
	return is_array( $custom ) ? array_values( $custom ) : array();
}

/**
 * Police actuellement reliée à chaque variable : slug => identifiant de la
 * police installée (0 = police du thème).
 *
 * @return array<string, int>
 */
function nb_base_current_site_fonts( ?array $fonts = null ): array {
	$fonts   = $fonts ?? nb_base_installed_fonts();
	$current = array_fill_keys( array_keys( nb_base_font_roles() ), 0 );
	$styles  = nb_base_site_styles();
	if ( is_wp_error( $styles ) ) {
		return $current;
	}
	foreach ( nb_base_custom_font_families( $styles ) as $entry ) {
		$slug = (string) ( $entry['slug'] ?? '' );
		if ( ! isset( $current[ $slug ] ) ) {
			continue;
		}
		foreach ( $fonts as $id => $font ) {
			if ( ( $entry['fontFamily'] ?? '' ) === $font['fontFamily'] ) {
				$current[ $slug ] = $id;
			}
		}
	}
	return $current;
}

/**
 * Relie les variables du thème aux polices choisies (0 = police du thème).
 *
 * @param array<string, int> $choice slug de variable => identifiant de police installée.
 * @return true|WP_Error
 */
function nb_base_save_site_fonts( array $choice ) {
	$styles = nb_base_site_styles();
	if ( is_wp_error( $styles ) ) {
		return $styles;
	}
	$fonts  = nb_base_installed_fonts();
	$roles  = nb_base_font_roles();
	$custom = array_values(
		array_filter(
			nb_base_custom_font_families( $styles ),
			static fn( $entry ) => ! isset( $roles[ (string) ( $entry['slug'] ?? '' ) ] )
		)
	);

	foreach ( array_keys( $roles ) as $role ) {
		$id = (int) ( $choice[ $role ] ?? 0 );
		if ( ! $id ) {
			continue;
		}
		if ( ! isset( $fonts[ $id ] ) ) {
			return new WP_Error( 'nb_base_font_unknown', __( 'This font is not installed.', 'nb-base' ) );
		}
		$font = $fonts[ $id ];
		// Activation (comme la bibliothèque de polices) : imprime ses @font-face.
		if ( ! in_array( $font['slug'], array_column( $custom, 'slug' ), true ) ) {
			$custom[] = array_filter(
				array(
					'name'       => $font['name'],
					'slug'       => $font['slug'],
					'fontFamily' => $font['fontFamily'],
					'fontFace'   => $font['fontFace'],
				)
			);
		}
		// Variable du thème redéfinie (même nom que dans theme.json).
		$custom[] = array(
			'name'       => 'font-' . $role,
			'slug'       => $role,
			'fontFamily' => $font['fontFamily'],
		);
	}

	$settings = (array) ( $styles['settings'] ?? array() );
	if ( $custom ) {
		$settings['typography']['fontFamilies']['custom'] = $custom;
	} else {
		unset( $settings['typography']['fontFamilies']['custom'] );
		if ( empty( $settings['typography']['fontFamilies'] ) ) {
			unset( $settings['typography']['fontFamilies'] );
		}
		if ( empty( $settings['typography'] ) ) {
			unset( $settings['typography'] );
		}
	}
	$styles['settings'] = $settings;

	return nb_base_import_styles( $styles );
}

/**
 * Section « Polices » de l'onglet Styles.
 */
function nb_base_site_fonts_section(): void {
	$fonts   = nb_base_installed_fonts();
	$current = nb_base_current_site_fonts( $fonts );
	?>
	<h3><?php esc_html_e( 'Fonts', 'nb-base' ); ?></h3>
	<p>
		<?php
		printf(
			/* translators: %s: link to Appearance → Fonts. */
			esc_html__( 'Each site has its own fonts: install them in %s (upload the files, or Google Fonts: the files are copied to this server), then choose them here. All the theme blocks follow.', 'nb-base' ),
			'<a href="' . esc_url( admin_url( 'font-library.php' ) ) . '">' . esc_html__( 'Appearance → Fonts', 'nb-base' ) . '</a>'
		);
		?>
	</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_fonts">
		<?php wp_nonce_field( 'nb_base_save_fonts' ); ?>
		<table class="form-table" role="presentation">
			<?php foreach ( nb_base_font_roles() as $role => $label ) : ?>
				<tr>
					<th scope="row"><label for="nb-font-<?php echo esc_attr( $role ); ?>"><?php echo esc_html( $label ); ?></label></th>
					<td>
						<select id="nb-font-<?php echo esc_attr( $role ); ?>" name="nb_fonts[<?php echo esc_attr( $role ); ?>]">
							<option value="0"><?php esc_html_e( 'Theme font (Inter)', 'nb-base' ); ?></option>
							<?php foreach ( $fonts as $id => $font ) : ?>
								<option value="<?php echo esc_attr( (string) $id ); ?>" <?php selected( $current[ $role ], $id ); ?>><?php echo esc_html( $font['name'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php if ( ! $fonts ) : ?>
			<p class="description"><?php esc_html_e( 'No font installed yet.', 'nb-base' ); ?></p>
		<?php endif; ?>
		<?php submit_button( __( 'Save fonts', 'nb-base' ), 'primary', 'submit', false ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_fonts',
	static function () {
		nb_base_admin_guard( 'nb_base_save_fonts' );
		$posted = isset( $_POST['nb_fonts'] ) && is_array( $_POST['nb_fonts'] ) ? wp_unslash( $_POST['nb_fonts'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$choice = array();
		foreach ( array_keys( nb_base_font_roles() ) as $role ) {
			$choice[ $role ] = absint( $posted[ $role ] ?? 0 );
		}
		nb_base_admin_redirect( is_wp_error( nb_base_save_site_fonts( $choice ) ) ? 'fonts-error' : 'fonts-saved', 'styles' );
	}
);
