<?php return array(
	'dependencies' => array(
		
	),
	'version' => '2636871d6eeedc428587'
);
