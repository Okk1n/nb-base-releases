<?php
/**
 * Formulaires : adaptateur Contact Form 7.
 *
 * Seul fichier du thème qui connaît Contact Form 7 (voir inc/forms.php).
 * Uniquement des points d'accroche publics de l'extension :
 *  - filtre « wpcf7_form_tag » : impose les types de fichiers et la taille
 *    maximale du thème à tous les champs fichier (affichage et validation) ;
 *  - wpcf7_remove_form_tag() / wpcf7_add_form_tag() : le champ fichier
 *    reprend le rendu de l'extension et y ajoute la légende (formats, taille),
 *    reliée au champ (aria-describedby) ;
 *  - filtre « wpcf7_file_extension_safelist » : les extensions acceptées
 *    gardent leur nom (sinon « devis.docx » devient « devis.docx_.txt ») ;
 *  - filtres « wpcf7_validate_file » / « wpcf7_validate_file* » : contrôle du
 *    contenu réel des fichiers (l'extension ne contrôle que leur nom) ;
 *  - filtres « nb_base_form_choices » / « nb_base_form_html » (thème) :
 *    liste des formulaires et rendu par le code court de l'extension ;
 *  - filtre « wpcf7_form_tag_data_option » : option « data:nb_request_types »
 *    d'une liste déroulante = choix « Type de demande » du site ;
 *  - filtre « wpcf7_autop_or_not » : pas de paragraphes ajoutés (balisage
 *    du thème, voir nb_base_cf7_default_form()) ;
 *  - filtre « wpcf7_default_template » : formulaire de départ d'un nouveau
 *    formulaire = formulaire type du thème ;
 *  - droits (« wpcf7_map_meta_cap », « map_meta_cap », action
 *    « wpcf7_admin_load ») : seul le designer crée, duplique ou supprime un
 *    formulaire et accède à l'écran Intégration ; le menu Contact (voir et
 *    modifier les formulaires existants) n'est ouvert aux autres
 *    administrateurs que par l'accès « client_forms » (inc/admin-menu.php) ;
 *  - filtres « wpcf7_form_hidden_fields », « wpcf7_form_elements » et
 *    « wpcf7_spam » : anti-spam du thème (inc/forms-antispam.php) ;
 *  - action « wpcf7_submit » : l'envoi (validé, anti-spam passé, fichiers
 *    encore présents) est traduit en envoi normalisé. Envois enregistrés :
 *    e-mail parti ou e-mail en échec (aucun message perdu) ; pas les spams.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'WPCF7_VERSION' ) ) {
	return;
}

/**
 * Extension indispensable : seul le designer peut la désactiver (droit
 * natif « deactivate_plugin », vérifié par WordPress pour le lien de la liste
 * des extensions, l'action groupée et l'API REST). Les mises à jour restent
 * possibles.
 */
add_filter(
	'map_meta_cap',
	static function ( array $caps, string $cap, int $user_id, array $args ): array {
		if (
			'deactivate_plugin' === $cap &&
			WPCF7_PLUGIN_BASENAME === ( $args[0] ?? '' ) &&
			nb_base_feature_enabled( 'forms' ) &&
			! nb_base_is_designer( $user_id )
		) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	10,
	4
);

/**
 * Mises à jour automatiques imposées (correctifs de sécurité de la partie
 * exposée des formulaires). Filtre natif « auto_update_plugin » : la liste des
 * extensions affiche l'état sans bouton pour le couper. WordPress annule
 * seul une mise à jour automatique qui provoque une erreur fatale.
 */
add_filter(
	'auto_update_plugin',
	static function ( $update, $item ) {
		if ( is_object( $item ) && WPCF7_PLUGIN_BASENAME === ( $item->plugin ?? '' ) && nb_base_feature_enabled( 'forms' ) ) {
			return true;
		}
		return $update;
	},
	10,
	2
);

// Explication à la place du lien « Désactiver ».
add_filter(
	'plugin_action_links_' . WPCF7_PLUGIN_BASENAME,
	static function ( array $links ): array {
		if ( nb_base_feature_enabled( 'forms' ) && ! current_user_can( 'deactivate_plugin', WPCF7_PLUGIN_BASENAME ) ) {
			$links['nb-base-required'] = '<span>' . esc_html__( 'Required by the theme', 'nb-base' ) . '</span>';
		}
		return $links;
	}
);

/**
 * Types de fichiers et taille imposés à chaque champ fichier, quelles que
 * soient les options saisies dans le formulaire.
 */
add_filter(
	'wpcf7_form_tag',
	static function ( $tag ) {
		if ( ! is_array( $tag ) || 'file' !== ( $tag['basetype'] ?? '' ) || ! nb_base_feature_enabled( 'forms' ) ) {
			return $tag;
		}

		$options   = array_filter(
			(array) ( $tag['options'] ?? array() ),
			static fn( $option ) => ! preg_match( '/^(filetypes|limit):/', (string) $option )
		);
		$options[] = 'filetypes:' . implode( '|', nb_base_form_file_extensions() );
		$options[] = 'limit:' . nb_base_form_max_file_size();

		$tag['options'] = array_values( $options );
		return $tag;
	}
);

/**
 * Extensions acceptées par le thème : pas de renommage de sécurité (leur
 * contenu réel est vérifié par nb_base_cf7_validate_file()).
 */
add_filter(
	'wpcf7_file_extension_safelist',
	static function ( $safelist ) {
		if ( ! nb_base_feature_enabled( 'forms' ) ) {
			return $safelist;
		}
		return array_values( array_unique( array_merge( (array) $safelist, nb_base_form_file_extensions() ) ) );
	}
);

/**
 * Champ fichier : rendu de l'extension + légende.
 */
add_action(
	'wpcf7_init',
	static function () {
		if ( ! nb_base_feature_enabled( 'forms' ) || ! function_exists( 'wpcf7_file_form_tag_handler' ) ) {
			return;
		}
		wpcf7_remove_form_tag( 'file' );
		wpcf7_remove_form_tag( 'file*' );
		wpcf7_add_form_tag(
			array( 'file', 'file*' ),
			'nb_base_cf7_file_tag_handler',
			array(
				'name-attr'      => true,
				'file-uploading' => true,
			)
		);
	},
	20
);

/**
 * Rendu du champ fichier avec sa légende.
 *
 * @param WPCF7_FormTag $tag Champ.
 */
function nb_base_cf7_file_tag_handler( $tag ): string {
	$html = (string) wpcf7_file_form_tag_handler( $tag );
	if ( '' === $html ) {
		return '';
	}

	$legend_id = 'nb-form-legend-' . sanitize_html_class( $tag->name );

	// Relie la légende au champ (en plus du message d'erreur éventuel).
	if ( preg_match( '/<input[^>]*\saria-describedby="([^"]*)"/', $html ) ) {
		$html = preg_replace( '/(<input[^>]*\saria-describedby=")([^"]*)"/', '$1$2 ' . $legend_id . '"', $html, 1 );
	} else {
		$html = preg_replace( '/<input\s/', '<input aria-describedby="' . esc_attr( $legend_id ) . '" ', $html, 1 );
	}

	return $html . '<span class="nb-form-file-legend" id="' . esc_attr( $legend_id ) . '">' . esc_html( nb_base_form_file_legend() ) . '</span>';
}

/**
 * Contrôle du contenu réel des fichiers.
 *
 * @param WPCF7_Validation $result Résultat de la validation.
 * @param WPCF7_FormTag    $tag    Champ.
 * @param array            $args   Contient « uploaded_files ».
 */
function nb_base_cf7_validate_file( $result, $tag, $args = array() ) {
	if ( ! nb_base_feature_enabled( 'forms' ) ) {
		return $result;
	}
	foreach ( (array) ( $args['uploaded_files'] ?? array() ) as $path ) {
		if ( false === nb_base_form_check_file( (string) $path, wp_basename( (string) $path ) ) ) {
			$result->invalidate( $tag, wpcf7_get_message( 'upload_file_type_invalid' ) );
			break;
		}
	}
	return $result;
}
add_filter( 'wpcf7_validate_file', 'nb_base_cf7_validate_file', 20, 3 );
add_filter( 'wpcf7_validate_file*', 'nb_base_cf7_validate_file', 20, 3 );

/* -------------------------------------------------------------------------
 * Anti-spam du thème (inc/forms-antispam.php).
 * ---------------------------------------------------------------------- */

// Heure d'affichage signée (champs cachés de l'extension).
add_filter(
	'wpcf7_form_hidden_fields',
	static function ( $fields ) {
		$form = wpcf7_get_current_contact_form();
		if ( ! $form || ! nb_base_feature_enabled( 'forms' ) ) {
			return $fields;
		}
		return array_merge( (array) $fields, nb_base_form_antispam_fields( (string) $form->id() ) );
	}
);

// Champ piège, à la fin des champs du formulaire.
add_filter(
	'wpcf7_form_elements',
	static fn( $html ) => nb_base_feature_enabled( 'forms' ) ? $html . nb_base_form_honeypot_html() : $html
);

/**
 * Cloudflare Turnstile : intégration native de l'extension (clés saisies par
 * le designer dans Contact → Intégration ; widget ajouté seul à chaque
 * formulaire, vérification côté serveur). Le thème la règle :
 *  - invisible sauf soupçon (« interaction-only »), sauf mode choisi dans le
 *    formulaire ([turnstile appearance:…]) ;
 *  - juste avant le bouton d'envoi (l'extension le met en tête) ;
 *  - script de Cloudflare seulement sur les pages qui affichent un formulaire
 *    (l'extension le charge partout).
 */
function nb_base_cf7_turnstile_active(): bool {
	return class_exists( 'WPCF7_Turnstile' ) && WPCF7_Turnstile::get_instance()->is_active();
}

/**
 * Un formulaire a-t-il été affiché dans la page en cours ?
 *
 * @param bool $set Mémoriser qu'un formulaire est affiché.
 */
function nb_base_cf7_form_rendered( bool $set = false ): bool {
	static $rendered = false;
	if ( $set ) {
		$rendered = true;
	}
	return $rendered;
}

add_filter(
	'wpcf7_form_elements',
	static function ( $html ) {
		nb_base_cf7_form_rendered( true );
		if ( ! nb_base_feature_enabled( 'forms' ) || ! nb_base_cf7_turnstile_active() ) {
			return $html;
		}
		if ( ! preg_match( '#<div class="wpcf7-turnstile cf-turnstile"[^>]*></div>\s*#', (string) $html, $match ) ) {
			return $html;
		}
		// Classe du thème : pas d'espace en plus tant qu'il est caché (styles du
		// bloc Formulaire, « is-visible » posée par le script plus bas).
		$widget = str_replace( 'class="wpcf7-turnstile cf-turnstile"', 'class="wpcf7-turnstile cf-turnstile nb-form-captcha"', trim( $match[0] ) );
		if ( ! str_contains( $widget, 'data-appearance=' ) ) {
			$widget = str_replace( '<div ', '<div data-appearance="interaction-only" ', $widget );
		}
		$without = str_replace( $match[0], '', (string) $html );
		if ( ! preg_match( '#<input[^>]*\bclass="[^"]*\bwpcf7-submit\b#', $without, $submit, PREG_OFFSET_CAPTURE ) ) {
			return str_replace( $match[0], $widget . "\n", (string) $html );
		}
		return substr_replace( $without, $widget, $submit[0][1], 0 );
	},
	20
);

// Modèles de blocs : la page est rendue avant l'en-tête, on sait donc déjà
// si elle contient un formulaire.
add_action(
	'wp_enqueue_scripts',
	static function () {
		if ( ! nb_base_feature_enabled( 'forms' ) ) {
			return;
		}
		if ( ! nb_base_cf7_form_rendered() ) {
			wp_dequeue_script( 'cloudflare-turnstile' );
			return;
		}
		// Widget affiché (soupçon) : classe « is-visible » (sa hauteur est la
		// seule différence, invisible pour le CSS).
		wp_add_inline_script(
			'cloudflare-turnstile',
			"document.addEventListener( 'DOMContentLoaded', () => { if ( ! window.ResizeObserver ) { return; } document.querySelectorAll( '.nb-form-captcha' ).forEach( ( el ) => new ResizeObserver( () => el.classList.toggle( 'is-visible', el.offsetHeight > 0 ) ).observe( el ) ); } );"
		);
	},
	20
);

// Mention d'information sous le formulaire (inc/forms.php).
add_filter(
	'nb_base_form_protection_service',
	static fn( $service ) => nb_base_cf7_turnstile_active()
		? array(
			'name' => 'Cloudflare Turnstile',
			'url'  => 'https://www.cloudflare.com/privacypolicy/',
		)
		: $service
);

// Verdict, après la validation et les contrôles de l'extension.
add_filter(
	'wpcf7_spam',
	static function ( $spam, $submission ) {
		if ( $spam || ! nb_base_feature_enabled( 'forms' ) || ! $submission instanceof WPCF7_Submission ) {
			return $spam;
		}
		$form = $submission->get_contact_form();
		$raw  = array();
		foreach ( array( nb_base_form_honeypot_name(), NB_BASE_FORM_TIME_FIELD ) as $name ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- envoi public, jeton vérifié par l'extension pour les comptes connectés.
			if ( isset( $_POST[ $name ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$raw[ $name ] = is_string( $_POST[ $name ] ) ? sanitize_text_field( wp_unslash( $_POST[ $name ] ) ) : array();
			}
		}
		$reason = nb_base_form_spam_reason(
			$raw,
			(array) $submission->get_posted_data(),
			$form ? (string) $form->id() : '',
			(string) $submission->get_meta( 'remote_ip' )
		);
		if ( '' === $reason ) {
			return $spam;
		}
		$submission->add_spam_log(
			array(
				'agent'  => 'nb-base',
				'reason' => $reason,
			)
		);
		return true;
	},
	20,
	2
);

/**
 * Envoi → envoi normalisé.
 */
add_action(
	'wpcf7_submit',
	static function ( $contact_form, $result ) {
		$status = is_array( $result ) ? ( $result['status'] ?? '' ) : '';
		if ( ! in_array( $status, array( 'mail_sent', 'mail_failed' ), true ) || ! nb_base_feature_enabled( 'forms' ) ) {
			return;
		}

		$submission = WPCF7_Submission::get_instance();
		if ( ! $submission ) {
			return;
		}

		$fields = array();
		foreach ( $contact_form->scan_form_tags() as $tag ) {
			if ( '' === (string) $tag->name || 'submit' === $tag->basetype || 'file' === $tag->basetype ) {
				continue;
			}
			$fields[ $tag->name ] = $submission->get_posted_data( $tag->name );
		}

		$entry_id = nb_base_form_handle_submission(
			array(
				'source'     => 'cf7',
				'form_id'    => (string) $contact_form->id(),
				'form_title' => $contact_form->title(),
				'fields'     => $fields,
				'files'      => $submission->uploaded_files(),
				'mail_sent'  => 'mail_sent' === $status,
				'store'      => ! $submission->get_meta( 'do_not_store' ),
			)
		);

		// E-mail non parti mais message enregistré : réussite pour le visiteur
		// (l'échec est signalé dans le message, côté administration).
		if ( 'mail_failed' === $status && $entry_id > 0 ) {
			nb_base_cf7_saved_despite_mail( (int) $contact_form->id() );
		}
	},
	10,
	2
);

/**
 * Formulaire dont l'e-mail a échoué mais dont le message est enregistré
 * (pour la requête en cours).
 *
 * @param int|null $form_id Identifiant à mémoriser ; null pour lire.
 */
function nb_base_cf7_saved_despite_mail( ?int $form_id = null ): int {
	static $saved = 0;
	if ( null !== $form_id ) {
		$saved = $form_id;
	}
	return $saved;
}

// Réponse de l'envoi (formulaire envoyé en arrière-plan, cas normal).
add_filter(
	'wpcf7_feedback_response',
	static function ( $response ) {
		$form_id = (int) ( $response['contact_form_id'] ?? 0 );
		if ( ! is_array( $response ) || 'mail_failed' !== ( $response['status'] ?? '' ) || ! $form_id || nb_base_cf7_saved_despite_mail() !== $form_id ) {
			return $response;
		}
		$form                = wpcf7_contact_form( $form_id );
		$response['status']  = 'mail_sent';
		$response['message'] = $form ? $form->message( 'mail_sent_ok' ) : $response['message'];
		return $response;
	}
);

// Même chose sans JavaScript (page rechargée) : message et classe du formulaire.
add_filter(
	'wpcf7_form_response_output',
	static function ( $output, $class, $content, $contact_form ) {
		if ( ! $contact_form || nb_base_cf7_saved_despite_mail() !== (int) $contact_form->id() ) {
			return $output;
		}
		return sprintf( '<div class="wpcf7-response-output" aria-hidden="true">%s</div>', esc_html( $contact_form->message( 'mail_sent_ok' ) ) );
	},
	10,
	4
);
add_filter(
	'wpcf7_form_class_attr',
	static function ( $class ) {
		return nb_base_cf7_saved_despite_mail() ? str_replace( 'failed', 'sent', (string) $class ) : $class;
	}
);

/* -------------------------------------------------------------------------
 * Affichage.
 * ---------------------------------------------------------------------- */

add_filter(
	'nb_base_form_choices',
	static function ( array $choices ): array {
		foreach ( WPCF7_ContactForm::find( array( 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $form ) {
			$choices[ (string) $form->id() ] = $form->title();
		}
		return $choices;
	}
);

add_filter(
	'nb_base_form_html',
	static function ( string $html, string $form_id ): string {
		$id = absint( $form_id );
		if ( ! $id || ! wpcf7_contact_form( $id ) ) {
			return $html;
		}
		return do_shortcode( sprintf( '[contact-form-7 id="%d" html_class="nb-form__form"]', $id ) );
	},
	10,
	2
);

// Lien « Modifier le formulaire » de l'éditeur ({id} remplacé par l'identifiant) :
// seulement pour qui a accès aux formulaires (voir les droits plus bas).
add_filter(
	'nb_base_form_edit_url',
	static fn() => nb_base_client_access( 'client_forms' ) ? admin_url( 'admin.php?page=wpcf7&post={id}&action=edit' ) : ''
);

// Champs d'un formulaire : nom => type (« text », « email », « acceptance »…),
// sans bouton ni fichier (comme l'envoi normalisé).
add_filter(
	'nb_base_form_fields',
	static function ( array $fields, string $form_id ): array {
		$form = absint( $form_id ) ? wpcf7_contact_form( absint( $form_id ) ) : null;
		if ( ! $form ) {
			return $fields;
		}
		foreach ( $form->scan_form_tags() as $tag ) {
			if ( '' === (string) $tag->name || 'submit' === $tag->basetype || 'file' === $tag->basetype ) {
				continue;
			}
			$fields[ (string) $tag->name ] = (string) $tag->basetype;
		}
		return $fields;
	},
	10,
	2
);

// Menus de l'extension (ordre de la colonne de gauche, inc/admin-menu.php).
add_filter(
	'nb_base_forms_menu_slugs',
	static fn( array $slugs ): array => array_merge( $slugs, array( 'wpcf7-dashboard', 'wpcf7' ) )
);

// Lien « Gérer les formulaires » de l'onglet Formulaires (page NB Base).
add_filter(
	'nb_base_form_list_url',
	static fn() => admin_url( 'admin.php?page=wpcf7' )
);

/**
 * Choix « Type de demande » : [select type-demande data:nb_request_types].
 */
add_filter(
	'wpcf7_form_tag_data_option',
	static function ( $data, $options ) {
		if ( in_array( 'nb_request_types', (array) $options, true ) ) {
			$data = array_merge( (array) $data, (array) get_option( 'nb_base_request_types', array() ) );
		}
		return $data;
	},
	10,
	2
);

add_filter(
	'wpcf7_autop_or_not',
	static fn( $autop ) => nb_base_feature_enabled( 'forms' ) ? false : $autop
);

/**
 * Formulaire type du thème (contact / devis). Balisage :
 *  - .nb-form-row : champs côte à côte (empilés sur mobile) ;
 *  - label.nb-form-field > span.nb-form-label + champ ;
 *  - noms de champs conventionnels : last-name, email (voir README) ; jamais un terme réservé de WordPress (name, attachment…), refusé par Contact Form 7 ;
 *  - un texte indicatif dans chaque champ (liste : premier choix ; fichier :
 *    légende du thème, les navigateurs n'en affichent pas) ;
 *  - bouton : [submit class:nb-form-submit].
 */
function nb_base_cf7_default_form(): string {
	$label = static fn( string $text, bool $required = false ) => '<span class="nb-form-label">' . $text . ( $required ? ' *' : '' ) . '</span>';

	return '<div class="nb-form-row">' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Last name', 'nb-base' ), true ) . ' [text* last-name autocomplete:family-name placeholder "' . __( 'Your last name', 'nb-base' ) . '"]</label>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'First name', 'nb-base' ) ) . ' [text first-name autocomplete:given-name placeholder "' . __( 'Your first name', 'nb-base' ) . '"]</label>' . "\n"
		. '</div>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Email', 'nb-base' ), true ) . ' [email* email autocomplete:email placeholder "' . __( 'your@email.com', 'nb-base' ) . '"]</label>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Phone', 'nb-base' ) ) . ' [tel phone autocomplete:tel placeholder "' . __( 'Your phone number', 'nb-base' ) . '"]</label>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Request type', 'nb-base' ) ) . ' [select request-type first_as_label data:nb_request_types "' . __( 'Select', 'nb-base' ) . '"]</label>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Message', 'nb-base' ) ) . ' [textarea message x5 placeholder "' . __( 'Type your message', 'nb-base' ) . '"]</label>' . "\n"
		. '<label class="nb-form-field">' . $label( __( 'Attached file', 'nb-base' ) ) . ' [file attached-file]</label>' . "\n"
		. '[submit class:nb-form-submit "' . __( 'Send', 'nb-base' ) . '"]';
}

/**
 * E-mail de notification type, accordé aux champs du formulaire type
 * (réponse directe à l'expéditeur, fichier joint, lignes vides omises).
 *
 * @param array $mail E-mail par défaut de l'extension.
 */
function nb_base_cf7_default_mail( array $mail ): array {
	$line = static fn( string $label, string $tag ) => $label . ' : ' . $tag . "\n";

	$mail['subject']            = '[_site_title] – ' . __( 'New request', 'nb-base' ) . ' [request-type]';
	$mail['body']               = $line( __( 'Last name', 'nb-base' ), '[last-name]' )
		. $line( __( 'First name', 'nb-base' ), '[first-name]' )
		. $line( __( 'Email', 'nb-base' ), '[email]' )
		. $line( __( 'Phone', 'nb-base' ), '[phone]' )
		. $line( __( 'Request type', 'nb-base' ), '[request-type]' )
		. "\n" . __( 'Message', 'nb-base' ) . " :\n[message]\n\n"
		. "-- \n"
		. sprintf(
			/* translators: 1: site name, 2: site address. */
			__( 'Sent from the form of %1$s (%2$s). The message and its files are also in the administration, menu Messages.', 'nb-base' ),
			'[_site_title]',
			'[_site_url]'
		);
	$mail['additional_headers'] = 'Reply-To: [email]';
	$mail['attachments']        = '[attached-file]';
	$mail['exclude_blank']      = 1;

	return $mail;
}

add_filter(
	'wpcf7_default_template',
	static function ( $template, $prop ) {
		if ( ! nb_base_feature_enabled( 'forms' ) ) {
			return $template;
		}
		// Textes du site : dans la langue du site, quelle que soit celle de l'utilisateur.
		if ( 'form' === $prop ) {
			return nb_base_in_site_locale( 'nb_base_cf7_default_form' );
		}
		if ( 'mail' === $prop && is_array( $template ) ) {
			return nb_base_in_site_locale( static fn() => nb_base_cf7_default_mail( $template ) );
		}
		return $template;
	},
	10,
	2
);

/**
 * Domaine d'envoi du site : hôte de l'adresse du site, sans « www. »
 * (comme l'adresse par défaut de Contact Form 7).
 */
function nb_base_cf7_site_mail_domain(): string {
	$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return str_starts_with( $host, 'www.' ) ? substr( $host, 4 ) : $host;
}

/**
 * Expéditeur corrigé pour le domaine du site : une adresse « wordpress@… »
 * (celle que Contact Form 7 écrit à la création du formulaire) ou une adresse
 * d'essai (example.com, .local, .test…) d'un autre domaine devient
 * wordpress@<domaine du site> ; le nom affiché est gardé. Toute autre adresse
 * (choisie sur un vrai domaine) est respectée. Cas visé : formulaire créé en
 * local ou sur un autre site, puis migré.
 *
 * @param string $sender Expéditeur (« Nom <adresse> » ou adresse seule).
 * @param string $domain Domaine du site.
 */
function nb_base_cf7_site_sender( string $sender, string $domain ): string {
	// Site sans vrai domaine (local) : rien à corriger.
	if ( '' === $domain || ! str_contains( $domain, '.' ) || preg_match( '/(^|\.)(localhost|local|test|invalid|example)$/', $domain ) ) {
		return $sender;
	}
	if ( ! preg_match( '/^\s*(?:(.*?)\s*<\s*([^<>\s@]+)@([^<>\s@]+)\s*>|([^<>\s@]+)@([^<>\s@]+))\s*$/', $sender, $m ) ) {
		return $sender;
	}
	$name  = trim( (string) ( $m[1] ?? '' ) );
	$local = strtolower( '' !== ( $m[2] ?? '' ) ? $m[2] : (string) ( $m[4] ?? '' ) );
	$host  = strtolower( '' !== ( $m[3] ?? '' ) ? $m[3] : (string) ( $m[5] ?? '' ) );
	$test  = (bool) preg_match( '/(^|\.)(localhost|local|test|invalid|example|example\.com|example\.org|example\.net)$/', $host );
	if ( $host === $domain || ( 'wordpress' !== $local && ! $test ) ) {
		return $sender;
	}
	$address = 'wordpress@' . $domain;
	return '' !== $name ? $name . ' <' . $address . '>' : $address;
}

add_filter(
	'wpcf7_mail_components',
	static function ( $components ) {
		if ( is_array( $components ) && isset( $components['sender'] ) && nb_base_feature_enabled( 'forms' ) ) {
			$components['sender'] = nb_base_cf7_site_sender( (string) $components['sender'], nb_base_cf7_site_mail_domain() );
		}
		return $components;
	}
);

/* -------------------------------------------------------------------------
 * Droits du client dans Contact Form 7.
 * ---------------------------------------------------------------------- */

// Créer (menu « Ajouter »), supprimer, écran Intégration : designer seulement.
// Voir et modifier les formulaires existants (menu Contact) : aussi les autres
// administrateurs si l'accès « client_forms » est ouvert.
add_filter(
	'wpcf7_map_meta_cap',
	static function ( array $meta_caps ): array {
		if ( nb_base_feature_enabled( 'forms' ) ) {
			$caps = array( 'wpcf7_edit_contact_forms', 'wpcf7_delete_contact_form', 'wpcf7_delete_contact_forms', 'wpcf7_manage_integration' );
			if ( ! nb_base_feature_enabled( 'client_forms' ) ) {
				$caps = array_merge( $caps, array( 'wpcf7_read_contact_form', 'wpcf7_read_contact_forms', 'wpcf7_edit_contact_form' ) );
			}
			foreach ( $caps as $cap ) {
				$meta_caps[ $cap ] = NB_BASE_DESIGN_CAP;
			}
		}
		return $meta_caps;
	}
);

// Enregistrer un nouveau formulaire (identifiant -1) : designer seulement.
add_filter(
	'map_meta_cap',
	static function ( array $caps, string $cap, int $user_id, array $args ): array {
		if (
			'wpcf7_edit_contact_form' === $cap &&
			(int) ( $args[0] ?? 0 ) <= 0 &&
			nb_base_feature_enabled( 'forms' ) &&
			! nb_base_is_designer( $user_id )
		) {
			$caps[] = 'do_not_allow';
		}
		return $caps;
	},
	20,
	4
);

// Dupliquer : designer seulement.
add_action(
	'wpcf7_admin_load',
	static function ( $page, $action ) {
		if ( 'copy' === $action && nb_base_feature_enabled( 'forms' ) && ! nb_base_is_designer() ) {
			wp_die( esc_html__( 'Only the designer can create forms.', 'nb-base' ), 403 );
		}
	},
	10,
	2
);

/* -------------------------------------------------------------------------
 * Newsletter (inc/newsletter.php).
 * ---------------------------------------------------------------------- */

/**
 * Formulaire de newsletter type : e-mail (sans libellé visible), case de
 * consentement obligatoire, bouton. Classe .nb-form--newsletter.
 */
function nb_base_cf7_newsletter_form(): string {
	return '<label class="nb-form-field"><span class="nb-form-label screen-reader-text">' . __( 'Email', 'nb-base' ) . '</span> [email* email autocomplete:email placeholder "' . __( 'Your email address', 'nb-base' ) . '"]</label>' . "\n"
		. '[acceptance newsletter-consent] ' . sprintf(
			/* translators: %s: site name. */
			__( 'I agree to receive the newsletter of %s. I can unsubscribe at any time with the link in each email.', 'nb-base' ),
			get_bloginfo( 'name' )
		) . ' [/acceptance]' . "\n"
		. '[submit class:nb-form-submit "' . __( 'Send', 'nb-base' ) . '"]';
}

/**
 * Message de réussite du formulaire de newsletter, selon la double confirmation.
 */
function nb_base_cf7_newsletter_sent_message( bool $double_opt_in ): string {
	return $double_opt_in
		? __( 'Thank you! Check your inbox and click the link to confirm your subscription.', 'nb-base' )
		: __( 'Thank you! Your subscription is registered.', 'nb-base' );
}

// Message de réussite affiché : suit le réglage « Double confirmation » du
// moment (il est enregistré dans le formulaire à sa création). Seulement si
// c'est encore l'un des deux textes du thème : un texte modifié est respecté.
add_filter(
	'wpcf7_display_message',
	static function ( $message, $status ) {
		if ( 'mail_sent_ok' !== $status || ! function_exists( 'nb_base_newsletter_available' ) || ! nb_base_newsletter_available() ) {
			return $message;
		}
		$form = wpcf7_get_current_contact_form();
		if ( ! $form || (string) $form->id() !== nb_base_newsletter_settings()['formId'] ) {
			return $message;
		}
		$stored = trim( (string) $form->message( 'mail_sent_ok', false ) );
		return nb_base_in_site_locale(
			static function () use ( $message, $stored ) {
				$defaults = array( nb_base_cf7_newsletter_sent_message( true ), nb_base_cf7_newsletter_sent_message( false ) );
				return in_array( $stored, $defaults, true )
					? nb_base_cf7_newsletter_sent_message( nb_base_newsletter_double_opt_in() )
					: $message;
			}
		);
	},
	10,
	2
);

add_filter(
	'nb_base_newsletter_create_form',
	static function ( string $id ): string {
		// Formulaire et messages de l'extension dans la langue du site.
		$saved = nb_base_in_site_locale(
			static function () {
				$form = WPCF7_ContactForm::get_template(
					array(
						'title'  => __( 'Newsletter', 'nb-base' ),
						'locale' => get_locale(),
					)
				);
				$messages = $form->prop( 'messages' );
				$messages['mail_sent_ok']    = nb_base_cf7_newsletter_sent_message( nb_base_newsletter_double_opt_in() );
				$messages['accept_terms']    = __( 'Please tick the box to subscribe.', 'nb-base' );
				$form->set_properties(
					array(
						'messages'            => $messages,
						'form'                => nb_base_cf7_newsletter_form(),
						// Pas d'e-mail de notification pour chaque inscription.
						'additional_settings' => 'skip_mail: on',
					)
				);
				return $form->save();
			}
		);
		return $saved ? (string) $saved : $id;
	}
);

// Classe du formulaire de newsletter (styles du pied de page).
add_filter(
	'wpcf7_form_class_attr',
	static function ( $class ) {
		$form = wpcf7_get_current_contact_form();
		if ( $form && function_exists( 'nb_base_newsletter_settings' ) && (string) $form->id() === nb_base_newsletter_settings()['formId'] ) {
			$class .= ' nb-form--newsletter';
		}
		return $class;
	}
);
