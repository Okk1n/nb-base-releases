<?php
/**
 * Animations d'apparition des blocs (script commun « nb-base-reveal »,
 * source : src/reveal/). Chaque bloc animable a son réglage, désactivé par
 * défaut ; son render.php appelle nb_base_reveal_attribute() quand il est
 * activé. Effet d'usine : theme.json → settings.custom.animation.<animation>,
 * surchargeable par site (styles.json). Voir README.md (« Animations »).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'init',
	static function () {
		$asset_file = NB_BASE_DIR . '/build-reveal/index.asset.php';
		if ( ! is_readable( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_register_script(
			'nb-base-reveal',
			NB_BASE_URI . '/build-reveal/index.js',
			$asset['dependencies'],
			$asset['version'],
			array( 'in_footer' => true, 'strategy' => 'defer' )
		);
		wp_register_style( 'nb-base-reveal', NB_BASE_URI . '/build-reveal/style-index.css', array(), $asset['version'] );
	},
	5
);

/**
 * Attribut HTML d'un conteneur animé (ses enfants directs s'animent) ; charge
 * le script et les styles. À appeler depuis render.php, seulement si le
 * réglage du bloc est activé.
 *
 * @param string $animation Nom de l'animation (clé de settings.custom.animation, ex. « cards »).
 * @return string Ex. ` data-nb-reveal="cards"` (espace initial compris).
 */
function nb_base_reveal_attribute( string $animation ): string {
	nb_base_reveal_enqueue();
	return ' data-nb-reveal="' . esc_attr( $animation ) . '"';
}

/**
 * Charge le script et les styles des animations, et prévoit la classe posée
 * dans <head>. Les blocs d'un thème de blocs sont rendus avant wp_head : la
 * classe est donc en place avant l'affichage (pas de clignotement).
 */
function nb_base_reveal_enqueue(): void {
	wp_enqueue_script( 'nb-base-reveal' );
	wp_enqueue_style( 'nb-base-reveal' );
	$GLOBALS['nb_base_reveal_used'] = true;
}

/**
 * <head> : classe .nb-reveal (éléments masqués en attendant leur apparition),
 * retirée au bout de 3 s si le script n'a pas démarré : le contenu n'est
 * jamais caché durablement.
 */
add_action(
	'wp_head',
	static function () {
		if ( empty( $GLOBALS['nb_base_reveal_used'] ) ) {
			return;
		}
		wp_print_inline_script_tag(
			'document.documentElement.classList.add("nb-reveal");setTimeout(function(){if(!window.nbReveal){document.documentElement.classList.remove("nb-reveal");}},3000);'
		);
	},
	1
);

/**
 * Carrousel « Autres … » des contenus structurés (nb-base/entry-carousel) :
 * animation des cartes réglée **par type de contenu** (toutes les fiches,
 * anciennes comprises), depuis la colonne de droite du bloc. Option : liste
 * des types dont les cartes s'animent (vide par défaut).
 */
add_action(
	'init',
	static function () {
		register_setting(
			'nb_base',
			'nb_base_related_reveal',
			array(
				'type'              => 'array',
				'description'       => __( 'Content types whose “Other …” carousel cards are animated.', 'nb-base' ),
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
				'sanitize_callback' => static fn( $value ) => array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $value ) ) ) ),
			)
		);
	}
);

/** Les cartes du carrousel « Autres … » de ce type s'animent-elles ? */
function nb_base_related_reveal( string $post_type ): bool {
	return in_array( $post_type, (array) get_option( 'nb_base_related_reveal', array() ), true );
}
