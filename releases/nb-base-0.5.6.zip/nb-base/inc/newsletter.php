<?php
/**
 * Newsletter : inscription depuis le pied de page, envoyée à un service
 * d'e-mailing (Brevo, ou webhook pour tout autre service).
 *
 * - Fonctionnalité « newsletter » (désactivée par défaut), qui nécessite la
 *   fonctionnalité « forms » : le formulaire est un formulaire de l'extension
 *   (Contact Form 7), créé depuis la page NB Base (modèle du thème : e-mail,
 *   case de consentement, bouton ; pas d'e-mail de notification).
 * - Le client masque ou affiche la newsletter (onglet Pied de page,
 *   nb_base_footer.showNewsletter) et modifie les textes du formulaire dans
 *   l'extension.
 * - Réglages du service : page NB Base, designer seulement (option
 *   « nb_base_newsletter », jamais exposée par l'API REST ; clé API jamais
 *   réaffichée).
 * - Envoi : action « nb_base_form_submitted » (envoi normalisé, inc/forms.php)
 *   pour le formulaire de newsletter, jamais enregistré dans les messages…
 *   sauf si le service échoue : l'inscription est alors enregistrée dans
 *   Messages avec l'erreur (aucune inscription perdue) et l'erreur est notée
 *   dans le journal de la page NB Base. Le visiteur voit toujours le message
 *   de réussite.
 * - Fournisseurs : nb_base_newsletter_providers() (filtre
 *   « nb_base_newsletter_providers ») ; un fournisseur = un libellé et une
 *   fonction d'inscription. Ajouter un service = ajouter un fournisseur.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_NEWSLETTER_OPTION = 'nb_base_newsletter';
const NB_BASE_NEWSLETTER_LOG    = 'nb_base_newsletter_log';

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['newsletter'] = array(
			'group'       => 'forms',
			'label'       => __( 'Newsletter', 'nb-base' ),
			'description' => __( 'Newsletter sign-up form in the footer, sent to an emailing service (Brevo or webhook). Requires the Forms feature.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

/**
 * La newsletter est-elle utilisable (fonctionnalités et extension) ?
 */
function nb_base_newsletter_available(): bool {
	return nb_base_feature_enabled( 'newsletter' ) && nb_base_feature_enabled( 'forms' ) && nb_base_forms_plugin_active();
}

/* -------------------------------------------------------------------------
 * Réglages.
 * ---------------------------------------------------------------------- */

/**
 * fieldMap : champ du formulaire => attribut Brevo (champs non listés : non envoyés).
 *
 * @return array{provider: string, formId: string, apiKey: string, listId: int, doubleOptIn: bool, doiTemplateId: int, doiRedirect: string, webhookUrl: string, fieldMap: array<string, string>}
 */
function nb_base_newsletter_defaults(): array {
	return array(
		'provider'      => 'brevo',
		'formId'        => '',
		'apiKey'        => '',
		'listId'        => 0,
		'doubleOptIn'   => true,
		'doiTemplateId' => 0,
		'doiRedirect'   => '',
		'webhookUrl'    => '',
		'fieldMap'      => array(),
	);
}

/**
 * Réglages nettoyés.
 *
 * @param mixed $value Valeur enregistrée ou reçue.
 */
function nb_base_sanitize_newsletter( $value ): array {
	$value    = is_array( $value ) ? $value : array();
	$defaults = nb_base_newsletter_defaults();
	$provider = (string) ( $value['provider'] ?? $defaults['provider'] );
	$map      = array();
	foreach ( (array) ( $value['fieldMap'] ?? array() ) as $field => $attribute ) {
		$field     = preg_replace( '/[^a-z0-9_:.-]/i', '', (string) $field );
		$attribute = strtoupper( preg_replace( '/[^a-z0-9_]/i', '', (string) $attribute ) );
		if ( '' !== $field && '' !== $attribute && strlen( $attribute ) <= 64 && count( $map ) < 50 ) {
			$map[ $field ] = $attribute;
		}
	}

	return array(
		'provider'      => array_key_exists( $provider, nb_base_newsletter_providers() ) ? $provider : $defaults['provider'],
		'formId'        => preg_replace( '/[^0-9a-z_-]/i', '', (string) ( $value['formId'] ?? '' ) ),
		'apiKey'        => preg_replace( '/[^0-9a-z_.-]/i', '', (string) ( $value['apiKey'] ?? '' ) ),
		'listId'        => absint( $value['listId'] ?? 0 ),
		'doubleOptIn'   => array_key_exists( 'doubleOptIn', $value ) ? (bool) $value['doubleOptIn'] : $defaults['doubleOptIn'],
		'doiTemplateId' => absint( $value['doiTemplateId'] ?? 0 ),
		'doiRedirect'   => esc_url_raw( (string) ( $value['doiRedirect'] ?? '' ), array( 'http', 'https' ) ),
		'webhookUrl'    => esc_url_raw( (string) ( $value['webhookUrl'] ?? '' ), array( 'https' ) ),
		'fieldMap'      => $map,
	);
}

function nb_base_newsletter_settings(): array {
	return nb_base_sanitize_newsletter( get_option( NB_BASE_NEWSLETTER_OPTION, array() ) );
}

/**
 * Double confirmation en vigueur (réglage propre à Brevo : sans effet pour
 * les autres services).
 */
function nb_base_newsletter_double_opt_in(): bool {
	$s = nb_base_newsletter_settings();
	return 'brevo' === $s['provider'] && $s['doubleOptIn'];
}

/**
 * Services proposés : identifiant => libellé et fonction d'inscription
 * ( fn( string $email, array $settings, array $fields ): true|WP_Error ;
 * $fields : champs envoyés par le visiteur, nom => valeur ).
 *
 * @return array<string, array{label: string, subscribe: callable}>
 */
function nb_base_newsletter_providers(): array {
	return (array) apply_filters(
		'nb_base_newsletter_providers',
		array(
			'brevo'   => array(
				'label'     => 'Brevo',
				'subscribe' => 'nb_base_newsletter_brevo_subscribe',
			),
			'webhook' => array(
				'label'     => __( 'Webhook (other service, Zapier, Make, n8n…)', 'nb-base' ),
				'subscribe' => 'nb_base_newsletter_webhook_subscribe',
			),
		)
	);
}

/* -------------------------------------------------------------------------
 * Fournisseurs.
 * ---------------------------------------------------------------------- */

/**
 * Brevo (API v3). Double confirmation : modèle de confirmation Brevo
 * (« double opt-in ») et page de retour ; sinon ajout direct à la liste.
 *
 * @return true|WP_Error
 */
function nb_base_newsletter_brevo_subscribe( string $email, array $settings, array $fields = array() ) {
	if ( '' === $settings['apiKey'] || ! $settings['listId'] ) {
		return new WP_Error( 'nb_newsletter_config', __( 'Brevo: API key or list missing.', 'nb-base' ) );
	}

	if ( $settings['doubleOptIn'] ) {
		if ( ! $settings['doiTemplateId'] ) {
			return new WP_Error( 'nb_newsletter_config', __( 'Brevo: double opt-in template missing.', 'nb-base' ) );
		}
		$url  = 'https://api.brevo.com/v3/contacts/doubleOptinConfirmation';
		$body = array(
			'email'          => $email,
			'includeListIds' => array( $settings['listId'] ),
			'templateId'     => $settings['doiTemplateId'],
			'redirectionUrl' => $settings['doiRedirect'] ? $settings['doiRedirect'] : home_url( '/' ),
		);
	} else {
		$url  = 'https://api.brevo.com/v3/contacts';
		$body = array(
			'email'         => $email,
			'listIds'       => array( $settings['listId'] ),
			'updateEnabled' => true,
		);
	}

	$attributes = nb_base_newsletter_brevo_contact_attributes( $settings, $fields );
	if ( $attributes ) {
		$body['attributes'] = $attributes;
	}

	$response = wp_remote_post(
		$url,
		array(
			'timeout' => 10,
			'headers' => array(
				'api-key'      => $settings['apiKey'],
				'accept'       => 'application/json',
				'content-type' => 'application/json',
			),
			'body'    => wp_json_encode( $body ),
		)
	);

	return nb_base_newsletter_check_response( $response, 'Brevo' );
}

/**
 * Webhook : données envoyées en JSON (POST) à l'adresse réglée (https).
 *
 * @return true|WP_Error
 */
function nb_base_newsletter_webhook_subscribe( string $email, array $settings, array $fields = array() ) {
	if ( '' === $settings['webhookUrl'] ) {
		return new WP_Error( 'nb_newsletter_config', __( 'Webhook: address missing.', 'nb-base' ) );
	}

	$response = wp_safe_remote_post(
		$settings['webhookUrl'],
		array(
			'timeout' => 10,
			'headers' => array( 'content-type' => 'application/json' ),
			'body'    => wp_json_encode(
				array(
					'event'   => 'newsletter_subscribe',
					'email'   => $email,
					'consent' => true,
					'site'    => home_url( '/' ),
					'date'    => gmdate( 'c' ),
					'fields'  => (object) $fields,
				)
			),
		)
	);

	return nb_base_newsletter_check_response( $response, 'Webhook' );
}

/**
 * Attributs de contact du compte Brevo : nom => type (« text », « float »,
 * « date », « boolean »). Attributs « normaux » seulement (pas les listes à
 * choix, calculés ou transactionnels). Mis en cache un jour, par clé API.
 *
 * @return array<string, string>|WP_Error
 */
function nb_base_newsletter_brevo_attributes( string $api_key, bool $refresh = false ) {
	if ( '' === $api_key ) {
		return new WP_Error( 'nb_newsletter_config', __( 'Brevo: API key missing.', 'nb-base' ) );
	}
	$cache_key = 'nb_base_brevo_attributes_' . md5( $api_key );
	$cached    = $refresh ? false : get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$response = wp_remote_get(
		'https://api.brevo.com/v3/contacts/attributes',
		array(
			'timeout' => 10,
			'headers' => array(
				'api-key' => $api_key,
				'accept'  => 'application/json',
			),
		)
	);
	$check = nb_base_newsletter_check_response( $response, 'Brevo' );
	if ( is_wp_error( $check ) ) {
		return $check;
	}

	$data       = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	$attributes = array();
	foreach ( (array) ( $data['attributes'] ?? array() ) as $attribute ) {
		if ( ! is_array( $attribute ) || 'normal' !== ( $attribute['category'] ?? '' ) || empty( $attribute['name'] ) ) {
			continue;
		}
		$type = (string) ( $attribute['type'] ?? 'text' );
		if ( in_array( $type, array( 'text', 'float', 'date', 'boolean' ), true ) ) {
			$attributes[ strtoupper( (string) $attribute['name'] ) ] = $type;
		}
	}
	ksort( $attributes );
	set_transient( $cache_key, $attributes, DAY_IN_SECONDS );
	return $attributes;
}

/**
 * Attributs envoyés à Brevo pour un contact, selon la correspondance
 * champ => attribut et le type de chaque attribut :
 * - case d'acceptation : oui / non (booléen), date d'inscription (date),
 *   date d'inscription au format AAAA-MM-JJ (texte) ;
 * - choix multiples : valeurs séparées par des virgules ;
 * - nombre (float) : valeur numérique, sinon non envoyé ;
 * - champ vide : non envoyé.
 *
 * @param array $fields Champs envoyés par le visiteur, nom => valeur.
 * @return array<string, mixed>
 */
function nb_base_newsletter_brevo_contact_attributes( array $settings, array $fields ): array {
	if ( ! $settings['fieldMap'] ) {
		return array();
	}
	$kinds = nb_base_form_fields( $settings['formId'] );
	$types = nb_base_newsletter_brevo_attributes( $settings['apiKey'] );
	$types = is_wp_error( $types ) ? array() : $types;

	$attributes = array();
	foreach ( $settings['fieldMap'] as $field => $attribute ) {
		if ( ! array_key_exists( $field, $fields ) ) {
			continue;
		}
		$value = $fields[ $field ];
		$type  = $types[ $attribute ] ?? 'text';

		if ( 'acceptance' === ( $kinds[ $field ] ?? '' ) ) {
			$accepted = ! empty( $value );
			if ( 'boolean' === $type ) {
				$attributes[ $attribute ] = $accepted;
			} elseif ( $accepted ) {
				$attributes[ $attribute ] = gmdate( 'Y-m-d' );
			}
			continue;
		}

		$value = is_array( $value ) ? implode( ', ', array_map( 'strval', array_filter( $value, 'is_scalar' ) ) ) : (string) $value;
		$value = sanitize_text_field( $value );
		if ( '' === $value ) {
			continue;
		}
		if ( 'float' === $type ) {
			$number = str_replace( array( ' ', ',' ), array( '', '.' ), $value );
			if ( is_numeric( $number ) ) {
				$attributes[ $attribute ] = (float) $number;
			}
		} elseif ( 'boolean' === $type ) {
			$attributes[ $attribute ] = ! in_array( strtolower( $value ), array( '0', 'no', 'non', 'false' ), true );
		} else {
			$attributes[ $attribute ] = $value;
		}
	}
	return $attributes;
}

/**
 * Réponse HTTP 2xx = réussite ; sinon erreur lisible.
 *
 * @param array|WP_Error $response Réponse de wp_remote_post().
 * @return true|WP_Error
 */
function nb_base_newsletter_check_response( $response, string $service ) {
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'nb_newsletter_http', $service . ' : ' . $response->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( $code >= 200 && $code < 300 ) {
		return true;
	}
	$data    = json_decode( (string) wp_remote_retrieve_body( $response ), true );
	$message = is_array( $data ) && ! empty( $data['message'] ) ? (string) $data['message'] : '';
	return new WP_Error( 'nb_newsletter_http', trim( $service . ' : HTTP ' . $code . ' ' . sanitize_text_field( $message ) ) );
}

/* -------------------------------------------------------------------------
 * Inscription.
 * ---------------------------------------------------------------------- */

/**
 * Le formulaire envoyé est-il celui de la newsletter ?
 */
function nb_base_newsletter_is_form( array $submission ): bool {
	$form_id = nb_base_newsletter_settings()['formId'];
	return '' !== $form_id && (string) ( $submission['form_id'] ?? '' ) === $form_id;
}

// Formulaire de newsletter : pas d'enregistrement dans les messages (sauf échec, plus bas).
add_filter(
	'nb_base_form_submission',
	static function ( array $submission ): array {
		if ( nb_base_newsletter_is_form( $submission ) ) {
			$submission['store'] = false;
		}
		return $submission;
	}
);

add_action(
	'nb_base_form_submitted',
	static function ( array $submission ) {
		if ( ! nb_base_newsletter_available() || ! nb_base_newsletter_is_form( $submission ) ) {
			return;
		}

		$email = sanitize_email( (string) ( $submission['fields']['email'] ?? '' ) );
		if ( ! is_email( $email ) ) {
			return;
		}

		$settings  = nb_base_newsletter_settings();
		$providers = nb_base_newsletter_providers();
		$provider  = $providers[ $settings['provider'] ] ?? null;
		$result    = ( $provider && is_callable( $provider['subscribe'] ) )
			? call_user_func( $provider['subscribe'], $email, $settings, (array) ( $submission['fields'] ?? array() ) )
			: new WP_Error( 'nb_newsletter_config', __( 'No emailing service set.', 'nb-base' ) );

		if ( true === $result ) {
			return;
		}

		// Échec : inscription gardée dans les messages, erreur notée au journal.
		$message                        = is_wp_error( $result ) ? $result->get_error_message() : __( 'Unknown error.', 'nb-base' );
		$submission['fields']['status'] = __( 'Newsletter sign-up failed, to be added by hand:', 'nb-base' ) . ' ' . $message;
		$submission['kind']             = 'newsletter';
		nb_base_form_store_entry( $submission );
		nb_base_newsletter_log( $message );
	}
);

/**
 * Journal des erreurs (20 dernières, sans adresse e-mail).
 */
function nb_base_newsletter_log( string $message ): void {
	$log = get_option( NB_BASE_NEWSLETTER_LOG, array() );
	$log = is_array( $log ) ? $log : array();
	array_unshift(
		$log,
		array(
			'date'    => time(),
			'message' => sanitize_text_field( $message ),
		)
	);
	update_option( NB_BASE_NEWSLETTER_LOG, array_slice( $log, 0, 20 ), false );
}

/* -------------------------------------------------------------------------
 * Pied de page.
 * ---------------------------------------------------------------------- */

add_filter(
	'nb_base_footer_newsletter',
	static function ( string $html ): string {
		if ( ! nb_base_newsletter_available() || ! nb_base_footer_settings()['showNewsletter'] ) {
			return $html;
		}
		return nb_base_form_html( nb_base_newsletter_settings()['formId'], false );
	}
);

/* -------------------------------------------------------------------------
 * Page NB Base (designer).
 * ---------------------------------------------------------------------- */

/**
 * Réglages Brevo présentés en étapes (ordre de la mise en place dans Brevo),
 * chacune avec ses consignes et son champ.
 *
 * @param array  $s       Réglages.
 * @param string $key_end 4 derniers caractères de la clé enregistrée.
 */
function nb_base_newsletter_brevo_steps_html( array $s, string $key_end ): void {
	$card = 'max-width:52em;margin-top:0;margin-bottom:1em';
	$step = static function ( int $number, string $title ) {
		echo '<h3 class="title" style="margin-top:0">' . esc_html( $number . '. ' . $title ) . '</h3>';
	};

	// Adresse du serveur : publique seulement (celle que Brevo voit, en général).
	$server_ip = isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : '';
	if ( ! filter_var( $server_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
		$server_ip = '';
	}
	$connection = '' !== $s['apiKey'] ? nb_base_newsletter_brevo_attributes( $s['apiKey'] ) : null;
	?>
	<p class="description" style="margin-bottom:1em"><?php esc_html_e( 'Follow the steps in order, in your Brevo account and here.', 'nb-base' ); ?></p>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 1, __( 'Create a list', 'nb-base' ) ); ?>
		<p><?php esc_html_e( 'In Brevo: CRM → Lists → Create a list. Its ID is the number shown next to its name.', 'nb-base' ); ?></p>
		<p>
			<label for="nb-nl-list"><?php esc_html_e( 'Brevo list ID', 'nb-base' ); ?></label>
			<input id="nb-nl-list" class="small-text" type="number" min="0" name="newsletter[listId]" value="<?php echo esc_attr( $s['listId'] ? (string) $s['listId'] : '' ); ?>">
		</p>
	</div>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 2, __( 'Create an API key', 'nb-base' ) ); ?>
		<p>
			<?php esc_html_e( 'In Brevo: profile menu → SMTP & API → API keys → Generate a new API key.', 'nb-base' ); ?>
			<a href="https://app.brevo.com/settings/keys/api" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Brevo', 'nb-base' ); ?></a>
		</p>
		<p><?php esc_html_e( 'Permissions: “Contacts” on “All”, everything else on “None”. The key is shown only once: copy it here.', 'nb-base' ); ?></p>
		<p>
			<label for="nb-nl-key"><?php esc_html_e( 'Brevo API key', 'nb-base' ); ?></label><br>
			<input id="nb-nl-key" class="regular-text" type="password" name="newsletter[apiKey]" value="" autocomplete="off" placeholder="<?php echo esc_attr( $key_end ? '••••••••' . $key_end : '' ); ?>">
			<?php if ( $key_end ) : ?>
				<label><input type="checkbox" name="newsletter[removeKey]" value="1"> <?php esc_html_e( 'Remove the key', 'nb-base' ); ?></label>
			<?php endif; ?>
		</p>
		<p class="description"><?php esc_html_e( 'Leave empty to keep the saved key (never shown again).', 'nb-base' ); ?></p>
	</div>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 3, __( 'Allow the site’s server and check the connection', 'nb-base' ) ); ?>
		<p>
			<?php esc_html_e( 'Brevo refuses unknown IP addresses. In Brevo: Security → Authorised IPs, add the server’s address.', 'nb-base' ); ?>
			<a href="https://app.brevo.com/security/authorised_ips" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Brevo', 'nb-base' ); ?></a>
		</p>
		<?php if ( '' !== $server_ip ) : ?>
			<p>
				<?php
				/* translators: %s: IP address. */
				printf( esc_html__( 'Probable server address: %s. If the error below shows another address, add that one.', 'nb-base' ), '<code>' . esc_html( $server_ip ) . '</code>' );
				?>
			</p>
		<?php endif; ?>
		<p><?php esc_html_e( 'Then save the settings: the connection is checked on save.', 'nb-base' ); ?></p>
		<?php if ( null === $connection ) : ?>
			<p class="description"><?php esc_html_e( 'Enter the API key (step 2) and save to check the connection.', 'nb-base' ); ?></p>
		<?php elseif ( is_wp_error( $connection ) ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( __( 'Connection to Brevo failed:', 'nb-base' ) . ' ' . $connection->get_error_message() ); ?></p></div>
		<?php else : ?>
			<div class="notice notice-success inline"><p><?php esc_html_e( 'Connected to Brevo.', 'nb-base' ); ?></p></div>
		<?php endif; ?>
	</div>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 4, __( 'Double opt-in (recommended)', 'nb-base' ) ); ?>
		<p>
			<input type="hidden" name="newsletter[doubleOptIn]" value="0">
			<label><input type="checkbox" name="newsletter[doubleOptIn]" value="1" <?php checked( $s['doubleOptIn'] ); ?>> <?php esc_html_e( 'The subscriber confirms by clicking a link in an email (recommended).', 'nb-base' ); ?></label>
		</p>
		<p><?php esc_html_e( 'In Brevo: Templates → Create a template, then:', 'nb-base' ); ?></p>
		<ul style="list-style:disc;margin-left:1.5em">
			<li><?php esc_html_e( 'sender: an address of a domain authenticated in Brevo (otherwise the email often ends up in spam);', 'nb-base' ); ?></li>
			<li><?php esc_html_e( 'a confirmation button whose link type is “Double opt-in link”;', 'nb-base' ); ?></li>
			<li><?php esc_html_e( 'advanced settings → Tag: optin;', 'nb-base' ); ?></li>
			<li><?php esc_html_e( 'save and activate the template, then enter its number here.', 'nb-base' ); ?></li>
		</ul>
		<p>
			<label for="nb-nl-doi"><?php esc_html_e( 'Brevo confirmation template ID', 'nb-base' ); ?></label>
			<input id="nb-nl-doi" class="small-text" type="number" min="0" name="newsletter[doiTemplateId]" value="<?php echo esc_attr( $s['doiTemplateId'] ? (string) $s['doiTemplateId'] : '' ); ?>">
		</p>
		<p>
			<label for="nb-nl-redirect"><?php esc_html_e( 'Page after confirmation (optional)', 'nb-base' ); ?></label><br>
			<input id="nb-nl-redirect" class="regular-text" type="url" name="newsletter[doiRedirect]" value="<?php echo esc_attr( $s['doiRedirect'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>">
		</p>
		<p class="description"><?php esc_html_e( 'Home page by default.', 'nb-base' ); ?></p>
	</div>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 5, __( 'Contact attributes (optional)', 'nb-base' ) ); ?>
		<p><?php esc_html_e( 'To send more information to Brevo (e.g. the consent date), create the attributes in Brevo, then choose them here.', 'nb-base' ); ?></p>
		<?php nb_base_newsletter_field_map_html( $s, $connection ); ?>
	</div>

	<div class="card" style="<?php echo esc_attr( $card ); ?>">
		<?php $step( 6, __( 'Test', 'nb-base' ) ); ?>
		<p><?php esc_html_e( 'Save, then sign up from the footer of the site with your own address.', 'nb-base' ); ?></p>
		<ul style="list-style:disc;margin-left:1.5em">
			<li><?php esc_html_e( 'With double opt-in, the contact appears in the list only after the click in the email.', 'nb-base' ); ?></li>
			<li><?php esc_html_e( 'A successful sign-up leaves no trace here; a failure appears in Messages → Newsletter and under “Latest errors” below.', 'nb-base' ); ?></li>
		</ul>
	</div>
	<?php
}

/**
 * Page NB Base : onglet « Newsletter » (fonctionnalité activée).
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		if ( nb_base_feature_enabled( 'newsletter' ) ) {
			$tabs['newsletter'] = array(
				'label'  => __( 'Newsletter', 'nb-base' ),
				'render' => 'nb_base_newsletter_admin_tab',
			);
		}
		return $tabs;
	}
);

/**
 * Onglet : correspondance champs du formulaire → attributs Brevo.
 *
 * Affichée seulement une fois Brevo connecté (liste des attributs lue) ;
 * sinon, correspondances déjà réglées gardées en champs cachés.
 *
 * @param array               $s          Réglages.
 * @param array|WP_Error|null $attributes Attributs lus dans Brevo (null : pas de clé).
 */
function nb_base_newsletter_field_map_html( array $s, $attributes ): void {
	$fields = nb_base_form_fields( $s['formId'] );
	$email  = array_search( 'email', $fields, true );
	if ( false !== $email ) {
		unset( $fields[ $email ] ); // Adresse : toujours envoyée comme e-mail du contact.
	}
	if ( '' === $s['formId'] || ! $fields ) {
		echo '<p class="description">' . esc_html__( 'Choose the sign-up form first. Each of its fields (other than the email address) can then be sent to a Brevo attribute.', 'nb-base' ) . '</p>';
		return;
	}

	if ( ! is_array( $attributes ) || ! $attributes ) {
		echo '<p class="description">' . esc_html(
			is_array( $attributes )
				? __( 'No contact attribute in Brevo yet: create one, then save the settings.', 'nb-base' )
				: __( 'Available once Brevo is connected (step 3).', 'nb-base' )
		) . '</p>';
		foreach ( $s['fieldMap'] as $field => $attribute ) {
			echo '<input type="hidden" name="' . esc_attr( 'newsletter[fieldMap][' . $field . ']' ) . '" value="' . esc_attr( $attribute ) . '">';
		}
		return;
	}
	$types = array(
		'text'    => __( 'text', 'nb-base' ),
		'float'   => __( 'number', 'nb-base' ),
		'date'    => __( 'date', 'nb-base' ),
		'boolean' => __( 'yes / no', 'nb-base' ),
	);
	?>
	<table class="widefat striped" style="max-width:40em">
		<thead><tr><th><?php esc_html_e( 'Form field', 'nb-base' ); ?></th><th><?php esc_html_e( 'Brevo attribute', 'nb-base' ); ?></th></tr></thead>
		<tbody>
		<?php foreach ( $fields as $field => $kind ) : ?>
			<?php
			$id      = 'nb-nl-map-' . sanitize_html_class( $field );
			$current = $s['fieldMap'][ $field ] ?? '';
			?>
			<tr>
				<td><label for="<?php echo esc_attr( $id ); ?>"><code><?php echo esc_html( $field ); ?></code></label> <span class="description">(<?php echo esc_html( $kind ); ?>)</span></td>
				<td>
					<select id="<?php echo esc_attr( $id ); ?>" name="newsletter[fieldMap][<?php echo esc_attr( $field ); ?>]">
						<option value=""><?php esc_html_e( '— Not sent —', 'nb-base' ); ?></option>
						<?php if ( '' !== $current && ! isset( $attributes[ $current ] ) ) : ?>
							<option value="<?php echo esc_attr( $current ); ?>" selected><?php echo esc_html( $current ); ?> (<?php esc_html_e( 'not found in Brevo', 'nb-base' ); ?>)</option>
						<?php endif; ?>
						<?php foreach ( $attributes as $name => $type ) : ?>
							<option value="<?php echo esc_attr( $name ); ?>" <?php selected( $current, $name ); ?>><?php echo esc_html( $name . ' (' . ( $types[ $type ] ?? $type ) . ')' ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="description"><?php esc_html_e( 'The email address is always sent. Consent checkbox: “yes / no” attribute = yes, date or text attribute = sign-up date. Create the attributes in Brevo → Contacts → Settings → Contact attributes (list refreshed when the settings are saved).', 'nb-base' ); ?></p>
	<?php
}

/**
 * Contenu de l'onglet.
 */
function nb_base_newsletter_admin_tab(): void {
	$s       = nb_base_newsletter_settings();
	$forms   = nb_base_form_choices();
	$log     = get_option( NB_BASE_NEWSLETTER_LOG, array() );
	$key_end = '' !== $s['apiKey'] ? substr( $s['apiKey'], -4 ) : '';
	?>
	<?php if ( ! nb_base_feature_enabled( 'forms' ) || ! nb_base_forms_plugin_active() ) : ?>
		<div class="notice notice-warning inline"><p><?php esc_html_e( 'The newsletter requires the Forms feature and the Contact Form 7 plugin.', 'nb-base' ); ?></p></div>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_newsletter">
		<?php wp_nonce_field( 'nb_base_save_newsletter' ); ?>
		<table class="form-table" role="presentation"><tbody>
			<tr>
				<th scope="row"><label for="nb-nl-form"><?php esc_html_e( 'Sign-up form', 'nb-base' ); ?></label></th>
				<td>
					<select id="nb-nl-form" name="newsletter[formId]">
						<option value=""><?php esc_html_e( '— Choose —', 'nb-base' ); ?></option>
						<?php foreach ( $forms as $id => $title ) : ?>
							<option value="<?php echo esc_attr( (string) $id ); ?>" <?php selected( $s['formId'], (string) $id ); ?>><?php echo esc_html( $title ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php if ( nb_base_newsletter_available() ) : ?>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nb_base_create_newsletter_form' ), 'nb_base_create_newsletter_form' ) ); ?>"><?php esc_html_e( 'Create the newsletter form', 'nb-base' ); ?></a>
					<?php endif; ?>
					<p class="description"><?php esc_html_e( 'Created from the theme model: email, consent checkbox, button; no notification email. Its texts can be changed in Contact → Contact forms.', 'nb-base' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nb-nl-provider"><?php esc_html_e( 'Emailing service', 'nb-base' ); ?></label></th>
				<td>
					<select id="nb-nl-provider" name="newsletter[provider]">
						<?php foreach ( nb_base_newsletter_providers() as $id => $provider ) : ?>
							<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $s['provider'], $id ); ?>><?php echo esc_html( $provider['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr data-nb-nl-provider="brevo">
				<td colspan="2" style="padding-left:0">
					<?php nb_base_newsletter_brevo_steps_html( $s, $key_end ); ?>
				</td>
			</tr>
			<tr data-nb-nl-provider="webhook">
				<th scope="row"><label for="nb-nl-webhook"><?php esc_html_e( 'Webhook address', 'nb-base' ); ?></label></th>
				<td>
					<input id="nb-nl-webhook" class="regular-text" type="url" name="newsletter[webhookUrl]" value="<?php echo esc_attr( $s['webhookUrl'] ); ?>" placeholder="https://">
					<p class="description"><?php esc_html_e( 'Webhook service only. Receives in JSON (POST): event, email, consent, site, date, fields (every form field).', 'nb-base' ); ?></p>
				</td>
			</tr>
		</tbody></table>
		<?php submit_button( __( 'Save newsletter settings', 'nb-base' ) ); ?>
	</form>
	<?php
	// Réglages propres à un service : affichés seulement quand il est choisi
	// (sans JavaScript, tout reste affiché ; les valeurs masquées sont gardées).
	wp_print_inline_script_tag(
		"( () => { const select = document.getElementById( 'nb-nl-provider' ); if ( ! select ) { return; } const update = () => document.querySelectorAll( '[data-nb-nl-provider]' ).forEach( ( row ) => { row.hidden = row.dataset.nbNlProvider !== select.value; } ); select.addEventListener( 'change', update ); update(); } )();"
	);
	?>
	<?php if ( is_array( $log ) && $log ) : ?>
		<h3><?php esc_html_e( 'Latest errors', 'nb-base' ); ?></h3>
		<p class="description"><?php esc_html_e( 'The failed sign-ups are in Messages → Newsletter, to be added by hand.', 'nb-base' ); ?></p>
		<ul>
			<?php foreach ( $log as $entry ) : ?>
				<li><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $entry['date'] ) . ' — ' . $entry['message'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php
}

add_action(
	'admin_post_nb_base_save_newsletter',
	static function () {
		nb_base_admin_guard( 'nb_base_save_newsletter' );
		$input    = isset( $_POST['newsletter'] ) && is_array( $_POST['newsletter'] ) ? wp_unslash( $_POST['newsletter'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$previous = nb_base_newsletter_settings();

		// Clé : champ vide = clé enregistrée conservée.
		if ( ! empty( $input['removeKey'] ) ) {
			$input['apiKey'] = '';
		} elseif ( '' === trim( (string) ( $input['apiKey'] ?? '' ) ) ) {
			$input['apiKey'] = $previous['apiKey'];
		}
		$input['doubleOptIn'] = ! empty( $input['doubleOptIn'] );

		update_option( NB_BASE_NEWSLETTER_OPTION, nb_base_sanitize_newsletter( $input ), false );
		$saved = nb_base_newsletter_settings();
		if ( 'brevo' === $saved['provider'] && '' !== $saved['apiKey'] ) {
			nb_base_newsletter_brevo_attributes( $saved['apiKey'], true ); // Liste des attributs rafraîchie.
		}
		nb_base_admin_redirect( 'newsletter-saved', 'newsletter' );
	}
);

add_action(
	'admin_post_nb_base_create_newsletter_form',
	static function () {
		nb_base_admin_guard( 'nb_base_create_newsletter_form' );
		$id = (string) apply_filters( 'nb_base_newsletter_create_form', '' );
		if ( '' !== $id ) {
			$settings           = nb_base_newsletter_settings();
			$settings['formId'] = $id;
			update_option( NB_BASE_NEWSLETTER_OPTION, $settings, false );
		}
		nb_base_admin_redirect( '' !== $id ? 'newsletter-form-created' : 'newsletter-form-error', 'newsletter' );
	}
);
