<?php
/**
 * Administration : colonne de gauche rangée et articles (blog) activables.
 *
 * Articles : fonctionnalité « posts » (désactivée par défaut). Désactivée, le
 * type natif « post » reste enregistré (articles existants toujours en ligne)
 * mais disparaît de l'administration : menu, bouton « Créer », menus du site
 * (réglages du type modifiés par le filtre public register_post_type_args).
 *
 * Ordre du menu (filtres publics custom_menu_order / menu_order) :
 *   Tableau de bord, Établissement, Messages
 *   — séparateur —
 *   Pages, types de contenu structurés actifs (Réalisations, Produits…),
 *   Articles (si actifs), Médias
 *   — séparateur —
 *   Apparence, menu de l'extension de formulaires (filtre
 *   nb_base_forms_menu_slugs, fourni par l'adaptateur), NB Base, Extensions,
 *   Comptes, Outils, Réglages ; puis tout autre menu (extensions), dans son
 *   ordre d'origine.
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['posts'] = array(
			'group'       => 'content',
			'label'       => __( 'Posts (blog)', 'nb-base' ),
			'description' => __( 'WordPress posts, categories and tags in the administration. Disabled: existing posts stay online but are hidden from the administration.', 'nb-base' ),
			'default'     => false,
		);
		return $features;
	}
);

add_filter(
	'register_post_type_args',
	static function ( array $args, string $post_type ): array {
		if ( 'post' !== $post_type || ! function_exists( 'nb_base_feature_enabled' ) || nb_base_feature_enabled( 'posts' ) ) {
			return $args;
		}
		$args['show_ui']           = false;
		$args['show_in_menu']      = false;
		$args['show_in_admin_bar'] = false;
		$args['show_in_nav_menus'] = false;
		return $args;
	},
	10,
	2
);

// Articles désactivés : leurs anciennes adresses d'administration renvoient
// au tableau de bord (au lieu d'un message d'erreur).
foreach ( array( 'load-edit.php', 'load-post-new.php', 'load-edit-tags.php' ) as $nb_hook ) {
	add_action(
		$nb_hook,
		static function () {
			$screen = get_current_screen();
			$posts  = $screen && ( 'post' === $screen->post_type || in_array( $screen->taxonomy, array( 'category', 'post_tag' ), true ) );
			if ( $posts && ! nb_base_feature_enabled( 'posts' ) ) {
				wp_safe_redirect( admin_url() );
				exit;
			}
		}
	);
}
unset( $nb_hook );

add_filter( 'custom_menu_order', '__return_true' );

add_filter(
	'menu_order',
	static function ( $order ) {
		if ( ! is_array( $order ) ) {
			return $order;
		}
		$types = array();
		foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $type ) {
			if ( $type->show_in_menu && function_exists( 'nb_base_entry_settings' ) && nb_base_entry_settings( $type->name ) ) {
				$types[] = 'edit.php?post_type=' . $type->name;
			}
		}
		$wanted = array_merge(
			array( 'index.php', 'nb-base-business', 'edit.php?post_type=nb_form_entry', 'separator1', 'edit.php?post_type=page' ),
			$types,
			array( 'edit.php', 'upload.php', 'separator2', 'themes.php' ),
			// Menu de l'extension de formulaires (fourni par son adaptateur).
			array_map( 'strval', (array) apply_filters( 'nb_base_forms_menu_slugs', array() ) ),
			array( 'nb-base', 'plugins.php', 'users.php', 'tools.php', 'options-general.php' )
		);
		// Seulement les menus présents pour ce compte ; les autres à la suite.
		$sorted = array_values( array_intersect( $wanted, $order ) );
		return array_merge( $sorted, array_values( array_diff( $order, $sorted ) ) );
	}
);

/**
 * Accès du client : écrans réservés au designer, ouvrables site par site dans
 * NB Base → Fonctionnalités (groupe « Client access ») : fermés par défaut,
 * sauf Contact (ouvert par défaut : le client y règle l'e-mail destinataire).
 * Export et effacement des données personnelles (Outils) : toujours ouverts
 * (demandes RGPD traitées par le client, responsable des données).
 * Fermé, un administrateur non designer (client, partenaire) ne voit pas le
 * menu ; une adresse saisie directement renvoie au tableau de bord (Thèmes :
 * à Menus, cible du menu Apparence). Les pages d'extensions rangées dans ces
 * menus (?page=…) ne sont pas bloquées, seulement masquées. Les droits natifs
 * (manage_options…) ne sont pas retirés : l'API REST des réglages du site
 * (en-tête, pied de page, établissement) en dépend.
 * Formulaires (menu Contact) : droits de l'extension, inc/forms-cf7.php.
 */
add_filter(
	'nb_base_feature_groups',
	static function ( array $groups ): array {
		$groups['client'] = __( 'Client access', 'nb-base' );
		return $groups;
	}
);

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$access = array(
			'client_settings' => array( __( 'Settings menu', 'nb-base' ), __( 'Settings (site title, administration email, reading, permalinks, privacy…) visible to administrators who are not the designer.', 'nb-base' ) ),
			'client_tools'    => array( __( 'Tools menu', 'nb-base' ), __( 'Tools (import, export, site health) visible to administrators who are not the designer. Export and erasure of personal data always remain available.', 'nb-base' ) ),
			'client_themes'   => array( __( 'Appearance → Themes', 'nb-base' ), __( 'Themes screen (change or install a theme) visible to administrators who are not the designer.', 'nb-base' ) ),
			'client_fonts'    => array( __( 'Appearance → Fonts', 'nb-base' ), __( 'Font library visible to administrators who are not the designer.', 'nb-base' ) ),
			'client_users'    => array( __( 'Account creation', 'nb-base' ), __( 'Administrators who are not the designer can create accounts for collaborators (any role except administrator). Existing accounts remain manageable either way.', 'nb-base' ) ),
			'client_forms'    => array( __( 'Forms menu (Contact)', 'nb-base' ), __( 'Administrators who are not the designer can edit existing forms (fields, texts, recipient email). Creating, duplicating and deleting forms remain reserved to the designer.', 'nb-base' ) ),
		);
		foreach ( $access as $slug => $texts ) {
			$features[ $slug ] = array(
				'group'       => 'client',
				'label'       => $texts[0],
				'description' => $texts[1],
				// Tous fermés par défaut (Contact compris, depuis la 0.5.6 : un site
				// qui n'a jamais enregistré ce réglage voit Contact se fermer).
				'default'     => false,
			);
		}
		return $features;
	}
);

/**
 * L'utilisateur courant a-t-il accès à cet écran réservé ?
 *
 * @param string $access Fonctionnalité d'accès (client_settings, client_tools…).
 */
function nb_base_client_access( string $access ): bool {
	return nb_base_is_designer() || nb_base_feature_enabled( $access );
}

add_action(
	'admin_menu',
	static function () {
		if ( ! nb_base_client_access( 'client_settings' ) ) {
			remove_menu_page( 'options-general.php' );
		}
		// Outils fermé : seuls restent l'export et l'effacement des données
		// personnelles ; le lien du menu (tools.php) renvoie au premier.
		if ( ! nb_base_client_access( 'client_tools' ) ) {
			foreach ( array( 'tools.php', 'import.php', 'export.php', 'site-health.php', 'theme-editor.php', 'plugin-editor.php' ) as $slug ) {
				remove_submenu_page( 'tools.php', $slug );
			}
		}
		// Le lien du menu Apparence reste themes.php (fixé par WordPress avant
		// ce filtre) : l'écran renvoie alors à Menus (voir plus bas).
		if ( ! nb_base_client_access( 'client_themes' ) ) {
			remove_submenu_page( 'themes.php', 'themes.php' );
		}
		if ( ! nb_base_client_access( 'client_fonts' ) ) {
			remove_submenu_page( 'themes.php', 'font-library.php' );
		}
	},
	999
);

foreach ( array(
	'client_settings' => array( 'options-general.php', 'options-writing.php', 'options-reading.php', 'options-media.php', 'options-permalink.php', 'options-privacy.php', 'options-connectors.php' ),
	'client_tools'    => array( 'tools.php', 'import.php', 'export.php', 'site-health.php' ),
	'client_themes'   => array( 'themes.php', 'theme-install.php' ),
	'client_fonts'    => array( 'font-library.php' ),
) as $nb_access => $nb_screens ) {
	foreach ( $nb_screens as $nb_screen ) {
		add_action(
			'load-' . $nb_screen,
			static function () use ( $nb_access, $nb_screen ) {
				if ( nb_base_client_access( $nb_access ) ) {
					return;
				}
				// Cibles des menus Apparence et Outils : renvoyées au premier sous-menu restant.
				$target = admin_url();
				if ( 'themes.php' === $nb_screen && current_user_can( 'edit_theme_options' ) ) {
					$target = admin_url( 'nav-menus.php' );
				} elseif ( 'tools.php' === $nb_screen && current_user_can( 'export_others_personal_data' ) ) {
					$target = admin_url( 'export-personal-data.php' );
				}
				wp_safe_redirect( $target );
				exit;
			}
		);
	}
}
unset( $nb_access, $nb_screens, $nb_screen );
