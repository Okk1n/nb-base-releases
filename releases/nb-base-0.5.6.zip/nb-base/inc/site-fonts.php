<?php
/**
 * Polices du site : chaque site a les siennes, installées par le designer dans
 * la bibliothèque de polices native (Apparence → Polices), jamais dans le thème.
 *
 * Le thème définit deux variables, « title » et « text »
 * (--wp--preset--font-family--title / --text, Inter par défaut), utilisées par
 * tous ses blocs. En préprod (voir README « Nouveau site »), Claude les relie à
 * une police installée avec nb_base_save_site_fonts() — pas de champ
 * d'administration (règle : la charte ne se règle pas en production) :
 * les styles du site (couche « custom » des styles globaux) redéfinissent ces
 * deux variables, qui l'emportent alors sur celles du thème. La police choisie
 * est aussi activée (même entrée que celle qu'écrit la bibliothèque de polices),
 * pour que WordPress imprime ses @font-face.
 *
 * Uniquement l'API REST publique (font-families, global-styles).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Variables de police du thème : slug => libellé.
 *
 * @return array<string, string>
 */
function nb_base_font_roles(): array {
	return array(
		'title' => __( 'Title font', 'nb-base' ),
		'text'  => __( 'Text font', 'nb-base' ),
	);
}

/**
 * Familles de secours, affichées tant que la police du site n'est pas chargée
 * (et si elle ne l'est pas) : famille générique => polices système.
 * À choisir selon le style de la police du site (une police à empattements
 * prend « serif », sinon le navigateur afficherait une police sans
 * empattements pendant le chargement, et inversement).
 *
 * @return array<string, string>
 */
function nb_base_font_fallbacks(): array {
	return array(
		'sans-serif' => 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
		'serif'      => 'Georgia, "Times New Roman", Times, serif',
		'monospace'  => 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
		'cursive'    => 'cursive',
	);
}

/**
 * Première famille d'une liste CSS (« "Lora", serif » → Lora).
 */
function nb_base_font_primary_family( string $font_family ): string {
	$first = explode( ',', $font_family )[0];
	return trim( $first, " \t\n\r\0\x0B\"'" );
}

/**
 * Famille générique de secours d'une liste CSS (dernière reconnue), ou vide.
 */
function nb_base_font_generic( string $font_family ): string {
	$generic = '';
	foreach ( array_slice( explode( ',', $font_family ), 1 ) as $item ) {
		$item = strtolower( trim( $item, " \t\n\r\0\x0B\"'" ) );
		if ( isset( nb_base_font_fallbacks()[ $item ] ) ) {
			$generic = $item;
		}
	}
	return $generic;
}

/**
 * Valeur de variable : police du site puis polices de secours.
 */
function nb_base_font_stack( string $font_family, string $fallback ): string {
	$stacks = nb_base_font_fallbacks();
	return '"' . str_replace( '"', '', nb_base_font_primary_family( $font_family ) ) . '", ' . ( $stacks[ $fallback ] ?? $stacks['sans-serif'] );
}

/**
 * Polices installées dans la bibliothèque, par identifiant.
 *
 * @return array<int, array{name: string, slug: string, fontFamily: string, fontFace: array}>
 */
function nb_base_installed_fonts(): array {
	$request = new WP_REST_Request( 'GET', '/wp/v2/font-families' );
	$request->set_param( 'per_page', 100 );
	$response = rest_do_request( $request );
	if ( $response->is_error() ) {
		return array();
	}
	$fonts = array();
	foreach ( (array) $response->get_data() as $family ) {
		$settings = (array) ( $family['font_family_settings'] ?? array() );
		$id       = (int) ( $family['id'] ?? 0 );
		$slug     = sanitize_title( (string) ( $settings['slug'] ?? '' ) );
		if ( ! $id || '' === $slug || isset( nb_base_font_roles()[ $slug ] ) || empty( $settings['fontFamily'] ) ) {
			continue;
		}
		$faces    = array();
		$response = rest_do_request( new WP_REST_Request( 'GET', '/wp/v2/font-families/' . $id . '/font-faces' ) );
		if ( ! $response->is_error() ) {
			foreach ( (array) $response->get_data() as $face ) {
				if ( ! empty( $face['font_face_settings'] ) ) {
					$faces[] = (array) $face['font_face_settings'];
				}
			}
		}
		$fonts[ $id ] = array(
			'name'       => (string) ( $settings['name'] ?? $slug ),
			'slug'       => $slug,
			'fontFamily' => (string) $settings['fontFamily'],
			'fontFace'   => $faces,
		);
	}
	uasort( $fonts, static fn( $a, $b ) => strcasecmp( $a['name'], $b['name'] ) );
	return $fonts;
}

/**
 * Styles du site en tableaux (l'export renvoie des objets vides).
 *
 * @return array|WP_Error
 */
function nb_base_site_styles() {
	$styles = nb_base_export_styles();
	return is_wp_error( $styles ) ? $styles : (array) json_decode( (string) wp_json_encode( $styles ), true );
}

/**
 * Polices personnalisées des styles du site (liste « custom »).
 */
function nb_base_custom_font_families( array $styles ): array {
	$custom = $styles['settings']['typography']['fontFamilies']['custom'] ?? array();
	return is_array( $custom ) ? array_values( $custom ) : array();
}

/**
 * Police actuellement reliée à chaque variable : slug => identifiant de la
 * police installée (0 = police du thème).
 *
 * @return array<string, int>
 */
function nb_base_current_site_fonts( ?array $fonts = null ): array {
	$fonts   = $fonts ?? nb_base_installed_fonts();
	$current = array_fill_keys( array_keys( nb_base_font_roles() ), 0 );
	$styles  = nb_base_site_styles();
	if ( is_wp_error( $styles ) ) {
		return $current;
	}
	foreach ( nb_base_custom_font_families( $styles ) as $entry ) {
		$slug = (string) ( $entry['slug'] ?? '' );
		if ( ! isset( $current[ $slug ] ) ) {
			continue;
		}
		foreach ( $fonts as $id => $font ) {
			// Comparaison sur la police elle-même (la variable ajoute les polices de secours).
			if ( nb_base_font_primary_family( (string) ( $entry['fontFamily'] ?? '' ) ) === nb_base_font_primary_family( $font['fontFamily'] ) ) {
				$current[ $slug ] = $id;
			}
		}
	}
	return $current;
}

/**
 * Famille de secours actuelle de chaque variable (vide : police du thème).
 *
 * @return array<string, string>
 */
function nb_base_current_font_fallbacks(): array {
	$current = array_fill_keys( array_keys( nb_base_font_roles() ), '' );
	$styles  = nb_base_site_styles();
	if ( is_wp_error( $styles ) ) {
		return $current;
	}
	foreach ( nb_base_custom_font_families( $styles ) as $entry ) {
		$slug = (string) ( $entry['slug'] ?? '' );
		if ( isset( $current[ $slug ] ) ) {
			$current[ $slug ] = nb_base_font_generic( (string) ( $entry['fontFamily'] ?? '' ) ) ?: 'sans-serif';
		}
	}
	return $current;
}

/**
 * Espacement des lettres des titres : valeur CSS acceptée (« -0.04em »,
 * « 0.5px », « normal »), sinon chaîne vide.
 */
function nb_base_sanitize_letter_spacing( string $value ): string {
	$value = strtolower( trim( $value ) );
	return preg_match( '/^(normal|0|-?(\d+\.?\d*|\.\d+)(em|rem|px))$/', $value ) ? $value : '';
}

/**
 * Espacement des lettres des titres propre au site (vide = valeur du thème).
 * Réglé en préprod (styles.json ou nb_base_save_site_fonts()), jamais par un
 * champ d'administration : voir README « Nouveau site ».
 */
function nb_base_current_title_letter_spacing(): string {
	$styles = nb_base_site_styles();
	return is_wp_error( $styles ) ? '' : nb_base_sanitize_letter_spacing( (string) ( $styles['settings']['custom']['letterSpacing']['title'] ?? '' ) );
}

/**
 * Relie les variables du thème aux polices choisies (0 = police du thème) et
 * règle l'espacement des lettres des titres (variable custom.letterSpacing.title,
 * utilisée par tous les titres du thème ; null = inchangé, vide = valeur du thème).
 *
 * @param array<string, int>    $choice         slug de variable => identifiant de police installée
 *                                             (variable absente : inchangée).
 * @param string|null           $letter_spacing Espacement des lettres des titres.
 * @param array<string, string> $fallbacks      slug de variable => famille de secours
 *                                             (nb_base_font_fallbacks() : sans-serif, serif,
 *                                             monospace, cursive) ; absente : celle déclarée
 *                                             par la police dans la bibliothèque, sinon sans-serif.
 * @return true|WP_Error
 */
function nb_base_save_site_fonts( array $choice, ?string $letter_spacing = null, array $fallbacks = array() ) {
	foreach ( $fallbacks as $fallback ) {
		if ( ! isset( nb_base_font_fallbacks()[ $fallback ] ) ) {
			return new WP_Error( 'nb_base_font_fallback', __( 'Unknown fallback font family.', 'nb-base' ) );
		}
	}
	$styles = nb_base_site_styles();
	if ( is_wp_error( $styles ) ) {
		return $styles;
	}
	$fonts  = nb_base_installed_fonts();
	// Variables absentes de $choice : inchangées.
	$roles  = array_intersect_key( nb_base_font_roles(), $choice );
	$custom = array_values(
		array_filter(
			nb_base_custom_font_families( $styles ),
			static fn( $entry ) => ! isset( $roles[ (string) ( $entry['slug'] ?? '' ) ] )
		)
	);

	foreach ( array_keys( $roles ) as $role ) {
		$id = (int) ( $choice[ $role ] ?? 0 );
		if ( ! $id ) {
			continue;
		}
		if ( ! isset( $fonts[ $id ] ) ) {
			return new WP_Error( 'nb_base_font_unknown', __( 'This font is not installed.', 'nb-base' ) );
		}
		$font = $fonts[ $id ];
		// Activation (comme la bibliothèque de polices) : imprime ses @font-face.
		if ( ! in_array( $font['slug'], array_column( $custom, 'slug' ), true ) ) {
			$custom[] = array_filter(
				array(
					'name'       => $font['name'],
					'slug'       => $font['slug'],
					'fontFamily' => $font['fontFamily'],
					'fontFace'   => $font['fontFace'],
				)
			);
		}
		// Variable du thème redéfinie (même nom que dans theme.json), avec ses
		// polices de secours.
		$fallback = $fallbacks[ $role ] ?? ( nb_base_font_generic( $font['fontFamily'] ) ?: 'sans-serif' );
		$custom[] = array(
			'name'       => 'font-' . $role,
			'slug'       => $role,
			'fontFamily' => nb_base_font_stack( $font['fontFamily'], $fallback ),
		);
	}

	$settings = (array) ( $styles['settings'] ?? array() );
	if ( $custom ) {
		$settings['typography']['fontFamilies']['custom'] = $custom;
	} else {
		unset( $settings['typography']['fontFamilies']['custom'] );
		if ( empty( $settings['typography']['fontFamilies'] ) ) {
			unset( $settings['typography']['fontFamilies'] );
		}
		if ( empty( $settings['typography'] ) ) {
			unset( $settings['typography'] );
		}
	}
	if ( null !== $letter_spacing ) {
		$letter_spacing = nb_base_sanitize_letter_spacing( $letter_spacing );
		if ( '' !== $letter_spacing ) {
			$settings['custom']['letterSpacing']['title'] = $letter_spacing;
		} else {
			unset( $settings['custom']['letterSpacing']['title'] );
			if ( empty( $settings['custom']['letterSpacing'] ) ) {
				unset( $settings['custom']['letterSpacing'] );
			}
			if ( isset( $settings['custom'] ) && empty( $settings['custom'] ) ) {
				unset( $settings['custom'] );
			}
		}
	}
	$styles['settings'] = $settings;

	return nb_base_import_styles( $styles );
}

/**
 * Sites réglés avant les polices de secours (variable sans famille générique) :
 * polices système sans empattements ajoutées à l'affichage, sans modifier
 * la base. Réglage propre au site : nb_base_save_site_fonts( …, $fallbacks ).
 */
add_filter(
	'wp_theme_json_data_user',
	static function ( $theme_json ) {
		$data   = $theme_json->get_data();
		$custom = $data['settings']['typography']['fontFamilies']['custom'] ?? null;
		if ( ! is_array( $custom ) ) {
			return $theme_json;
		}
		$changed = false;
		foreach ( $custom as $i => $entry ) {
			$family = (string) ( $entry['fontFamily'] ?? '' );
			// Slugs écrits ici : les libellés traduits de nb_base_font_roles() seraient chargés trop tôt.
			if ( in_array( (string) ( $entry['slug'] ?? '' ), array( 'title', 'text' ), true ) && '' !== $family && '' === nb_base_font_generic( $family ) ) {
				$custom[ $i ]['fontFamily'] = nb_base_font_stack( $family, 'sans-serif' );
				$changed                    = true;
			}
		}
		if ( ! $changed ) {
			return $theme_json;
		}
		$data['settings']['typography']['fontFamilies']['custom'] = $custom;
		return $theme_json->update_with( $data );
	}
);
