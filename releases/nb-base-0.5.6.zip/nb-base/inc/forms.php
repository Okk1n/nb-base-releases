<?php
/**
 * Formulaires : partie neutre, indépendante de l'extension de formulaire.
 *
 * Principe : l'extension (Contact Form 7 aujourd'hui) n'est connue que de son
 * adaptateur (inc/forms-cf7.php). L'adaptateur traduit chaque envoi en un
 * « envoi normalisé » et le passe à nb_base_form_handle_submission(). Tout le
 * reste du thème (messages reçus, fichiers, newsletter…) ne connaît que ce
 * format. Changer d'extension = écrire un nouvel adaptateur.
 *
 * Envoi normalisé (tableau) :
 *  - source     : identifiant de l'extension ('cf7')
 *  - form_id    : identifiant du formulaire dans l'extension (chaîne)
 *  - form_title : nom du formulaire
 *  - fields     : nom du champ => valeur (texte ; listes jointes par des virgules)
 *  - files      : nom du champ => chemins des fichiers envoyés (déjà vérifiés
 *                 par l'extension, encore présents sur le disque)
 *  - mail_sent  : l'e-mail de notification est-il parti ?
 *  - store      : enregistrer l'envoi (false si le formulaire le refuse)
 *
 * Messages reçus : type de contenu « nb_form_entry », non public, absent de
 * l'API REST, consultable (lecture seule) par les administrateurs. Fichiers
 * joints copiés hors de portée publique (uploads/nb-base-forms/<dossier
 * aléatoire>/), servis uniquement aux comptes autorisés. Conservation limitée
 * (6 mois par défaut, réglable sur la page NB Base), suppression automatique.
 *
 * Affichage : bloc de section nb-base/contact-form (colonne de gauche :
 * en-tête, coordonnées, note Google ; à droite : formulaire), formulaire
 * rendu par le bloc nb-base/form (hors inserteur, réutilisable).
 * nb_base_form_html() : HTML d'un formulaire (fourni par l'adaptateur) suivi
 * de la mention d'information RGPD (générée : nom du site, durée de
 * conservation, page de confidentialité).
 * Textes de la section (surtitre, titre, texte) : communs au site par défaut
 * (nb_base_contact_section()), propres à un bloc si son réglage « Texte
 * commun » est coupé.
 * Choix des listes déroulantes « Type de demande » : option du site
 * « nb_base_request_types », modifiable par le client depuis le bloc.
 *
 * Types de fichiers acceptés et taille maximale : nb_base_form_file_types(),
 * nb_base_form_max_file_size() (imposés à tous les champs fichier par
 * l'adaptateur, rappelés dans la légende du champ).
 *
 * @package nb-base
 */

defined( 'ABSPATH' ) || exit;

const NB_BASE_FORM_ENTRY_TYPE = 'nb_form_entry';
const NB_BASE_FORMS_OPTION    = 'nb_base_forms';
const NB_BASE_FORMS_DIR       = 'nb-base-forms';

add_filter(
	'nb_base_features',
	static function ( array $features ): array {
		$features['forms'] = array(
			'group'       => 'forms',
			'label'       => __( 'Forms', 'nb-base' ),
			'description' => __( 'Forms (requires the Contact Form 7 plugin): received messages and attached files stored in the administration, accepted file types and size enforced, limited retention.', 'nb-base' ),
			'default'     => false,
			'blocks'      => array( 'nb-base/contact-form' ),
		);
		return $features;
	}
);

/* -------------------------------------------------------------------------
 * Fichiers acceptés.
 * ---------------------------------------------------------------------- */

/**
 * Types de fichiers acceptés : extensions (séparées par |) => type MIME.
 * La première extension de chaque ligne est celle affichée dans la légende.
 *
 * Exclus volontairement : SVG et HTML (peuvent contenir du code), archives
 * (ZIP, RAR : contenu invérifiable), anciens formats Office DOC / XLS (macros),
 * RTF, exécutables.
 *
 * @return array<string, string>
 */
function nb_base_form_file_types_available(): array {
	return array(
		'jpg|jpeg|jpe' => 'image/jpeg',
		'png'          => 'image/png',
		'webp'         => 'image/webp',
		'heic'         => 'image/heic',
		'pdf'          => 'application/pdf',
		'docx'         => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'odt'          => 'application/vnd.oasis.opendocument.text',
		'xlsx'         => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'ods'          => 'application/vnd.oasis.opendocument.spreadsheet',
		'txt'          => 'text/plain',
	);
}

/**
 * Types de fichiers acceptés sur ce site : ceux cochés par le designer
 * (onglet Formulaires), tous par défaut.
 *
 * @return array<string, string>
 */
function nb_base_form_file_types(): array {
	$types = array_intersect_key(
		nb_base_form_file_types_available(),
		array_flip( nb_base_forms_settings()['fileTypes'] )
	);

	/**
	 * Liste modifiable (même format).
	 */
	return (array) apply_filters( 'nb_base_form_file_types', $types );
}

/**
 * Toutes les extensions acceptées.
 *
 * @return string[]
 */
function nb_base_form_file_extensions(): array {
	$extensions = array();
	foreach ( array_keys( nb_base_form_file_types() ) as $key ) {
		$extensions = array_merge( $extensions, explode( '|', $key ) );
	}
	return $extensions;
}

/**
 * Taille maximale d'un fichier, en octets : réglage du designer (onglet
 * Formulaires), 10 Mo par défaut (une photo de téléphone fait 2 à 8 Mo).
 */
function nb_base_form_max_file_size(): int {
	return max( 1, (int) apply_filters( 'nb_base_form_max_file_size', nb_base_forms_settings()['maxSize'] * MB_IN_BYTES ) );
}

/**
 * Taille maximale réglable, en Mo : limite d'envoi du serveur (PHP), au plus 100.
 */
function nb_base_form_max_file_size_limit(): int {
	return max( 1, min( 100, (int) floor( wp_max_upload_size() / MB_IN_BYTES ) ) );
}

/**
 * Légende du champ fichier : formats acceptés et taille maximale.
 */
function nb_base_form_file_legend(): string {
	$labels = array();
	foreach ( array_keys( nb_base_form_file_types() ) as $key ) {
		$labels[] = strtoupper( strtok( $key, '|' ) );
	}

	return sprintf(
		/* translators: 1: list of file formats, 2: maximum size (e.g. 10 MB). */
		__( 'Accepted formats: %1$s. Maximum size: %2$s per file.', 'nb-base' ),
		implode( ', ', $labels ),
		size_format( nb_base_form_max_file_size() )
	);
}

/**
 * Vérifie le contenu réel d'un fichier (pas seulement son extension) :
 * le type détecté doit correspondre à l'extension et faire partie de la liste.
 *
 * @param string $path     Chemin du fichier.
 * @param string $filename Nom du fichier (extension d'origine).
 * @return string|false Type MIME reconnu, ou false si refusé.
 */
function nb_base_form_check_file( string $path, string $filename ) {
	if ( ! is_file( $path ) || filesize( $path ) > nb_base_form_max_file_size() ) {
		return false;
	}

	$check = wp_check_filetype_and_ext( $path, $filename, nb_base_form_file_types() );
	if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
		return false;
	}

	// Le nom corrigé éventuel doit garder la même extension.
	if ( ! empty( $check['proper_filename'] ) ) {
		return false;
	}

	return $check['type'];
}

/* -------------------------------------------------------------------------
 * Réglages (page NB Base, designer).
 * ---------------------------------------------------------------------- */

/**
 * Durées de conservation proposées : mois => libellé.
 *
 * @return array<int, string>
 */
function nb_base_forms_retention_labels(): array {
	return array(
		1  => __( '1 month', 'nb-base' ),
		3  => __( '3 months', 'nb-base' ),
		6  => __( '6 months', 'nb-base' ),
		12 => __( '12 months', 'nb-base' ),
		24 => __( '24 months', 'nb-base' ),
	);
}

/**
 * Durées de conservation proposées (mois).
 *
 * @return int[]
 */
function nb_base_forms_retention_choices(): array {
	return array_keys( nb_base_forms_retention_labels() );
}

/**
 * Champs d'un formulaire (fournis par l'adaptateur) : nom => type
 * (« text », « email », « acceptance », « checkbox »…).
 *
 * @return array<string, string>
 */
function nb_base_form_fields( string $form_id ): array {
	if ( '' === $form_id ) {
		return array();
	}
	return array_map( 'strval', (array) apply_filters( 'nb_base_form_fields', array(), $form_id ) );
}

/**
 * Réglages des formulaires (nettoyés).
 *
 * - retention : durée de conservation des messages (mois) ;
 * - fileTypes : formats acceptés (clés de nb_base_form_file_types_available()) ;
 *   tous par défaut, et tous si aucun n'est coché ;
 * - maxSize : taille maximale d'un fichier (Mo), 10 par défaut.
 *
 * @param array|null $value Valeur à nettoyer (null : réglages enregistrés).
 * @return array{retention: int, fileTypes: string[], maxSize: int}
 */
function nb_base_forms_settings( ?array $value = null ): array {
	if ( null === $value ) {
		$value = get_option( NB_BASE_FORMS_OPTION, array() );
		$value = is_array( $value ) ? $value : array();
	}
	$retention = isset( $value['retention'] ) ? (int) $value['retention'] : 6;
	$available = array_keys( nb_base_form_file_types_available() );
	$types     = isset( $value['fileTypes'] ) && is_array( $value['fileTypes'] )
		? array_values( array_intersect( $available, array_map( 'strval', $value['fileTypes'] ) ) )
		: array();
	$max_size  = isset( $value['maxSize'] ) ? (int) $value['maxSize'] : 10;

	return array(
		'retention' => in_array( $retention, nb_base_forms_retention_choices(), true ) ? $retention : 6,
		'fileTypes' => $types ? $types : $available,
		'maxSize'   => max( 1, min( 100, $max_size ) ),
	);
}

/**
 * Page NB Base : onglet « Formulaires » (fonctionnalité activée).
 */
add_filter(
	'nb_base_admin_tabs',
	static function ( array $tabs ): array {
		if ( nb_base_feature_enabled( 'forms' ) ) {
			$tabs['forms'] = array(
				'label'  => __( 'Forms', 'nb-base' ),
				'render' => 'nb_base_forms_admin_tab',
			);
		}
		return $tabs;
	}
);

/**
 * Contenu de l'onglet.
 */
function nb_base_forms_admin_tab(): void {
	$settings = nb_base_forms_settings();
	?>
	<?php if ( ! nb_base_forms_plugin_active() ) : ?>
		<div class="notice notice-warning inline"><p><?php esc_html_e( 'The Contact Form 7 plugin is not active: forms are not displayed.', 'nb-base' ); ?></p></div>
	<?php else : ?>
		<?php $list_url = (string) apply_filters( 'nb_base_form_list_url', '' ); ?>
		<?php if ( '' !== $list_url ) : ?>
			<p><a class="button" href="<?php echo esc_url( $list_url ); ?>"><?php esc_html_e( 'Manage forms', 'nb-base' ); ?></a></p>
		<?php endif; ?>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="nb_base_save_forms">
		<?php wp_nonce_field( 'nb_base_save_forms' ); ?>
		<table class="form-table" role="presentation"><tbody>
			<tr>
				<th scope="row"><label for="nb-forms-retention"><?php esc_html_e( 'Message retention', 'nb-base' ); ?></label></th>
				<td>
					<select id="nb-forms-retention" name="forms[retention]">
						<?php foreach ( nb_base_forms_retention_labels() as $months => $label ) : ?>
							<option value="<?php echo esc_attr( (string) $months ); ?>" <?php selected( $settings['retention'], $months ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Received messages and their attached files are deleted automatically after this period (GDPR: keep personal data only as long as needed).', 'nb-base' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Accepted file formats', 'nb-base' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text"><?php esc_html_e( 'Accepted file formats', 'nb-base' ); ?></legend>
						<?php foreach ( array_keys( nb_base_form_file_types_available() ) as $key ) : ?>
							<label style="display:inline-block;min-width:6em;margin:0 1em .5em 0">
								<input type="checkbox" name="forms[fileTypes][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $settings['fileTypes'], true ) ); ?>>
								<?php echo esc_html( strtoupper( str_replace( '|', ', ', $key ) ) ); ?>
							</label>
						<?php endforeach; ?>
					</fieldset>
					<p class="description"><?php esc_html_e( 'Applies to every file field of every form. Each file’s real content is checked, not only its extension. No format ticked = all formats. Formats that can contain code (SVG, HTML, archives, old Office formats) are never offered.', 'nb-base' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nb-forms-max-size"><?php esc_html_e( 'Maximum file size', 'nb-base' ); ?></label></th>
				<td>
					<input id="nb-forms-max-size" class="small-text" type="number" min="1" max="<?php echo esc_attr( (string) nb_base_form_max_file_size_limit() ); ?>" name="forms[maxSize]" value="<?php echo esc_attr( (string) $settings['maxSize'] ); ?>"> <?php esc_html_e( 'MB per file', 'nb-base' ); ?>
					<p class="description">
						<?php
						printf(
							/* translators: %s: server upload limit (e.g. 64 MB). */
							esc_html__( 'Server limit: %s. A larger value is reduced to it.', 'nb-base' ),
							esc_html( size_format( nb_base_form_max_file_size_limit() * MB_IN_BYTES ) )
						);
						?>
					</p>
				</td>
			</tr>
		</tbody></table>
		<?php submit_button( __( 'Save forms settings', 'nb-base' ) ); ?>
	</form>
	<?php
}

add_action(
	'admin_post_nb_base_save_forms',
	static function () {
		nb_base_admin_guard( 'nb_base_save_forms' );
		$input = isset( $_POST['forms'] ) && is_array( $_POST['forms'] ) ? wp_unslash( $_POST['forms'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$clean = nb_base_forms_settings( $input );
		$clean['maxSize'] = min( $clean['maxSize'], nb_base_form_max_file_size_limit() );
		update_option( NB_BASE_FORMS_OPTION, $clean, false );
		nb_base_admin_redirect( 'forms-saved', 'forms' );
	}
);

/**
 * L'extension de formulaire est-elle active ? (Contact Form 7 aujourd'hui.)
 */
function nb_base_forms_plugin_active(): bool {
	return defined( 'WPCF7_VERSION' );
}

/* -------------------------------------------------------------------------
 * Affichage.
 * ---------------------------------------------------------------------- */

/**
 * Formulaires disponibles (fournis par l'adaptateur) : identifiant => nom.
 *
 * @return array<string, string>
 */
function nb_base_form_choices(): array {
	return (array) apply_filters( 'nb_base_form_choices', array() );
}

/**
 * HTML d'un formulaire et de sa mention d'information ('' si introuvable).
 *
 * @param string $form_id Identifiant du formulaire (voir nb_base_form_choices()).
 * @param bool   $privacy Ajouter la mention d'information (pas pour la
 *                        newsletter : sa case de consentement en tient lieu).
 */
function nb_base_form_html( string $form_id, bool $privacy = true ): string {
	if ( '' === $form_id || ! nb_base_feature_enabled( 'forms' ) ) {
		return '';
	}
	$html = (string) apply_filters( 'nb_base_form_html', '', $form_id );
	if ( '' === trim( $html ) ) {
		return '';
	}
	return '<div class="nb-form">' . $html . ( $privacy ? nb_base_form_privacy_html() : '' ) . '</div>';
}

/**
 * Mention d'information RGPD sous le formulaire (obligatoire ; pas de case à
 * cocher : répondre à une demande ne requiert pas de consentement).
 */
function nb_base_form_privacy_html(): string {
	$retention = nb_base_forms_retention_labels()[ nb_base_forms_settings()['retention'] ];
	$text      = sprintf(
		/* translators: 1: site name, 2: retention period (e.g. 6 months). */
		__( 'The information you provide is used by %1$s only to handle your request and is kept for %2$s. You can access, correct or delete it at any time.', 'nb-base' ),
		get_bloginfo( 'name' ),
		$retention
	);
	$html = esc_html( $text );

	// Service anti-robot externe (fourni par l'adaptateur : nom, adresse de
	// sa politique de confidentialité).
	$service = apply_filters( 'nb_base_form_protection_service', null );
	if ( is_array( $service ) && '' !== (string) ( $service['name'] ?? '' ) ) {
		$name  = esc_html( (string) $service['name'] );
		$name  = empty( $service['url'] ) ? $name : '<a href="' . esc_url( (string) $service['url'] ) . '">' . $name . '</a>';
		$html .= ' ' . sprintf(
			/* translators: %s: name of the anti-spam service (e.g. Cloudflare Turnstile), linked to its privacy policy. */
			esc_html__( 'To block spam, this form is protected by %s, which checks that it is sent by a person.', 'nb-base' ),
			$name
		);
	}

	$url = get_privacy_policy_url();
	if ( $url ) {
		$html .= ' <a href="' . esc_url( $url ) . '">' . esc_html__( 'Privacy policy', 'nb-base' ) . '</a>';
	}

	return '<p class="nb-form__privacy">' . $html . '</p>';
}

/**
 * Choix des listes « Type de demande » (option du site, une valeur par ligne
 * dans l'éditeur). Nettoyés : texte simple, sans doublon, 30 au plus.
 *
 * @param mixed $value Valeur reçue.
 * @return string[]
 */
function nb_base_sanitize_request_types( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$clean = array();
	foreach ( $value as $item ) {
		$item = trim( sanitize_text_field( (string) $item ) );
		if ( '' !== $item && ! in_array( $item, $clean, true ) ) {
			$clean[] = $item;
		}
	}
	return array_slice( $clean, 0, 30 );
}

add_action(
	'init',
	static function () {
		register_setting(
			'nb_base',
			'nb_base_request_types',
			array(
				'type'              => 'array',
				'description'       => __( 'Choices of the “Request type” lists of the forms.', 'nb-base' ),
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_request_types',
			)
		);
	}
);
add_filter( 'option_nb_base_request_types', 'nb_base_sanitize_request_types' );

/**
 * Textes communs des sections « Formulaire de contact » (surtitre, titre avec
 * mise en avant, texte) : option du site « nb_base_contact_section », utilisée
 * par les templates (réalisations) et par chaque bloc dont le réglage « Texte
 * commun » est actif ; modifiée depuis ces blocs (enregistrée avec la page).
 * Sans réglage enregistré : textes par défaut, dans la langue du site.
 *
 * @return array{eyebrow: string, title: string, text: string}
 */
function nb_base_contact_section_defaults(): array {
	return array(
		'eyebrow' => __( 'Contact – quote', 'nb-base' ),
		/* translators: the part between <mark> and </mark> is highlighted. */
		'title'   => str_replace( '<mark>', '<mark class="nb-highlight">', __( 'A project in mind? <mark>Let’s talk</mark>', 'nb-base' ) ),
		'text'    => __( 'Tell us about your needs: we will get back to you quickly.', 'nb-base' ),
	);
}

/**
 * @param mixed $value Valeur reçue.
 * @return array{eyebrow: string, title: string, text: string}
 */
function nb_base_sanitize_contact_section( $value ): array {
	$value = is_array( $value ) ? $value : array();
	return array(
		'eyebrow' => sanitize_text_field( (string) ( $value['eyebrow'] ?? '' ) ),
		'title'   => wp_kses( (string) ( $value['title'] ?? '' ), array( 'mark' => array( 'class' => true ), 'br' => array() ) ),
		'text'    => wp_kses( (string) ( $value['text'] ?? '' ), array( 'br' => array() ) ),
	);
}

/**
 * Textes communs (enregistrés, sinon par défaut).
 *
 * @return array{eyebrow: string, title: string, text: string}
 */
function nb_base_contact_section(): array {
	$saved = get_option( 'nb_base_contact_section', null );
	return is_array( $saved ) ? nb_base_sanitize_contact_section( $saved ) : nb_base_in_site_locale( 'nb_base_contact_section_defaults' );
}

add_action(
	'init',
	static function () {
		register_setting(
			'nb_base',
			'nb_base_contact_section',
			array(
				'type'              => 'object',
				'description'       => __( 'Shared texts of the contact form sections.', 'nb-base' ),
				'default'           => nb_base_in_site_locale( 'nb_base_contact_section_defaults' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'                 => 'object',
						'properties'           => array(
							'eyebrow' => array( 'type' => 'string' ),
							'title'   => array( 'type' => 'string' ),
							'text'    => array( 'type' => 'string' ),
						),
						'additionalProperties' => false,
					),
				),
				'sanitize_callback' => 'nb_base_sanitize_contact_section',
			)
		);
	}
);
add_filter( 'option_nb_base_contact_section', 'nb_base_sanitize_contact_section' );

/**
 * Données de l'éditeur (bloc nb-base/contact-form).
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		if ( ! nb_base_feature_enabled( 'forms' ) ) {
			return;
		}
		$choices = array();
		foreach ( nb_base_form_choices() as $id => $title ) {
			$choices[] = array(
				'value' => (string) $id,
				'label' => (string) $title,
			);
		}
		$data = array(
			'forms'        => $choices,
			'pluginActive' => nb_base_forms_plugin_active(),
			'editUrl'      => (string) apply_filters( 'nb_base_form_edit_url', '' ),
		);
		wp_add_inline_script( 'wp-block-editor', 'window.nbBaseForms = ' . wp_json_encode( $data ) . ';', 'before' );
	}
);

/* -------------------------------------------------------------------------
 * Messages reçus.
 * ---------------------------------------------------------------------- */

add_action(
	'init',
	static function () {
		register_post_type(
			NB_BASE_FORM_ENTRY_TYPE,
			array(
				'labels'              => array(
					'name'               => __( 'Messages', 'nb-base' ),
					'singular_name'      => __( 'Message', 'nb-base' ),
					'menu_name'          => __( 'Messages', 'nb-base' ),
					'all_items'          => __( 'Received messages', 'nb-base' ),
					'edit_item'          => __( 'Message', 'nb-base' ),
					'search_items'       => __( 'Search messages', 'nb-base' ),
					'not_found'          => __( 'No message received.', 'nb-base' ),
					'not_found_in_trash' => __( 'No message in the trash.', 'nb-base' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_nav_menus'   => false,
				'show_in_rest'        => false, // Données personnelles : jamais exposées par l'API.
				'show_ui'             => nb_base_feature_enabled( 'forms' ),
				'show_in_menu'        => true,
				'menu_position'       => 26,
				'menu_icon'           => 'dashicons-email-alt',
				'supports'            => false,
				'rewrite'             => false,
				'query_var'           => false,
				'map_meta_cap'        => true,
				// Lecture et suppression par les administrateurs ; aucune création ni modification.
				'capabilities'        => array(
					'create_posts'           => 'do_not_allow',
					'publish_posts'          => 'do_not_allow',
					'edit_posts'             => 'manage_options',
					'edit_others_posts'      => 'manage_options',
					'edit_published_posts'   => 'manage_options',
					'edit_private_posts'     => 'manage_options',
					'read_private_posts'     => 'manage_options',
					'delete_posts'           => 'manage_options',
					'delete_others_posts'    => 'manage_options',
					'delete_published_posts' => 'manage_options',
					'delete_private_posts'   => 'manage_options',
				),
			)
		);
	}
);

/**
 * Point d'entrée des adaptateurs : traite un envoi normalisé.
 *
 * @param array $submission Envoi normalisé (voir en-tête du fichier).
 * @return int Message enregistré (0 si non enregistré) : l'adaptateur affiche
 *             la réussite au visiteur même si l'e-mail n'est pas parti.
 */
function nb_base_form_handle_submission( array $submission ): int {
	if ( ! nb_base_feature_enabled( 'forms' ) ) {
		return 0;
	}

	$submission = wp_parse_args(
		$submission,
		array(
			'source'     => '',
			'form_id'    => '',
			'form_title' => '',
			'fields'     => array(),
			'files'      => array(),
			'mail_sent'  => true,
			'store'      => true,
		)
	);

	/**
	 * Envoi normalisé avant enregistrement (ex. newsletter : non enregistrée).
	 */
	$submission = (array) apply_filters( 'nb_base_form_submission', $submission );

	$entry_id = $submission['store'] ? nb_base_form_store_entry( $submission ) : 0;

	/**
	 * Après chaque envoi (newsletter, intégrations…).
	 *
	 * @param array $submission Envoi normalisé.
	 * @param int   $entry_id   Message enregistré (0 si non enregistré).
	 */
	do_action( 'nb_base_form_submitted', $submission, $entry_id );

	return $entry_id;
}

/**
 * Dossier de stockage des fichiers (créé et protégé au besoin).
 *
 * @return string Chemin absolu, sans barre finale ('' si impossible).
 */
function nb_base_forms_dir(): string {
	$uploads = wp_upload_dir( null, false );
	if ( ! empty( $uploads['error'] ) ) {
		return '';
	}
	$dir = trailingslashit( $uploads['basedir'] ) . NB_BASE_FORMS_DIR;

	if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
		return '';
	}

	// Accès direct interdit (Apache). Sous Nginx, les dossiers aléatoires
	// restent introuvables et aucun index n'est listé.
	$htaccess = $dir . '/.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		file_put_contents( $htaccess, "# NB Base: no direct access.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}
	if ( ! file_exists( $dir . '/index.php' ) ) {
		file_put_contents( $dir . '/index.php', "<?php\n// Silence.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
	}

	return $dir;
}

/**
 * Enregistre un envoi comme message reçu, avec copie des fichiers joints.
 *
 * @param array $submission Envoi normalisé.
 * @return int Identifiant du message (0 en cas d'échec).
 */
function nb_base_form_store_entry( array $submission ): int {
	$fields = array();
	foreach ( (array) $submission['fields'] as $name => $value ) {
		$name = sanitize_key( (string) $name );
		if ( '' === $name ) {
			continue;
		}
		$value           = is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
		$fields[ $name ] = sanitize_textarea_field( $value );
	}

	// Titre de la liste : nom (last-name ; ancien nom de champ : name), sinon
	// e-mail, sinon nom du formulaire.
	$title = '';
	foreach ( array( 'last-name', 'name', 'email' ) as $key ) {
		if ( '' !== ( $fields[ $key ] ?? '' ) ) {
			$title = $fields[ $key ];
			break;
		}
	}
	if ( '' === $title ) {
		$title = (string) $submission['form_title'];
	}

	$entry_id = wp_insert_post(
		array(
			'post_type'   => NB_BASE_FORM_ENTRY_TYPE,
			'post_status' => 'publish',
			'post_title'  => wp_strip_all_tags( $title ),
			'post_author' => 0,
		),
		true
	);
	if ( is_wp_error( $entry_id ) || ! $entry_id ) {
		return 0;
	}

	update_post_meta( $entry_id, '_nb_form_source', sanitize_key( (string) $submission['source'] ) );
	update_post_meta( $entry_id, '_nb_form_id', sanitize_text_field( (string) $submission['form_id'] ) );
	update_post_meta( $entry_id, '_nb_form_title', sanitize_text_field( (string) $submission['form_title'] ) );
	update_post_meta( $entry_id, '_nb_form_fields', $fields );
	update_post_meta( $entry_id, '_nb_form_mail_sent', $submission['mail_sent'] ? 1 : 0 );
	update_post_meta( $entry_id, '_nb_form_kind', nb_base_form_entry_kind( (string) ( $submission['kind'] ?? '' ) ) );

	$files = nb_base_form_store_files( (array) $submission['files'] );
	if ( $files ) {
		update_post_meta( $entry_id, '_nb_form_files', $files );
	}

	return (int) $entry_id;
}

/**
 * Copie les fichiers d'un envoi dans un dossier aléatoire protégé.
 * Chaque fichier est revérifié (contenu réel) ; un fichier refusé est ignoré.
 *
 * @param array<string, string[]> $files Nom du champ => chemins.
 * @return array<string, array<int, array{path: string, name: string, type: string, size: int}>>
 */
function nb_base_form_store_files( array $files ): array {
	$base = nb_base_forms_dir();
	if ( '' === $base ) {
		return array();
	}

	$folder = '';
	$stored = array();

	foreach ( $files as $field => $paths ) {
		$field = sanitize_key( (string) $field );
		foreach ( (array) $paths as $path ) {
			$path = (string) $path;
			$name = sanitize_file_name( wp_basename( $path ) );
			$type = nb_base_form_check_file( $path, $name );
			if ( '' === $field || false === $type ) {
				continue;
			}

			if ( '' === $folder ) {
				$folder = bin2hex( random_bytes( 16 ) );
				if ( ! wp_mkdir_p( $base . '/' . $folder ) ) {
					return array();
				}
			}

			$target = wp_unique_filename( $base . '/' . $folder, $name );
			if ( ! copy( $path, $base . '/' . $folder . '/' . $target ) ) {
				continue;
			}

			$stored[ $field ][] = array(
				'path' => $folder . '/' . $target, // Relatif au dossier de stockage.
				'name' => $name,
				'type' => $type,
				'size' => (int) filesize( $path ),
			);
		}
	}

	return $stored;
}

/**
 * Chemin absolu d'un fichier stocké, ou '' s'il est invalide.
 *
 * @param string $relative Chemin relatif enregistré.
 */
function nb_base_form_file_path( string $relative ): string {
	$base = nb_base_forms_dir();
	if ( '' === $base || ! preg_match( '#^[a-f0-9]{32}/[^/\\\\]+$#', $relative ) ) {
		return '';
	}
	$path = realpath( $base . '/' . $relative );
	$root = realpath( $base );
	return ( $path && $root && str_starts_with( $path, $root . DIRECTORY_SEPARATOR ) && is_file( $path ) ) ? $path : '';
}

/**
 * Supprime les fichiers d'un message quand il est supprimé définitivement.
 */
add_action(
	'before_delete_post',
	static function ( int $post_id ) {
		if ( NB_BASE_FORM_ENTRY_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$folders = array();
		foreach ( (array) get_post_meta( $post_id, '_nb_form_files', true ) as $list ) {
			foreach ( (array) $list as $file ) {
				$path = nb_base_form_file_path( (string) ( $file['path'] ?? '' ) );
				if ( $path ) {
					wp_delete_file( $path );
					$folders[ dirname( $path ) ] = true;
				}
			}
		}
		foreach ( array_keys( $folders ) as $folder ) {
			@rmdir( $folder ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- ne supprime que si vide.
		}
	}
);

/**
 * Téléchargement d'un fichier joint : comptes autorisés uniquement.
 */
add_action(
	'admin_post_nb_base_form_file',
	static function () {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- vérifié ci-dessous.
		$entry_id = isset( $_GET['entry'] ) ? absint( $_GET['entry'] ) : 0;
		$field    = isset( $_GET['field'] ) ? sanitize_key( wp_unslash( $_GET['field'] ) ) : '';
		$index    = isset( $_GET['index'] ) ? absint( $_GET['index'] ) : 0;
		// phpcs:enable

		check_admin_referer( 'nb_base_form_file_' . $entry_id );
		if ( NB_BASE_FORM_ENTRY_TYPE !== get_post_type( $entry_id ) || ! current_user_can( 'edit_post', $entry_id ) ) {
			wp_die( esc_html__( 'Restricted access.', 'nb-base' ), 403 );
		}

		$files = (array) get_post_meta( $entry_id, '_nb_form_files', true );
		$file  = $files[ $field ][ $index ] ?? null;
		$path  = is_array( $file ) ? nb_base_form_file_path( (string) ( $file['path'] ?? '' ) ) : '';
		if ( '' === $path ) {
			wp_die( esc_html__( 'File not found.', 'nb-base' ), 404 );
		}

		$type   = (string) $file['type'];
		$inline = in_array( $type, array( 'image/jpeg', 'image/png', 'image/webp' ), true );

		nocache_headers();
		header( 'Content-Type: ' . $type );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: ' . ( $inline ? 'inline' : 'attachment' ) . '; filename="' . str_replace( '"', '', (string) $file['name'] ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		header( "Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox" );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}
);

/**
 * Lien de téléchargement d'un fichier joint.
 */
function nb_base_form_file_url( int $entry_id, string $field, int $index ): string {
	return wp_nonce_url(
		add_query_arg(
			array(
				'action' => 'nb_base_form_file',
				'entry'  => $entry_id,
				'field'  => $field,
				'index'  => $index,
			),
			admin_url( 'admin-post.php' )
		),
		'nb_base_form_file_' . $entry_id
	);
}

/* -------------------------------------------------------------------------
 * Écrans d'administration (lecture seule).
 * ---------------------------------------------------------------------- */

add_action(
	'add_meta_boxes_' . NB_BASE_FORM_ENTRY_TYPE,
	static function ( WP_Post $post ) {
		remove_meta_box( 'submitdiv', NB_BASE_FORM_ENTRY_TYPE, 'side' );
		remove_meta_box( 'slugdiv', NB_BASE_FORM_ENTRY_TYPE, 'normal' );
		add_meta_box( 'nb-form-entry', __( 'Message', 'nb-base' ), 'nb_base_form_entry_box', NB_BASE_FORM_ENTRY_TYPE, 'normal', 'high' );
		add_meta_box( 'nb-form-entry-info', __( 'Details', 'nb-base' ), 'nb_base_form_entry_info_box', NB_BASE_FORM_ENTRY_TYPE, 'side', 'high' );
	}
);

/**
 * Contenu du message : champs puis fichiers joints.
 */
function nb_base_form_entry_box( WP_Post $post ): void {
	$fields = (array) get_post_meta( $post->ID, '_nb_form_fields', true );
	$files  = (array) get_post_meta( $post->ID, '_nb_form_files', true );
	?>
	<table class="widefat striped nb-form-entry">
		<tbody>
		<?php foreach ( $fields as $name => $value ) : ?>
			<?php if ( '' === (string) $value ) { continue; } ?>
			<tr>
				<th scope="row" style="width:25%"><?php echo esc_html( (string) $name ); ?></th>
				<td><?php echo nl2br( esc_html( (string) $value ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php foreach ( $files as $field => $list ) : ?>
			<tr>
				<th scope="row"><?php echo esc_html( (string) $field ); ?></th>
				<td>
					<?php foreach ( (array) $list as $index => $file ) : ?>
						<?php
						$url   = nb_base_form_file_url( $post->ID, (string) $field, (int) $index );
						$image = in_array( $file['type'] ?? '', array( 'image/jpeg', 'image/png', 'image/webp' ), true );
						?>
						<p>
							<?php if ( $image ) : ?>
								<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( $url ); ?>" alt="" style="display:block;max-width:240px;max-height:240px;margin-bottom:4px"></a>
							<?php endif; ?>
							<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( (string) ( $file['name'] ?? '' ) ); ?></a>
							(<?php echo esc_html( size_format( (int) ( $file['size'] ?? 0 ) ) ); ?>)
						</p>
					<?php endforeach; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * Informations : formulaire, date, état de l'e-mail, suppression.
 */
function nb_base_form_entry_info_box( WP_Post $post ): void {
	$mail_sent = (bool) get_post_meta( $post->ID, '_nb_form_mail_sent', true );
	$retention = nb_base_forms_settings()['retention'];
	?>
	<p><strong><?php esc_html_e( 'Form', 'nb-base' ); ?></strong><br><?php echo esc_html( (string) get_post_meta( $post->ID, '_nb_form_title', true ) ); ?></p>
	<p><strong><?php esc_html_e( 'Received', 'nb-base' ); ?></strong><br><?php echo esc_html( get_the_date( '', $post ) . ' ' . get_the_time( '', $post ) ); ?></p>
	<?php if ( ! $mail_sent ) : ?>
		<p style="color:#b32d2e"><strong><?php esc_html_e( 'The notification email could not be sent.', 'nb-base' ); ?></strong></p>
	<?php endif; ?>
	<p class="description">
		<?php
		/* translators: %s: retention period (e.g. 6 months). */
		echo esc_html( sprintf( __( 'Deleted automatically %s after receipt.', 'nb-base' ), nb_base_forms_retention_labels()[ $retention ] ) );
		?>
	</p>
	<?php if ( current_user_can( 'delete_post', $post->ID ) ) : ?>
		<p><a class="submitdelete" style="color:#b32d2e" href="<?php echo esc_url( (string) get_delete_post_link( $post->ID, '', true ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this message and its files permanently?', 'nb-base' ) ); ?>');"><?php esc_html_e( 'Delete permanently', 'nb-base' ); ?></a></p>
	<?php endif; ?>
	<?php
}

// Colonnes de la liste.
add_filter(
	'manage_' . NB_BASE_FORM_ENTRY_TYPE . '_posts_columns',
	static function (): array {
		return array(
			'cb'       => '<input type="checkbox">',
			'title'    => __( 'From', 'nb-base' ),
			'nb_email' => __( 'Email', 'nb-base' ),
			'nb_form'  => __( 'Form', 'nb-base' ),
			'nb_files' => __( 'Files', 'nb-base' ),
			'date'     => __( 'Received', 'nb-base' ),
		);
	}
);

add_action(
	'manage_' . NB_BASE_FORM_ENTRY_TYPE . '_posts_custom_column',
	static function ( string $column, int $post_id ) {
		if ( 'nb_email' === $column ) {
			$fields = (array) get_post_meta( $post_id, '_nb_form_fields', true );
			$email  = sanitize_email( (string) ( $fields['email'] ?? '' ) );
			if ( $email ) {
				echo '<a href="' . esc_url( 'mailto:' . $email ) . '">' . esc_html( $email ) . '</a>';
			}
		} elseif ( 'nb_form' === $column ) {
			echo esc_html( (string) get_post_meta( $post_id, '_nb_form_title', true ) );
			if ( ! get_post_meta( $post_id, '_nb_form_mail_sent', true ) ) {
				echo '<br><span style="color:#b32d2e">' . esc_html__( 'Email not sent', 'nb-base' ) . '</span>';
			}
		} elseif ( 'nb_files' === $column ) {
			$count = 0;
			foreach ( (array) get_post_meta( $post_id, '_nb_form_files', true ) as $list ) {
				$count += count( (array) $list );
			}
			echo $count ? esc_html( (string) $count ) : '—';
		}
	},
	10,
	2
);

/* -------------------------------------------------------------------------
 * Onglets de la liste : Demandes / Newsletter (métadonnée _nb_form_kind ;
 * sans métadonnée = demande). Sans onglet choisi : Demandes.
 * ---------------------------------------------------------------------- */

/**
 * Sources des messages : identifiant => libellé de l'onglet.
 *
 * @return array<string, string>
 */
function nb_base_form_entry_kinds(): array {
	return array(
		'message'    => __( 'Requests', 'nb-base' ),
		'newsletter' => __( 'Newsletter', 'nb-base' ),
	);
}

function nb_base_form_entry_kind( string $kind ): string {
	return array_key_exists( $kind, nb_base_form_entry_kinds() ) ? $kind : 'message';
}

/**
 * Condition de requête pour une source.
 */
function nb_base_form_entry_kind_query( string $kind ): array {
	if ( 'message' === $kind ) {
		return array(
			'relation' => 'OR',
			array( 'key' => '_nb_form_kind', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_nb_form_kind', 'value' => 'message' ),
		);
	}
	return array( array( 'key' => '_nb_form_kind', 'value' => $kind ) );
}

/**
 * Onglet affiché (paramètre nb_kind de l'adresse).
 */
function nb_base_form_entry_current_kind(): string {
	return nb_base_form_entry_kind( isset( $_GET['nb_kind'] ) ? sanitize_key( wp_unslash( $_GET['nb_kind'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}

add_action(
	'pre_get_posts',
	static function ( WP_Query $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || NB_BASE_FORM_ENTRY_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'edit-' . NB_BASE_FORM_ENTRY_TYPE !== $screen->id ) {
			return;
		}
		$query->set( 'meta_query', nb_base_form_entry_kind_query( nb_base_form_entry_current_kind() ) );
	}
);

// Onglets « Demandes (n) | Newsletter (n) » à la place de « Tous » (la corbeille reste).
add_filter(
	'views_edit-' . NB_BASE_FORM_ENTRY_TYPE,
	static function ( array $views ): array {
		$is_trash = isset( $_GET['post_status'] ) && 'trash' === $_GET['post_status']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current  = nb_base_form_entry_current_kind();
		$tabs     = array();
		foreach ( nb_base_form_entry_kinds() as $kind => $label ) {
			$count = ( new WP_Query(
				array(
					'post_type'      => NB_BASE_FORM_ENTRY_TYPE,
					'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
					'meta_query'     => nb_base_form_entry_kind_query( $kind ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			) )->found_posts;
			$url              = add_query_arg( array( 'post_type' => NB_BASE_FORM_ENTRY_TYPE, 'nb_kind' => $kind ), admin_url( 'edit.php' ) );
			$tabs[ 'nb-' . $kind ] = sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$s)</span></a>',
				esc_url( $url ),
				( ! $is_trash && $kind === $current ) ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				esc_html( number_format_i18n( $count ) )
			);
		}
		unset( $views['all'], $views['publish'] );
		return array_merge( $tabs, $views );
	}
);

// Les actions de la liste (recherche, pagination, suppression groupée) restent dans l'onglet.
add_action(
	'restrict_manage_posts',
	static function ( string $post_type ) {
		if ( NB_BASE_FORM_ENTRY_TYPE === $post_type ) {
			echo '<input type="hidden" name="nb_kind" value="' . esc_attr( nb_base_form_entry_current_kind() ) . '">';
		}
	}
);

// Pas de modification : « Voir » à la place de « Modifier », pas de modification rapide ni groupée.
add_filter(
	'post_row_actions',
	static function ( array $actions, WP_Post $post ): array {
		if ( NB_BASE_FORM_ENTRY_TYPE !== $post->post_type ) {
			return $actions;
		}
		unset( $actions['inline hide-if-no-js'] );
		if ( isset( $actions['edit'] ) ) {
			$actions['edit'] = '<a href="' . esc_url( (string) get_edit_post_link( $post->ID ) ) . '">' . esc_html__( 'View', 'nb-base' ) . '</a>';
		}
		return $actions;
	},
	10,
	2
);

add_filter(
	'bulk_actions-edit-' . NB_BASE_FORM_ENTRY_TYPE,
	static function ( array $actions ): array {
		unset( $actions['edit'] );
		return $actions;
	}
);

/* -------------------------------------------------------------------------
 * Conservation limitée : suppression automatique quotidienne.
 * Active même si la fonctionnalité est désactivée (données déjà reçues).
 * ---------------------------------------------------------------------- */

add_action(
	'init',
	static function () {
		if ( ! wp_next_scheduled( 'nb_base_forms_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'nb_base_forms_cleanup' );
		}
	}
);

add_action( 'nb_base_forms_cleanup', 'nb_base_forms_cleanup' );

/**
 * Supprime définitivement les messages plus anciens que la durée de conservation.
 *
 * @return int Nombre de messages supprimés.
 */
function nb_base_forms_cleanup(): int {
	$months  = nb_base_forms_settings()['retention'];
	$before  = gmdate( 'Y-m-d H:i:s', strtotime( "-{$months} months" ) );
	$deleted = 0;

	// Par lots ; nombre de tours borné (un message impossible à supprimer ne bloque pas la boucle).
	for ( $round = 0; $round < 50; $round++ ) {
		$ids = get_posts(
			array(
				'post_type'        => NB_BASE_FORM_ENTRY_TYPE,
				'post_status'      => array( 'publish', 'private', 'draft', 'pending', 'future', 'trash' ),
				'fields'           => 'ids',
				'posts_per_page'   => 100,
				'offset'           => 0,
				'no_found_rows'    => true,
				'suppress_filters' => true,
				'date_query'       => array( array( 'before' => $before, 'column' => 'post_date_gmt' ) ),
			)
		);
		if ( ! $ids ) {
			break;
		}
		$round_deleted = 0;
		foreach ( $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				++$round_deleted;
			}
		}
		$deleted += $round_deleted;
		if ( 0 === $round_deleted ) {
			break;
		}
	}

	return $deleted;
}
